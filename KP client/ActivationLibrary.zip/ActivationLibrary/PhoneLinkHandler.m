//
//  PhoneLinkHandler.m
//  MobileCare
//
//  Created by Zhanquan He on 7/18/11.
//  Copyright 2011 kaiser permanente. All rights reserved.
//

#import "PhoneLinkHandler.h"
#import "MessageMan.h"

@implementation PhoneLinkHandler

@synthesize alertTitle;
@synthesize cancelBtnText;
@synthesize callString;
@synthesize callPromptsAndNumbers;

- (id)init
{
    if ((self = [super init]))
    {
        self.alertTitle = @"Call KP";
        self.cancelBtnText=@"Cancel";
        self.callString=nil;
        self.callPromptsAndNumbers=nil;
    }
    return self;
}

- (BOOL) deviceSupportsCalls
{
    BOOL bCanCall = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tel://"]];
    return bCanCall;
}

- (void) displayNotSupported:(NSArray*)aPhoneNums
{
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Call KP" message:@"Calling from this device is not supported." delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
//    alert.tag=kNotSupported;
//    [alert show];
//    [alert release];    

    NSString* szMessage = @"";
    for (id phN in aPhoneNums)
    {
        if ([szMessage length] > 0)
        {
            szMessage = [NSString stringWithFormat:@"%@\n", szMessage];
        }
        
        if ([phN isKindOfClass:[NSDictionary class]]) 
        {                
            szMessage = [NSString stringWithFormat:@"%@%@", szMessage, [phN objectForKey:@"prompt"]];                
        }
        else // assume NSString 
        {
            szMessage = [NSString stringWithFormat:@"%@%@", szMessage, phN];                
        }
    }        
    
    [MessageMan showMessage:szMessage withTitle:@"Your device does not support calls"];

}

- (void) displaySingleNumber:(NSString *)phoneNum
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:phoneNum delegate:self cancelButtonTitle:cancelBtnText otherButtonTitles:@"Call", nil];
    alert.tag=kSingleNumber;
    self.callString=[NSString stringWithFormat:@"Tel:%@", phoneNum];
    [alert show];
    [alert release];    
}

- (void) showPhoneAlertWithPhoneNum:(NSString *)phoneNum
{
    if (NO == [self deviceSupportsCalls]) 
    {
        [self displayNotSupported:[NSArray arrayWithObject:phoneNum]];
    } 
    else 
    {
        [self displaySingleNumber:phoneNum];
    }
}
- (void) doCallDirectly:(NSString *)phoneNum{
    
    if (NO == [self deviceSupportsCalls])
    {
        [self displayNotSupported:[NSArray arrayWithObject:phoneNum]];
    }
    else
    {
        self.callString=[NSString stringWithFormat:@"Tel:%@", phoneNum];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:self.callString]];
    }

    
}
- (void) showPhoneAlertWithPhoneNums:(NSArray *)phoneNums
{    
    if (NO == [self deviceSupportsCalls]) 
    {
        [self displayNotSupported:phoneNums];
    } 
    else 
    {
        if ([phoneNums count]==1) 
        {
            id phN = [phoneNums objectAtIndex:0];            
            
            if ([phN isKindOfClass:[NSDictionary class]]) 
            {
                [self displaySingleNumber:[phN objectForKey: @"number"]];
            } 
            else // assume NSString 
            {
                [self displaySingleNumber:phN];
            }
        }  
        else if ([phoneNums count]>1)
        {
            self.callPromptsAndNumbers=[NSMutableArray arrayWithCapacity:2];
            
            NSString* msg = @"Please choose a number:";
        
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:msg delegate:self cancelButtonTitle:cancelBtnText otherButtonTitles:nil];
            
            for (id phN in phoneNums) 
            {
                if ([phN isKindOfClass:[NSDictionary class]]) {
                    NSString *buttonTitle=[phN objectForKey:@"prompt"];
                    [alert addButtonWithTitle:buttonTitle];
                    NSString *number=[phN objectForKey: @"number"];
                    [self.callPromptsAndNumbers addObject:[NSString stringWithFormat:@"tel://%@", number]];
                } else {
                    [alert addButtonWithTitle:phN];
                    [self.callPromptsAndNumbers addObject:[NSString stringWithFormat:@"tel://%@", phN]];
                }
            }
         
            alert.tag=kMultipleNumber;
            
            [alert show];
            [alert release];
        }
    }  
}

- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==kSingleNumber) 
    {
        if (buttonIndex==1 && self.callString != nil) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:self.callString]];
        }
    } 
    else if (alertView.tag==kMultipleNumber) 
    {
        if (self.callPromptsAndNumbers != nil && buttonIndex > 0) 
        {
            NSString* szPhoneNo = [self.callPromptsAndNumbers objectAtIndex:buttonIndex-1];
            NSURL* url = [NSURL URLWithString:szPhoneNo];
            [[UIApplication sharedApplication] openURL:url];
        }
    }
}

- (void)dealloc
{
    self.callString = nil;
    self.callPromptsAndNumbers=nil;
    [super dealloc];
}

@end
