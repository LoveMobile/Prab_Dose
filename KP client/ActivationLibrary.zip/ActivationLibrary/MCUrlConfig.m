//
//  MCUrlConfig.m
//  MobileCare
//
//  Created by Sean Gilligan on 12/3/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//

#import "MCUrlConfig.h"

@implementation MCUrlConfig

@synthesize wsBaseURL, webBaseURL;

- (id)initWithKey:(NSString *)key
{
    self = [super init];
    
    if (self)
	{
		NSString *plistFilePath = [[NSBundle mainBundle] pathForResource:@"urlConfig" ofType:@"plist"];
		NSDictionary *urlConfigPlist = [NSDictionary dictionaryWithContentsOfFile:plistFilePath];
		NSDictionary *urlConfigDict =  [urlConfigPlist valueForKey:key];
//		self.ssoURL = [urlConfigDict valueForKey:@"ssoURL"];
		self.wsBaseURL = [urlConfigDict valueForKey:@"wsBaseURL"];
        self.webBaseURL = [urlConfigDict valueForKey:@"webBaseURL"];
    }
    return self;
}

@end
