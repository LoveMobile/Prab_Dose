//
//  IdleTimerMan.m
//  MobileCare
//
//  Created by Surya Pasula on 7/15/11.
//  Copyright 2011 TPMG. All rights reserved.
//

#import "IdleTimerMan.h"
#import "AuthorizationMan.h"
#import "Utilities.h"
#import "Constants.h"

static IdleTimerMan *mIM=nil;

@interface IdleTimerMan (Private)
- (void) showPassCodeView;
@end

@implementation IdleTimerMan
@synthesize idleTimer;
@synthesize passCodeActive;
@synthesize changePasscodeActive;

+ (IdleTimerMan *) get
{
    if (mIM==nil) {
        mIM=[[IdleTimerMan alloc] init];
    }
    return mIM;
}

- (id) init
{
    if ((self=[super init])) {
        self.passCodeActive=NO;
        self.changePasscodeActive=NO;
    }
    return self;
}

- (void) killTimer {
    
    if (self.idleTimer) {
        [self.idleTimer invalidate];
    }    
    self.idleTimer = nil;
}

- (void) idleAction {
    LOG("The idleTimer fired!");
    /*
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"flagSignOn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[Utilities getAppDel] showMerlin];    
     */
    [Utilities signOff];
}


//reset the idleTime
- (void) resetIdleTimer {
    LOG("The idleTimer get reseted!");
    if (!idleTimer || ![idleTimer isValid]) {
        idleTimer = nil;
//        LOG("resetIdleTimer ==> creating idleTimer");
        idleTimer = [[NSTimer scheduledTimerWithTimeInterval:kMaxIdleTimeInterval
                                                      target:self
                                                    selector:@selector(idleAction)
                                                    userInfo:nil
                                                     repeats:NO] retain];
    }
    else {
//        LOG("resetIdleTimer ==> reset time on idleTimer");
        if (fabs([idleTimer.fireDate timeIntervalSinceNow]) < kMaxIdleTimeInterval-1.0) {
            [idleTimer setFireDate:[NSDate dateWithTimeIntervalSinceNow:kMaxIdleTimeInterval]];
        }
    }
}

- (void) merlinClosed {
    //passcode screen closed
    [Utilities getAppDel].delegate = nil;
    self.passCodeActive = NO;
    [self resetIdleTimer];
}

- (void)dealloc
{
    if (self.idleTimer) {
        [self.idleTimer invalidate];
    } 
    self.idleTimer = nil;
    
    [super dealloc];
}


@end
