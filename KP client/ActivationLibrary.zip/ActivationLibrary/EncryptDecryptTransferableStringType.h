/*

  EncryptDecryptTransferableType.h
  MobileCare

  Created by Hursh Prasad on 4/21/11.
  Copyright 2011 AppStem, Inc. All rights reserved.

 
 Please refrence the following Apple Guide
 http://developer.apple.com/library/ios/#documentation/Security/Conceptual/Security_Overview/Introduction/Introduction.html
  
 This class uses Cryptography of Apples CommonCrypto library in iOS supporting 3.1.3 and forward. 

 The following headers and libs are included in SecKeyWrapper class
 #import <Security/Security.h>
 #import <CommonCrypto/CommonDigest.h>
 #import <CommonCrypto/CommonCryptor.h>
 
 The libraries support hardware accelerated API with a hardware generated symmetric key
 
*/

#import <Foundation/Foundation.h>
#import "SecKeyWrapper.h"


@interface EncryptDecryptTransferableStringType : NSValueTransformer {
    
}

- (NSString *)encryptString:(NSString *)value;

- (NSString *)decryptString:(NSString *)value;

- (NSString *)encryptString:(NSString *)value withKey:(NSString *)key;

- (NSString *)decryptString:(NSString *)value withKey:(NSString *)key;

@end
