//
//  TTGFetcherImage.m
//  TTGMobile
//
//  Created by Sandesh Pujar on 15/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGFetcherImage.h"
#import "TTGNetworkManager.h"
#import "TTGRequestManager.h"
#import "Reachability.h"


typedef void (^TTGFetcherImageBlock)(NSURLResponse *response, NSData *data, NSError *error);

@implementation TTGFetcherImage


#pragma mark - Private methods

- (void)startConnectioManagerWithRequest:(NSMutableURLRequest *)request withCompletionBlock:(TTGFetcherImageBlock)iCompletionBlock {
    [TTGNetworkManager initiateAsynchronousConnectionWithRequest:request andCompletionHandler:iCompletionBlock];
}


#pragma mark - Initialization methods

static TTGFetcherImage *fetcherImageSharedSingleton;

+ (TTGFetcherImage *)sharedSingleton {
    if (fetcherImageSharedSingleton == nil) {
        fetcherImageSharedSingleton = [[TTGFetcherImage alloc] init];
    }
    
    return fetcherImageSharedSingleton;
}


- (id)init {
    if (self = [super init]) {
        
    }
	
    return self;
}


#pragma mark - Wrapper method

- (void)initiateRequestWithHeaderParameter:(NSDictionary *)headerParameter bodyParameter:(NSDictionary *)bodyParameter httpMethodType:(NSString *)httpMethodType urlString:(NSString *)urlString andCompletionHandler:(TTGFetcherImageBlock)iCompletionBlock {
    NSMutableURLRequest *request = nil;
    
    NSMutableDictionary *headerDictionary = [NSMutableDictionary dictionaryWithDictionary:headerParameter];
    NSMutableDictionary *bodyDictionary = [NSMutableDictionary dictionaryWithDictionary:bodyParameter];
    
    // Initiating request manager to prepare request based on webservice type
    request = [TTGRequestManager createImageRequestWithHeader:headerDictionary body:bodyDictionary httpMethodType:httpMethodType andRequestUrlString:urlString];
    
    // Making the reachability check, if network available make the service call, else send back an error to the delegate
    Reachability * reachability = [Reachability reachabilityForInternetConnection];
    [reachability startNotifier];
    
    NetworkStatus remoteHostStatus = [reachability currentReachabilityStatus];
    
    if (remoteHostStatus == NotReachable) {
        NSURLResponse *urlResponse = (NSURLResponse *)[NSNull null];
        NSData *data = (NSData *)[NSNull null];
        NSError *error = [NSError errorWithDomain:@"" code:0 userInfo:nil];
        
		if (iCompletionBlock) {
			iCompletionBlock(urlResponse, data, error);
		}
    } else {
        [self startConnectioManagerWithRequest:request withCompletionBlock:(TTGFetcherImageBlock)iCompletionBlock];
    }
}


@end