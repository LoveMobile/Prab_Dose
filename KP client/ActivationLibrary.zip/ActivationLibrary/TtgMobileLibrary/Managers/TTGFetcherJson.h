//
//  TTGFetcherJson.h
//  TTGSignOn
//
//  Created by Sandesh Pujar on 30/10/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

typedef enum {
    kWebserviceTypeSystemStatus = 0,
    kWebserviceTypeSignOn,
    kWebserviceTypeSignOff,
    kWebserviceTypeKeepAlive
} WebserviceType;

@interface TTGFetcherJson : NSObject

@property (assign, nonatomic) WebserviceType webserviceType;

+ (TTGFetcherJson *)sharedSingleton;// Creates shared singleton instance
- (void)initiateRequestWithHeaderParameter:(NSDictionary *)headerParameter bodyParameter:(NSDictionary *)bodyParameter httpMethodType:(NSString *)httpMethodType urlString:(NSString *)urlString andCompletionHandler:(void(^)(NSURLResponse *response, NSData *data, NSError *error))completion;// Wrapper method along with completion handler

@end