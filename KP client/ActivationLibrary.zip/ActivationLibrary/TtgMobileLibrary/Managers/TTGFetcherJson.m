//
//  TTGFetcherJson.m
//  TTGSignOn
//
//  Created by Sandesh Pujar on 30/10/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGFetcherJson.h"
#import "TTGNetworkManager.h"
#import "TTGRequestManager.h"
#import "Reachability.h"


typedef void(^TTGFetcherJsonBlock)(NSURLResponse *response, NSData *data, NSError *error);

@interface TTGFetcherJson ()

@property (nonatomic, strong) NSDictionary *requestParameter;

@end


@implementation TTGFetcherJson


#pragma mark - Private methods

- (void)startConnectioManagerWithRequest:(NSMutableURLRequest *)request withCompletionBlock:(TTGFetcherJsonBlock)iCompletionBlock {
	[TTGNetworkManager initiateAsynchronousConnectionWithRequest:request andCompletionHandler:iCompletionBlock];;
}


#pragma mark - Initialization methods

static TTGFetcherJson *fetcherJsonSharedSingleton;

+ (TTGFetcherJson *)sharedSingleton {
    if(fetcherJsonSharedSingleton == nil) {
        fetcherJsonSharedSingleton = [[TTGFetcherJson alloc] init];
    }
    
    return fetcherJsonSharedSingleton;
}


- (id)init {
    if (self = [super init]) {
    
    }
    return self;
}


#pragma mark - Wrapper method

- (void)initiateRequestWithHeaderParameter:(NSDictionary *)headerParameter bodyParameter:(NSDictionary *)bodyParameter httpMethodType:(NSString *)httpMethodType urlString:(NSString *)urlString andCompletionHandler:(TTGFetcherJsonBlock)iCompletionBlock {
    NSMutableURLRequest *request = nil;
    NSMutableDictionary *headerDictionary = [NSMutableDictionary dictionaryWithDictionary:headerParameter];
    NSMutableDictionary *bodyDictionary = [NSMutableDictionary dictionaryWithDictionary:bodyParameter];
    
    // Initiating request manager to prepare request based on webservice type
    request = [TTGRequestManager createJsonRequestWithHeader:headerDictionary body:bodyDictionary httpMethodType:httpMethodType andRequestUrlString:urlString];
    
    // Making the reachability check, if network available make the service call, else send back an error to the delegate
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    [reachability startNotifier];
    
    NetworkStatus remoteHostStatus = [reachability currentReachabilityStatus];
    
    if (remoteHostStatus == NotReachable) {
        NSURLResponse *urlResponse = (NSURLResponse *)[NSNull null];
        NSData *data = (NSData *)[NSNull null];
        NSError *error = [NSError errorWithDomain:@"" code:0 userInfo:nil];
        
		if (iCompletionBlock) {
			iCompletionBlock(urlResponse, data, error);
		}
    } else {
        [self startConnectioManagerWithRequest:request withCompletionBlock:(TTGFetcherJsonBlock)iCompletionBlock];
    }
}


@end
