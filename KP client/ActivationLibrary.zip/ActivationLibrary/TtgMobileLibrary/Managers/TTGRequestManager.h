//
//  TTGRequestManager.h
//  TTGMobile
//
//  Created by Niranjan K N on 10/30/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGFetcherJson.h"

@interface TTGRequestManager : NSObject

// Json request creation method
+ (NSMutableURLRequest *)createJsonRequestWithHeader:(NSMutableDictionary *)header body:(NSMutableDictionary *)body httpMethodType:(NSString *)methodType andRequestUrlString:(NSString *)urlString;

+ (NSMutableURLRequest *)createImageRequestWithHeader:(NSMutableDictionary *)header body:(NSMutableDictionary *)body httpMethodType:(NSString *)methodType andRequestUrlString:(NSString *)urlString;

@end
