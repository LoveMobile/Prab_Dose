//
//  TTGRequestManager.m
//  TTGMobile
//
//  Created by Niranjan K N on 10/30/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGRequestManager.h"
#import "NSData+TTGMobileBase64.h"
#import "TTGConstants.h"


@implementation TTGRequestManager


#pragma mark - Json request creation method

+ (NSMutableURLRequest *)createJsonRequestWithHeader:(NSMutableDictionary *)header body:(NSMutableDictionary *)body httpMethodType:(NSString *)methodType andRequestUrlString:(NSString *)urlString {
    // Creating NSURL object form url string
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    // Setting Header fields if available
    if ([header count] > 0) {
        // Filling all the header items
        for (NSInteger i = 0; i < [header count]; i++) {
            NSString *headerKey = [[header allKeys] objectAtIndex:i];
            NSString *headerValue = [header objectForKey:headerKey];
            
            [request addValue:headerValue forHTTPHeaderField:headerKey];
        }
        
        // Setting the content type as json
        [request addValue:kRequestHTTPHeaderValue forHTTPHeaderField:kRequestHTTPHeaderField];
        
        // Printing header fields
        NSDictionary *headerFields = [request allHTTPHeaderFields];
        LOG("\nRequest header fields :\n%@", [headerFields description]);
    }
    
    // Setting Body parameters if availabe
    if ([body count] > 0) {
        // Converting Dictionary to JSON String
        NSError *error = nil;
        NSData *requestBody = [NSJSONSerialization dataWithJSONObject:body options:NSJSONWritingPrettyPrinted error:&error];
        
        [request setHTTPBody:requestBody];
    }
    
    if ([methodType length] > 0) {
        [request setHTTPMethod:methodType];
	} else {
        if ([body count] > 0) {
            [request setHTTPMethod:kRequestHTTPMethodPost];
		} else {
            [request setHTTPMethod:kRequestHTTPMethodGet];
		}
    }
    
    return request;
}


+ (NSMutableURLRequest *)createImageRequestWithHeader:(NSMutableDictionary *)header body:(NSMutableDictionary *)body httpMethodType:(NSString *)methodType andRequestUrlString:(NSString *)urlString {
    NSString *cookieHeaderValue = [header objectForKey:kCookieKey];
    
    NSMutableURLRequest* request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:urlString]];
    
    [request setHTTPMethod:methodType];
    [request setTimeoutInterval:60];
    
    [request setValue:cookieHeaderValue forHTTPHeaderField:kCookieKey];
    
    // Printing header fields
    NSDictionary *headerFields = [request allHTTPHeaderFields];
    LOG("\nRequest header fields :\n%@", [headerFields description]);
    
    return request;
}


@end
