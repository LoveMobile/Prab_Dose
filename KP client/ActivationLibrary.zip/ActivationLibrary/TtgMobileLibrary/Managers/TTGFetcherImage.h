//
//  TTGFetcherImage.h
//  TTGMobile
//
//  Created by Sandesh Pujar on 15/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

@interface TTGFetcherImage : NSObject

+ (TTGFetcherImage *)sharedSingleton;// Creates shared singleton instance
- (void)initiateRequestWithHeaderParameter:(NSDictionary *)headerParameter bodyParameter:(NSDictionary *)bodyParameter httpMethodType:(NSString *)httpMethodType urlString:(NSString *)urlString andCompletionHandler:(void(^)(NSURLResponse *response, NSData *data, NSError *error))completion;// Wrapper method along with completion handler

@end
