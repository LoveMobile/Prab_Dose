//
//  TTGFetcherImage.h
//  TTGMobile
//
//  Created by Niranjan K N on 10/30/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGNetworkManager.h"


@implementation TTGNetworkManager


#pragma mark - Wrapper method
 
+ (void)initiateAsynchronousConnectionWithRequest:(NSMutableURLRequest *)iServiceRequest andCompletionHandler:(void(^)(NSURLResponse *response, NSData *data, NSError *error))iCompletion {
    [iServiceRequest setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    
    NSOperationQueue *anOperationQueue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:iServiceRequest queue:anOperationQueue completionHandler:iCompletion];
}


+ (void)initiateSynchronousConnectionWithRequest:(NSMutableURLRequest *)iServiceRequest andCompletionHandler:(void(^)(NSURLResponse *response, NSData *data, NSError *error))iCompletion {
    NSURLResponse *aResponse = nil;
    NSError *anError = nil;
    NSData *aRequestData = [NSURLConnection sendSynchronousRequest:iServiceRequest returningResponse:&aResponse error:&anError];
    
	if (iCompletion) {
		iCompletion(aResponse, aRequestData, anError);
	}
}


@end
