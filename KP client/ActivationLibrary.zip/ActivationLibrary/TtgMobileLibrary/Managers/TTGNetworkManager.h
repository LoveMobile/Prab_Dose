//
//  TTGFetcherImage.h
//  TTGMobile
//
//  Created by Niranjan K N on 10/30/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

@interface TTGNetworkManager : NSObject

+ (void)initiateAsynchronousConnectionWithRequest:(NSMutableURLRequest *)serviceRequest andCompletionHandler:(void(^)(NSURLResponse *response, NSData *data, NSError *error))completion;

+ (void)initiateSynchronousConnectionWithRequest:(NSMutableURLRequest *)serviceRequest andCompletionHandler:(void(^)(NSURLResponse *response, NSData *data, NSError *error))completion;

@end