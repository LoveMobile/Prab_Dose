//
//  TTGKeepAliveManager.h
//  TTGSignOn
//
//  Created by Niranjan K N on 11/6/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

@class TTGStatus;

@interface TTGKeepAliveManager : NSObject 

- (id)initWithSsosession:(NSString *)appSsosession;
- (void)performKeepAliveWithSuccess:(void(^)(NSString *ssosession))success andError:(void(^)(TTGStatus *status))error;

@end
