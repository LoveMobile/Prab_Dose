//
//  TTGKeepAliveManager.m
//  TTGSignOn
//
//  Created by Niranjan K N on 11/6/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGKeepAliveManager.h"
#import "NSData+TTGMobileBase64.h"
#import "TTGConstants.h"
#import "TTGFetcherJson.h"
#import "TTGFetcherImage.h"
#import "TTGHelper.h"


typedef void (^TTGKeepAliveSuccessBlock)(NSString *ssosession);
typedef void (^TTGKeepAliveErrorBlock)(TTGStatus *status);

@interface TTGKeepAliveManager ()

@property (copy, nonatomic) TTGKeepAliveSuccessBlock successBlock;
@property (copy, nonatomic) TTGKeepAliveErrorBlock errorBlock;
@property (strong, nonatomic) NSString * ssosession;

@end


@implementation TTGKeepAliveManager


#pragma mark - Private methods
#pragma mark - Header body creation methods

- (NSMutableDictionary *)createHeaderParameterDictionaryForWebserviceType:(WebserviceType)webserviceType {
    NSMutableDictionary *headerDictionary = [[NSMutableDictionary alloc] init];
    
    switch (webserviceType) {
        case kWebserviceTypeKeepAlive: {
            // Creating header parameters
            NSString *encodedSsoSession = [self encodeValueByAddingPercentEscapes:self.ssosession];
            NSString *encodedSsoSessionToken = [NSString stringWithFormat:@"%@=%@", kObSSOCookie, encodedSsoSession];
            
            if (encodedSsoSessionToken) {
                [headerDictionary setObject:encodedSsoSessionToken forKey:kCookieKey];
			}

            break;
		}
            
        default:
            break;
    }
    
    return headerDictionary;
}


- (NSMutableDictionary *)createBodyParameterDictionaryWithWebserviceType:(WebserviceType)webserviceType {
    NSMutableDictionary *bodyDictionary = [NSMutableDictionary dictionary];
    return bodyDictionary;
}


#pragma mark - Encoding / Decoding

- (NSString *)encodeValueByAddingPercentEscapes:(NSString *)value {
    NSString *encodedValue = (__bridge_transfer NSString *)
    CFURLCreateStringByAddingPercentEscapes(NULL,
                                            (CFStringRef)value,
                                            NULL,
                                            (CFStringRef)@"!*'\"();:@&=+$,/?%#[]^§°£€ç ",
                                            kCFStringEncodingUTF8);
    return encodedValue;
}


- (NSString *)decodeValueByReplacingPercentEscapes:(NSString *)encodedValue {
    NSString *value = (__bridge_transfer NSString *)
    CFURLCreateStringByReplacingPercentEscapes(NULL,
                                               (CFStringRef)encodedValue,
                                               CFSTR("") /* replace all escapes */
                                               );
    return value;
}


#pragma mark - Service initiation method

- (void)initiateKeepAliveService {
    // Create header and body parameters
    NSDictionary *headerDictionary = [self createHeaderParameterDictionaryForWebserviceType:kWebserviceTypeKeepAlive];
    NSDictionary *bodyDictionary = [self createBodyParameterDictionaryWithWebserviceType:kWebserviceTypeKeepAlive];

    NSString *urlString, *httpMethodType = nil;
    
    urlString = [TTGHelper keepAliveURL];
    
    httpMethodType = kRequestHTTPMethodGet;
    
    // Initialize fetcher image class to initiate signOff service call
    TTGFetcherImage *fetcherImage = [TTGFetcherImage sharedSingleton];
    
    [fetcherImage initiateRequestWithHeaderParameter:headerDictionary bodyParameter:bodyDictionary httpMethodType:httpMethodType urlString:urlString andCompletionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        if (error) {
            NSHTTPURLResponse *httpUrlReponse = (NSHTTPURLResponse *)response;
            
            if (![httpUrlReponse isKindOfClass:[NSNull class]] && [httpUrlReponse statusCode] == 302) {
                // Calling the main thread to perform the operation
                NSMutableDictionary *dataDictionary = [NSMutableDictionary dictionary];
                
                if (data) {
                    [dataDictionary setObject:data forKey:kDictionaryDataKey];
				}
                
                if (response) {
                    [dataDictionary setObject:response forKey:kDictionaryURLResponseKey];
				}
                
                [self performSelectorOnMainThread:@selector(processSuccessData:) withObject:dataDictionary waitUntilDone:NO];
            } else {
                // Calling the main thread to perform the operation
                [self performSelectorOnMainThread:@selector(processFailureError:) withObject:error waitUntilDone:NO];
            }
        } else {
            // Calling the main thread to perform the operation
            NSMutableDictionary *dataDictionary = [NSMutableDictionary dictionary];
            
            if (data) {
                [dataDictionary setObject:data forKey:kDictionaryDataKey];
			}
            
            if (response) {
                [dataDictionary setObject:response forKey:kDictionaryURLResponseKey];
			}
            
            [self performSelectorOnMainThread:@selector(processSuccessData:) withObject:dataDictionary waitUntilDone:NO];
        }
    }];
}


#pragma mark - Response processing method

- (void)processSuccessData:(NSMutableDictionary *)dataDictionary {
	NSData *data = [dataDictionary objectForKey:kDictionaryDataKey];
	NSURLResponse *urlResponse = [dataDictionary objectForKey:kDictionaryURLResponseKey];

	// Printing the repsonse string
	NSString *responseString = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
	LOG("\nResponse Data :\n%@", responseString);

	// Printing the header values
	NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*)urlResponse;

	LOG("\nStatus Code - %ld", (long)[httpResponse statusCode]);

	NSDictionary *dictionary = nil;

	if ([urlResponse respondsToSelector:@selector(allHeaderFields)]) {
		dictionary = [httpResponse allHeaderFields];
		
		LOG("%@",[dictionary description]);
	}
		
	NSHTTPCookie *cookie = nil;
	NSArray *cookieArray = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];

	LOG("\nCookie Array = %@", cookieArray);

	for (NSHTTPCookie * cookieSearch in cookieArray) {
		if ([[cookieSearch name] isEqualToString:kObSSOCookie]) {
			cookie = cookieSearch;
		}
	}

	LOG("\nCookie  = %@", cookie);

	NSString * decodedObSsoSession = [self decodeValueByReplacingPercentEscapes:[cookie value]];

	//Passing the received cookie back to the calling success block
	dispatch_async(dispatch_get_main_queue(), ^{
		if (self.successBlock) {
			self.successBlock(decodedObSsoSession);
		}
	});
}


- (void)processFailureError:(NSDictionary *)errorDictionary {
    // Building error dictionary with status code, error title and error message as keys and corresponding values as objects
    TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:kErrorCodeGenericError];
    
    // Passing the received error back to the calling error block
    dispatch_async(dispatch_get_main_queue(), ^{
		if (self.errorBlock) {
			self.errorBlock(status);
		}
    });
}


#pragma mark - Initialization method

- (id)initWithSsosession:(NSString *)appSsosession {
    if (self = [super init]) {
		self.ssosession = appSsosession;
	}
	
	return self;
}


#pragma mark - Wrapper method

- (void)performKeepAliveWithSuccess:(TTGKeepAliveSuccessBlock)success andError:(TTGKeepAliveErrorBlock)error {
    self.successBlock = success;
    self.errorBlock = error;
    
    if ([self.ssosession length] > 0) {
        // Initiate keep alive service call
        [self initiateKeepAliveService];
    } else {
        TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:kErrorCodeGenericError];
        
        dispatch_async(dispatch_get_main_queue(), ^{
			if (self.errorBlock) {
				self.errorBlock(status);
			}
        });
    }
}


@end
