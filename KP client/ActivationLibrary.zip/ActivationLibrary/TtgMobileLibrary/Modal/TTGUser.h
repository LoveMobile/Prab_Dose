//
//  TTGUser.h
//  TTGMobile
//
//  Created by Sandesh Pujar on 19/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGStatus.h"

@interface TTGUser : TTGStatus

@property (strong, nonatomic) NSString *ssosession;
@property (strong, nonatomic) NSString *guid;
@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSString *region;
@property (strong, nonatomic) NSString *email;
@property (strong, nonatomic) NSString *epicEmail;
@property (strong, nonatomic) NSString *preferredFirstName;
@property (strong, nonatomic) NSString *activationStatusCode;
@property (strong, nonatomic) NSString *disabledReasonCode;
@property (strong, nonatomic) NSString *termsAndConditionAccpeted;
@property (strong, nonatomic) NSString *serviceArea;

@end
