//
//  TTGStatus.h
//  TTGMobile
//
//  Created by Sandesh Pujar on 19/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

@interface TTGStatus : NSObject

@property (strong, nonatomic) NSNumber *statusCode;
@property (strong, nonatomic) NSString *statusTitle;
@property (strong, nonatomic) NSString *statusMessage;

@end
