//
//  TTGUser.m
//  TTGMobile
//
//  Created by Sandesh Pujar on 19/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGUser.h"


@implementation TTGUser

@synthesize ssosession;
@synthesize guid;
@synthesize firstName;
@synthesize lastName;
@synthesize region;
@synthesize email;
@synthesize epicEmail;
@synthesize preferredFirstName;
@synthesize activationStatusCode;
@synthesize disabledReasonCode;
@synthesize termsAndConditionAccpeted;
@synthesize serviceArea;

@end
