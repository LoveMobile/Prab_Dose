//
//  NSData+TTGMobileBase64.h
//  TTGMobile
//
//  Created by Niranjan K N on 11/20/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

@interface NSData (TTGMobileBase64)

+ (NSData *)dataWithBase64EncodedString:(NSString *)string;
- (NSString *)base64EncodedStringWithWrapWidth:(NSUInteger)wrapWidth;
- (NSString *)base64EncodedString;

@end


@interface NSString (TTGMobileBase64)

+ (NSString *)stringWithBase64EncodedString:(NSString *)string;
- (NSString *)base64EncodedStringWithWrapWidth:(NSUInteger)wrapWidth;
- (NSString *)base64EncodedString;
- (NSString *)base64DecodedString;
- (NSData *)base64DecodedData;

@end