//
//  TTGConstants.h
//  TTGSignOn
//
//  Created by Sandesh Pujar on 05/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#ifndef TTGSignOn_Constants_h
#define TTGSignOn_Constants_h

#pragma mark - Tags

#pragma mark SignOn Tags

#define kAccountLocked                              @"accountlocked"
#define kAuthenticationFailed                       @"authenticationfailed"
#define kSystemError                                @"systemError"
#define kBussinessError                             @"businessError"
#define kInterrupt                                  @"interruptList"
#define kUser                                       @"user"
#define kRegion                                     @"region"
#define kMRN                                        @"MRN"
#define kInterruptUnbleToActivateMychartAccount     @"UNABLE_TO_ACTIVATE_MYCHART_ACCOUNT"
#define kGuid                                       @"guid"
#define kFirstName                                  @"firstName"
#define kLastName                                   @"lastName"
#define kEmail                                      @"email"
#define kEpicEmail                                  @"epicEmail"
#define kPreferredFirstName                         @"preferredFirstName"
#define kActivationStatusCode                       @"activationStatusCode"
#define kDisabledReasonCode                         @"disabledReasonCode"
#define kTermsAndConditionAccpeted                  @"termsAndCondAccepted"
#define kServiceArea                                @"serviceArea"

#pragma mark System status Tags

#define kResponse       @"response"
#define kMessage        @"message"
#define kStatusCode     @"statusCode"

#pragma mark Sign off Tags

#define kCorrelationID  @"X-CorrelationID"
#define KCrelationID    @"corelationId"

#pragma mark Keep alive Tags

#define kSetCookie     @"Set-Cookie"

#pragma mark - Application error titles and messages

#define kTitleAuthenticationFail      @"Authorization failed"
#define kMessageAuthenticationFail    @"Authorization failed. Please go to kp.org to activate your account. Your device has been deactivated and your data has been cleared from the device"
#define kTitleLockedOut               @"Locked out"
#define kMessageLockedOut             @"There is a problem with your account. Please go to kp.org for details"
#define kTitleNcalError               @"Error"
#define kMessageNcalError             @"This app is available only to Kaiser Permanente members in Northern California at this time. Your device has been deactivated and your data has been cleared from the device"
#define kTitleGeneralError            @"Error"
#define kMessageGeneralError          @"Your data cannot be retrieved at this time. Please try again later"

#pragma mark - Appication Status Codes

#define kErrorCodeAuthorizationFail   5
#define kErrorCodeTitleLocked_Out     6
#define kErrorCodeNcal                8
#define kErrorCodeGenericError        20

#pragma mark - Appication Error Keys

#define kErrorKeyStatusCode    @"statusCode"
#define kErrorKeyErrorTitle    @"errorTitle"
#define kErrorKeyErrorMessage  @"errorMessage"
#define kErrorKeyError         @"error"

#pragma mark - TTGHelper Tags

#define kEnvironmentName    @"DEV"

#pragma mark - WebServiceType Tags

#define kServiceSystemStatus   @"systemstatus"
#define kServiceSignOn         @"signon"
#define kServiceSignOff        @"signoff"
#define kServiceKeepAlive      @"keepalive"
#define kServiceType           @"webserviceType"


#pragma mark - Request HTTPMethod Titles

#define kRequestHTTPMethodPost     @"POST"
#define kRequestHTTPMethodGet      @"GET"
#define kRequestHTTPMethodDelete   @"DELETE"
#define kRequestHTTPMethodPut      @"PUT"

#pragma mark - Cookie Tags

#define kCookieKey      @"Cookie"
#define kObSSOCookie    @"ObSSOCookie"

#pragma mark - Dictionary Tags

#define kDictionaryDataKey             @"data"
#define kDictionaryURLResponseKey      @"urlResponse"
#define kDictionaryErrorKey            @"error"

#pragma mark - Request header and body parameters

#define kRequestHTTPHeaderValue     @"application/json"
#define kRequestHTTPHeaderField     @"Content-type"

#define kRequestHeaderKeyUserAgentCategory      @"X-useragentcategory"
#define kRequestHeaderKeyOSVersion              @"X-osversion"
#define kRequestHeaderKeyUserAgentType          @"X-useragenttype"
#define kRequestHeaderAPIKey                    @"X-apiKey"
#define kRequestHeaderKeyAppName                @"X-appName"
#define kRequestHeaderKeyssosession             @"ssosession"
#define kRequestHeaderKeyUserID                 @"X-userId"
#define kRequestHeaderKeyAuthorization          @"Authorization"

#define kRequestBodyKeyappID               @"appId"
#define kRequestBodyKeyappVersion          @"appVersion"
#define kRequestBodyKeyOS                  @"os"
#define kRequestBodyKeyOSVersion           @"osVersion"

#endif

#pragma mark - DebugLogs Macro

#ifdef KPLOGGING
#define LOG(fmt, ...) NSLog((@"%s %@"), __PRETTY_FUNCTION__, [NSString stringWithFormat:(@fmt), ##__VA_ARGS__])
#else
#define LOG(fmt, ...)
#endif

