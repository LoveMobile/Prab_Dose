//
//  TTGHelper.m
//  TTGMobile
//
//  Created by Sandesh Pujar on 12/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGHelper.h"
#import "TTGConstants.h"
#import "TTGStatus.h"
#include <objc/message.h>


@implementation TTGHelper


#pragma mark - Private methods

+ (NSString *)environment {
    // Obtain environment name from appdelegate of the consuming application
    //SEL selector = sel_registerName("applicationEnvironment");
    SEL selector = NSSelectorFromString(@"getAppEnvironmentAsString");
    
    NSString *environmentName = nil;
    id applicationDelegate = [[UIApplication sharedApplication] delegate];
    
    if ([applicationDelegate respondsToSelector:selector])
        environmentName = (NSString *)objc_msgSend(applicationDelegate, selector,nil);
    //environmentName = [applicationDelegate performSelector:selector];
    
    // If the environment has not been set by consuming app, forcefully set the environment to dev
    if (!environmentName || [environmentName length] <= 0)
        environmentName = kEnvironmentName;
    
    return environmentName;
}


+ (NSString *)urlStringForEnvironment:(NSString *)environmentName andService:(NSString *)serviceName {
    // Obtain configuration dictionary from Configuration plist
    NSDictionary *configurationDictionary = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"TtgMobileLibrary" ofType:@"plist"]];
    
    // Return url string for the passed environment and service name
    return [[configurationDictionary objectForKey:environmentName] objectForKey:serviceName];
}


#pragma mark - Wrapper methods

+ (NSString *)systemStatusURL {
    return [TTGHelper urlStringForEnvironment:[TTGHelper environment] andService:kServiceSystemStatus];
}


+ (NSString *)signOnURL {
    return [TTGHelper urlStringForEnvironment:[TTGHelper environment] andService:kServiceSignOn];
}


+ (NSString *)signOffURL {
    return [TTGHelper urlStringForEnvironment:[TTGHelper environment] andService:kServiceSignOff];
}


+ (NSString *)keepAliveURL {
    return [TTGHelper urlStringForEnvironment:[TTGHelper environment] andService:kServiceKeepAlive];
}


+ (NSString *)systemVersionString {
	return [NSString stringWithFormat:@"%@", [[UIDevice currentDevice] systemVersion]];
}


+ (NSString *)systemNameString {
	return [NSString stringWithFormat:@"%@", [[UIDevice currentDevice] systemName]];
}


+ (TTGStatus *)statusWithErrorForStatusCode:(NSInteger)statusCode {
    // Building status with status code, error title and error message as keys and corresponding values as objects
    TTGStatus *status = [[TTGStatus alloc] init];
    
    NSString *errorTitle = nil;
    NSString *errorMessage = nil;
    NSNumber *statusCodeNumber = [NSNumber numberWithInteger:statusCode];
    
    switch (statusCode) {
        case 5: {
            errorTitle = kTitleAuthenticationFail;
            errorMessage = kMessageAuthenticationFail;
            break;
		}

        case 6: {
            errorTitle = kTitleLockedOut;
            errorMessage = kMessageLockedOut;
            break;
		}

        case 7: {
            errorTitle = kTitleAuthenticationFail;
            errorMessage = kMessageAuthenticationFail;
            break;
		}

        case 8: {
            errorTitle = kTitleNcalError;
            errorMessage = kMessageNcalError;
            break;
		}

        case kErrorCodeGenericError: {
            errorTitle = kTitleGeneralError;
            errorMessage = kMessageGeneralError;
            break;
		}

        default:
            break;
    }
    
    status.statusCode = statusCodeNumber;
    status.statusTitle = errorTitle;
    status.statusMessage = errorMessage;
    
    return status;
}


@end
