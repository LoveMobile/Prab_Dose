//
//  TTGHelper.h
//  TTGMobile
//
//  Created by Sandesh Pujar on 12/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

@class TTGStatus;

@interface TTGHelper : NSObject

+ (NSString *)systemStatusURL;
+ (NSString *)signOnURL;
+ (NSString *)signOffURL;
+ (NSString *)keepAliveURL;
+ (NSString *)systemVersionString;
+ (NSString *)systemNameString;
+ (TTGStatus *)statusWithErrorForStatusCode:(NSInteger)statusCode;

@end
