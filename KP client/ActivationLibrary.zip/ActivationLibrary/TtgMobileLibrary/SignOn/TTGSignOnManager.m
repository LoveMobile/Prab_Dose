//
//  TTGSignOnManager.m
//  TTGSignOn
//
//  Created by Sandesh Pujar on 30/10/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGSignOnManager.h"
#import "NSData+TTGMobileBase64.h"
#import "TTGConstants.h"
#import "TTGFetcherJson.h"
#import "TTGHelper.h"
#import "TTGUser.h"


typedef void (^TTGSignOnSuccessBlock)(TTGUser *user);
typedef void (^TTGSignOnErrorBlock)(TTGStatus *status);

@interface TTGSignOnManager ()

@property (copy, nonatomic) TTGSignOnSuccessBlock successBlock;
@property (copy, nonatomic) TTGSignOnErrorBlock failureBlock;
@property (strong, nonatomic) NSString *username;
@property (strong, nonatomic) NSString *password;
@property (strong, nonatomic) NSString *region;
@property (strong, nonatomic) NSString *apiKey;
@property (strong, nonatomic) NSString *appID;
@property (strong, nonatomic) NSString *appName;
@property (strong, nonatomic) NSString *appVersion;

@end


@implementation TTGSignOnManager


#pragma mark - Private methods
#pragma mark - General methods

- (NSInteger)applicationStatusCodeForResponse:(NSDictionary *)responseDictionary {
	NSInteger appStatusCode = 0;

	// If account locked is there and true and if user is null, status code = 6
	if ([responseDictionary objectForKey:kAccountLocked] && [[responseDictionary objectForKey:kAccountLocked] boolValue] == true && ![responseDictionary objectForKey:kUser]) {
		appStatusCode = 6;
	}

	// If authentication failed is there are true and if user is null, status code = 5
	else if ([responseDictionary objectForKey:kAuthenticationFailed] && [[responseDictionary objectForKey:kAuthenticationFailed] boolValue] == true && ![responseDictionary objectForKey:kUser]) {
		appStatusCode = 5;
	}

	// If system error is there and not null, status code = 20
	else if ([responseDictionary objectForKey:kSystemError] && [responseDictionary objectForKey:kSystemError] != [NSNull null]) {
		appStatusCode = kErrorCodeGenericError;
	}

	// If user is not null
	else if ([responseDictionary objectForKey:kUser] && [responseDictionary objectForKey:kUser] != [NSNull null]) {
		// Obtaining dictionary from User tag
		NSDictionary *userDictionary = [responseDictionary objectForKey:kUser];
		
		// If region is not the region passed by client, status code = 8
		if (![[userDictionary objectForKey:kRegion] isEqualToString:self.region]) {
			appStatusCode = 8;
		}
		
		// If system error is there and it is null and if business error is there and it is null
		else if ([responseDictionary objectForKey:kSystemError] && [responseDictionary objectForKey:kSystemError] == [NSNull null] && [responseDictionary objectForKey:kBussinessError] && [responseDictionary objectForKey:kBussinessError] == [NSNull null]) {
			
			// if interrupt error is there and it is NOT null
			if ([responseDictionary objectForKey:kInterrupt] && [responseDictionary objectForKey:kInterrupt] != [NSNull null]) {
				// Obtaining interrupt array from interrupt tag
				NSArray *interruptArray = [responseDictionary objectForKey:kInterrupt];
				
				// If interrupt array contains UNABLE_TO_ACTIVATE_MYCHART_ACCOUNT, status code = 7
				if ([interruptArray containsObject:kInterruptUnbleToActivateMychartAccount]) {
					appStatusCode = 7;
				} else {
					appStatusCode = 0;
				}
			} else {
				// Else, status code = 0
				appStatusCode = 0;
			}
		}
		
		// If business error and it is not null, status code = 7
		else if ([responseDictionary objectForKey:kBussinessError] && [responseDictionary objectForKey:kBussinessError] != NULL) {
			appStatusCode = 7;
		} else {
			appStatusCode = kErrorCodeGenericError;
		}
	}

	return appStatusCode;
}


- (NSString *)ssosessionForURLResponse:(NSURLResponse *)urlResponse {
    // Obtaining first the header field dictionary from httpResponse and obtaining value of ssosession from dictionary
    NSString *ssosession = nil;
    
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*)urlResponse;
    
	if ([urlResponse respondsToSelector:@selector(allHeaderFields)]) {
		NSDictionary *dictionary = [httpResponse allHeaderFields];
		
        LOG("\nHttp Header values :\n%@", [dictionary description]);
        
        ssosession = [dictionary objectForKey:kRequestHeaderKeyssosession];
	}
    
    return ssosession;
}


- (NSDictionary *)dictionaryWithDataForResponse:(NSDictionary *)responseData andSsosession:(NSString *)ssosession {
    // Building success data dictionary containing ssosession and User values as keys and corresponding values as objects
    NSMutableDictionary *resultDictionary = [NSMutableDictionary dictionary];
    
    if (ssosession) {
        [resultDictionary setObject:ssosession forKey:kRequestHeaderKeyssosession];
	}
    
    if ([responseData objectForKey:kUser]) {
        [resultDictionary setObject:[responseData objectForKey:kUser] forKey:kUser];
	}
    
    return resultDictionary;
}


- (TTGUser *)userObjectForResponse:(NSDictionary *)responseData andSsoSession:(NSString *)ssosession {
    TTGUser *user = [[TTGUser alloc] init];
    
    user.statusCode = [NSNumber numberWithInteger:0];
    user.statusTitle = @"Success";
    user.statusMessage = @"Success";
    user.ssosession = ssosession;
    user.guid = [[responseData objectForKey:kUser] objectForKey:kGuid];
    user.firstName = [[responseData objectForKey:kUser] objectForKey:kFirstName];
    user.lastName = [[responseData objectForKey:kUser] objectForKey:kLastName];
    user.region = [[responseData objectForKey:kUser] objectForKey:kRegion];
    user.email = [[responseData objectForKey:kUser] objectForKey:kEmail];
    user.epicEmail = [[responseData objectForKey:kUser] objectForKey:kEpicEmail];
    user.preferredFirstName = [[responseData objectForKey:kUser] objectForKey:kPreferredFirstName];
    user.activationStatusCode = [[responseData objectForKey:kUser] objectForKey:kActivationStatusCode];
    user.disabledReasonCode = [[responseData objectForKey:kUser] objectForKey:kDisabledReasonCode];
    user.termsAndConditionAccpeted = [[responseData objectForKey:kUser] objectForKey:kTermsAndConditionAccpeted];
    user.serviceArea = [[responseData objectForKey:kUser] objectForKey:kServiceArea];
    
    return user;
}


#pragma mark - Header body creation methods

- (NSMutableDictionary *)createHeaderParameterDictionaryForWebserviceType:(WebserviceType)webserviceType {
    NSMutableDictionary *headerDictionary = [[NSMutableDictionary alloc] init];
    
    switch (webserviceType) {
        case kWebserviceTypeSystemStatus: {
            break;
		}
            
        case kWebserviceTypeSignOn: {
            // Creating header parameters
            [headerDictionary setObject:@"I" forKey:kRequestHeaderKeyUserAgentCategory];
            [headerDictionary setObject:[NSString stringWithFormat:@"%@", [[UIDevice currentDevice] systemVersion]] forKey:kRequestHeaderKeyOSVersion];
            [headerDictionary setObject:@"iPhone" forKey:kRequestHeaderKeyUserAgentType];
            [headerDictionary setObject:[NSString stringWithFormat:@"%@", self.apiKey] forKey:kRequestHeaderAPIKey];
            [headerDictionary setObject:[NSString stringWithFormat:@"%@", self.appName] forKey:kRequestHeaderKeyAppName];
            [headerDictionary setObject:[NSString stringWithFormat:@"%@", self.username] forKey:kRequestHeaderKeyUserID];
            
            // Creating a plaintext string in the format username:password
            NSString * loginString = [NSString stringWithFormat:@"%@:%@", self.username, self.password];
            
            // Employing the Base64 encoding above to encode the authentication tokens
            NSData *encodedLoginData = [loginString dataUsingEncoding:NSASCIIStringEncoding];
            
            // Creating the contents of the header
            NSString *authHeader = [NSString stringWithFormat:@"Basic %@", [encodedLoginData base64EncodedStringWithWrapWidth:80]];
            
            if (authHeader) {
                [headerDictionary setObject:authHeader forKey:kRequestHeaderKeyAuthorization];
			}

            break;
		}
            
        default:
            break;
    }
    
    return headerDictionary;
}


- (NSMutableDictionary *)createBodyParameterDictionaryWithWebserviceType:(WebserviceType)webserviceType {
    NSMutableDictionary *bodyDictionary = [NSMutableDictionary dictionary];
    
    switch (webserviceType) {
        case kWebserviceTypeSystemStatus: {
            // Setting body parameters
            [bodyDictionary setValue:self.appID forKey:kRequestBodyKeyappID];
            [bodyDictionary setValue:self.appVersion forKey:kRequestBodyKeyappVersion];
            [bodyDictionary setValue:[TTGHelper systemNameString] forKey:kRequestBodyKeyOS];
            [bodyDictionary setValue:[TTGHelper systemVersionString] forKey:kRequestBodyKeyOSVersion];
            break;
		}

        case kWebserviceTypeSignOn: {
			break;
		}
            
        default:
            break;
    }
    
    return bodyDictionary;
}


#pragma mark - Service initiation methods

- (void)initiateSystemStatusService {
    // Create header and body parameters
    NSDictionary *headerDictionary = [self createHeaderParameterDictionaryForWebserviceType:kWebserviceTypeSystemStatus];
    NSDictionary *bodyDictionary = [self createBodyParameterDictionaryWithWebserviceType:kWebserviceTypeSystemStatus];
    
    NSString *urlString, *httpMethodType = nil;
    
    urlString = [TTGHelper systemStatusURL];

    httpMethodType = kRequestHTTPMethodPost;
    
    // If url string is obtained successfully, do further operations, else return an error block to the calling class
    if ([urlString length] > 0) {
        // Initialize fetcher json class to initiate status code service call
        TTGFetcherJson *fetcherJson = [TTGFetcherJson sharedSingleton];
        fetcherJson.webserviceType = kWebserviceTypeSystemStatus;
        
        [fetcherJson initiateRequestWithHeaderParameter:headerDictionary bodyParameter:bodyDictionary httpMethodType:httpMethodType urlString:urlString andCompletionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
            
            if (error) {
                [self performSelectorOnMainThread:@selector(processFailureError:) withObject:nil waitUntilDone:NO];
            } else {
                // Calling the main thread to perform the operation
                NSMutableDictionary *dataDictionary = [NSMutableDictionary dictionary];
                
                if (data) {
                    [dataDictionary setObject:data forKey:kDictionaryDataKey];
				}
                
                if (response) {
                    [dataDictionary setObject:response forKey:kDictionaryURLResponseKey];
				}
                
                switch (fetcherJson.webserviceType) {
                    case kWebserviceTypeSystemStatus: {
                        [dataDictionary setObject:kServiceSystemStatus forKey:kServiceType];
                        break;
					}
						
                    case kWebserviceTypeSignOn: {
                        [dataDictionary setObject:kServiceSignOn forKey:kServiceType];
                        break;
					}

                    default:
                        break;
                }
                
                [self performSelectorOnMainThread:@selector(processSuccessData:) withObject:dataDictionary waitUntilDone:NO];
            }
        }];
    }
    
    // Right now returning a generic error
    else {
        TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:kErrorCodeGenericError];
		if (self.failureBlock) {
			self.failureBlock(status);
		}
    }
}


- (void)initiateSignOnService {
    // Create header and body parameters
    NSDictionary *headerDictionary = [self createHeaderParameterDictionaryForWebserviceType:kWebserviceTypeSignOn];
    NSDictionary *bodyDictionary = [self createBodyParameterDictionaryWithWebserviceType:kWebserviceTypeSignOn];
    
    NSString *urlString, *httpMethodType = nil;
    
    urlString = [TTGHelper signOnURL];
    
    httpMethodType = kRequestHTTPMethodPut;
    
    // If url string is obtained successfully, do further operations, else return an error block to the calling class
    if ([urlString length] > 0) {
        // Initialize fetcher json class to initiate signOn service call
        TTGFetcherJson *fetcherJson = [TTGFetcherJson sharedSingleton];
        fetcherJson.webserviceType = kWebserviceTypeSignOn;
        
        [fetcherJson initiateRequestWithHeaderParameter:headerDictionary bodyParameter:bodyDictionary httpMethodType:httpMethodType urlString:urlString andCompletionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
            
            if (error) {
                NSMutableDictionary *errorDictionary = [NSMutableDictionary dictionary];
                
                if (response) {
                    [errorDictionary setObject:response forKey:kDictionaryURLResponseKey];
				}
                
                if (data) {
                    [errorDictionary setObject:data forKey:kDictionaryDataKey];
				}
                
                if (error) {
                    [errorDictionary setObject:error forKey:kDictionaryErrorKey];
				}
                
                [self performSelectorOnMainThread:@selector(processFailureError:) withObject:errorDictionary waitUntilDone:NO];
            } else {
                // Calling the main thread to perform the operation
                NSMutableDictionary *dataDictionary = [NSMutableDictionary dictionary];
                
                if (data) {
                    [dataDictionary setObject:data forKey:kDictionaryDataKey];
				}
                
                if (response) {
                    [dataDictionary setObject:response forKey:kDictionaryURLResponseKey];
				}
                
                switch (fetcherJson.webserviceType) {
                    case kWebserviceTypeSystemStatus: {
                        [dataDictionary setObject:kServiceSystemStatus forKey:kServiceType];
                        break;
					}

                    case kWebserviceTypeSignOn: {
                        [dataDictionary setObject:kServiceSignOn forKey:kServiceType];
                        break;
					}

                    default:
                        break;
                }
                
                [self performSelectorOnMainThread:@selector(processSuccessData:) withObject:dataDictionary waitUntilDone:NO];
            }
        }];
    } else {
        TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:kErrorCodeGenericError];
        
		if (self.failureBlock) {
			self.failureBlock(status);
		}
    }
}


#pragma mark - Response processing methods

- (void)processSuccessData:(NSMutableDictionary *)dataDictionary {
    NSData *data = [dataDictionary objectForKey:kDictionaryDataKey];
    NSURLResponse *urlResponse = [dataDictionary objectForKey:kDictionaryURLResponseKey];
    NSString *webserviceType = [dataDictionary objectForKey:kServiceType];
    
    // Printing the repsonse string
    NSString *responseString = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
    LOG("\nResponse Data :\n%@", responseString);
    
    // Printing the header values
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*)urlResponse;
    
	if ([urlResponse respondsToSelector:@selector(allHeaderFields)]) {
		NSDictionary *dictionary = [httpResponse allHeaderFields];
		
        LOG("\nHttp Header values :\n%@", [dictionary description]);
	}
    
    // Parsing the data
    NSError *parsingError = nil;
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&parsingError];
    TTGUser *user = nil;
    
    if (!parsingError) {
        // Printing the data
        LOG("\nParsed Data :\n%@", [responseDictionary description]);
        
        if ([webserviceType isEqualToString:kServiceSystemStatus]) {
            NSInteger statusCode = [[[responseDictionary objectForKey:kResponse] objectForKey:kStatusCode] integerValue];
            
            if (statusCode == 0) {
                // Initiate the SignOn service call
                [self initiateSignOnService];
            } else {
                // Return error
                NSMutableDictionary *resultDictionary = [NSMutableDictionary dictionary];
                
                [resultDictionary setValue:[NSNumber numberWithInteger:statusCode] forKey:kErrorKeyStatusCode];
                [resultDictionary setObject:kErrorKeyError forKey:kErrorKeyErrorTitle];
                
                if ([[responseDictionary objectForKey:kResponse] objectForKey:kMessage]) {
                    [resultDictionary setObject:[[responseDictionary objectForKey:kResponse] objectForKey:kMessage] forKey:kErrorKeyErrorMessage];
				}
            }
        } else if ([webserviceType isEqualToString:kServiceSignOn]) {
            // Calling method to decide that status code basd on some conditions
            NSInteger appStatusCode = [self applicationStatusCodeForResponse:responseDictionary];
            
            // If status code is 0, then it is SUCCESS, else for any other status code, it is FAILURE
            if (appStatusCode == 0) {
                
                // Obtaining ssosession from the NSURLResponse
                NSString *ssosession = [self ssosessionForURLResponse:urlResponse];
                
                // Obtaining the constructed dictionary object that needs to be returned to the consuming class
                user = [self userObjectForResponse:responseDictionary andSsoSession:ssosession];
                
                // Passing the response dictionary back to the calling success block
                dispatch_async(dispatch_get_main_queue(), ^{
					if (self.successBlock) {
						self.successBlock(user);
					}
                });
            } else {
                // Obtaining the constructed dictionary object
                TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:appStatusCode];
                
                // Passing the erro back to the calling error block
                dispatch_async(dispatch_get_main_queue(), ^{
					if (self.failureBlock) {
						self.failureBlock(status);
					}
                });
            }
        }
    } else {
        // Obtaining the constructed dictionary object
        TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:kErrorCodeGenericError];
        
        // Passing the error back to the calling error block
        dispatch_async(dispatch_get_main_queue(), ^{
			if (self.failureBlock) {
				self.failureBlock(status);
			}
        });
    }
}


- (void)processFailureError:(NSDictionary *)errorDictionary {
    NSData *data = [NSData data];
    NSError *error = nil;
    
    if ([errorDictionary objectForKey:kDictionaryDataKey]) {
        data = [errorDictionary objectForKey:kDictionaryDataKey];
	}
    
    if ([errorDictionary objectForKey:kDictionaryErrorKey]) {
        error = [errorDictionary objectForKey:kDictionaryErrorKey];
	}
    
    NSDictionary *responseDictionary = nil;
    TTGStatus *status = nil;
    
    // If 401, and data is empty, status code = 5, else if data is there, status code = 6
    // If not 401, send generic error code
    if ([error code] == 401 || [error code] == -1012) {
        if (data) {
            NSError *parsingError = nil;
            responseDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&parsingError];
            
            if (parsingError) {
                NSInteger statusCode = [self applicationStatusCodeForResponse:responseDictionary];
                status = [TTGHelper statusWithErrorForStatusCode:statusCode];
                
				if (self.failureBlock) {
					self.failureBlock(status);
				}
            } else {
                NSInteger statusCode = [self applicationStatusCodeForResponse:responseDictionary];
                status = [TTGHelper statusWithErrorForStatusCode:statusCode];
            }
        } else {
            status = [TTGHelper statusWithErrorForStatusCode:5];
        }
    } else {
		status = [TTGHelper statusWithErrorForStatusCode:kErrorCodeGenericError];
    }
    
	if (self.failureBlock) {
		self.failureBlock(status);
	}
}


#pragma mark - Initialization method

- (id)initWithUsername:(NSString *)memberUsername password:(NSString *)memberPassword region:(NSString *)memberRegion apiKey:(NSString *)applicationApiKey appID:(NSString *)applicationID appName:(NSString *)applicationName andAppVersion:(NSString *)applicationVersion {
    if (self = [super init]) {
		self.username = memberUsername;
        self.password = memberPassword;
        self.region = memberRegion;
        self.apiKey = applicationApiKey;
        self.appID = applicationID;
        self.appName = applicationName;
        self.appVersion = applicationVersion;
	}
	
	return self;
}


#pragma mark - Wrapper method

- (void)performSignOnWithSuccess:(TTGSignOnSuccessBlock)success andError:(TTGSignOnErrorBlock)error
{
    self.successBlock = success;
    self.failureBlock = error;
    
    if (([self.username length] > 0)&&([self.password length] > 0)&&([self.region length] > 0) && ([self.apiKey length] > 0) && ([self.appID length] > 0) && ([self.appName length] > 0)&& ([self.appVersion length] > 0)) {
        // Initiate the Status Code service call
        [self initiateSystemStatusService];
    } else {
        TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:kErrorCodeGenericError];
        
        dispatch_async(dispatch_get_main_queue(), ^{
			if (self.failureBlock) {
				self.failureBlock(status);
			}
        });
    }
}


@end
