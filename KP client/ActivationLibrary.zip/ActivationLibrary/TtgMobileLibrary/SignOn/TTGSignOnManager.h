//
//  TTGSignOnManager.h
//  TTGSignOn
//
//  Created by Sandesh Pujar on 30/10/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

@class TTGUser, TTGStatus;

@interface TTGSignOnManager : NSObject 

- (id)initWithUsername:(NSString *)memberUsername password:(NSString *)memberPassword region:(NSString *)memberRegion apiKey:(NSString *)applicationApiKey appID:(NSString *)applicationID appName:(NSString *)applicationName andAppVersion:(NSString *)applicationVersion;

- (void)performSignOnWithSuccess:(void(^)(TTGUser *user))success andError:(void(^)(TTGStatus *status))error;

@end
