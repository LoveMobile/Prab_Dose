//
//  TTGSignOffManager.h
//  TTGSignOn
//
//  Created by Sandesh Pujar on 06/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

@class TTGStatus;

@interface TTGSignOffManager : NSObject

- (id)initWithSsosession:(NSString *)applicationSsosession apiKey:(NSString *)applicationApiKey andAppName:(NSString *)applicationName;
- (void)performSignOffWithSuccess:(void(^)(NSDictionary* dataDictionary))success andError:(void(^)(TTGStatus *status))error;

@end

