//
//  TTGSignOffManager.m
//  TTGSignOn
//
//  Created by Sandesh Pujar on 06/11/13.
//  Copyright (c) 2013 Sandesh Pujar. All rights reserved.
//

#import "TTGSignOffManager.h"
#import "TTGConstants.h"
#import "TTGFetcherJson.h"
#import "TTGHelper.h"
#import "TTGStatus.h"


typedef void (^TTGSignOffSuccessBlock)(NSDictionary *dataDictionary);
typedef void (^TTGSignOffErrorBlock)(TTGStatus *status);

@interface TTGSignOffManager ()

@property (copy, nonatomic) TTGSignOffSuccessBlock successBlock;
@property (copy, nonatomic) TTGSignOffErrorBlock errorBlock;
@property (strong, nonatomic) NSString *ssosession;
@property (strong, nonatomic) NSString *apiKey;
@property (strong, nonatomic) NSString *appName;

@end


@implementation TTGSignOffManager


#pragma mark - Private methods
#pragma mark - Header body creation methods

- (NSMutableDictionary *)createHeaderParameterDictionaryForWebserviceType:(WebserviceType)webserviceType {
    NSMutableDictionary *headerDictionary = [[NSMutableDictionary alloc] init];
    
    switch (webserviceType) {
        case kWebserviceTypeSignOff: {
            // Creating header parameters
            [headerDictionary setObject:@"I" forKey:kRequestHeaderKeyUserAgentCategory];
            [headerDictionary setObject:[NSString stringWithFormat:@"%@", [[UIDevice currentDevice] systemVersion]] forKey:kRequestHeaderKeyOSVersion];
            [headerDictionary setObject:@"iPhone" forKey:kRequestHeaderKeyUserAgentType];
            [headerDictionary setObject:[NSString stringWithFormat:@"%@", self.apiKey] forKey:kRequestHeaderAPIKey];
            [headerDictionary setObject:[NSString stringWithFormat:@"%@", self.appName] forKey:kRequestHeaderKeyAppName];
            [headerDictionary setObject:self.ssosession forKey:kRequestHeaderKeyssosession];
            break;
		}
            
        default:
            break;
    }
    
    return headerDictionary;
}


- (NSMutableDictionary *)createBodyParameterDictionaryWithWebserviceType:(WebserviceType)webserviceType {
    NSMutableDictionary *bodyDictionary = [NSMutableDictionary dictionary];
	return bodyDictionary;
}


#pragma mark - Service initiation method

- (void)initiateSignOffService {
    // Create header and body parameters
    NSDictionary *headerDictionary = [self createHeaderParameterDictionaryForWebserviceType:kWebserviceTypeSignOff];
    NSDictionary *bodyDictionary = [self createBodyParameterDictionaryWithWebserviceType:kWebserviceTypeSignOff];
    
    NSString *urlString, *httpMethodType = nil;

    urlString = [TTGHelper signOffURL];
    
    httpMethodType = kRequestHTTPMethodDelete;
    
    // Initialize fetcher json class to initiate signOff service call
    TTGFetcherJson *fetcherJson = [TTGFetcherJson sharedSingleton];
    fetcherJson.webserviceType = kWebserviceTypeSignOff;
    
    [fetcherJson initiateRequestWithHeaderParameter:headerDictionary bodyParameter:bodyDictionary httpMethodType:httpMethodType urlString:urlString andCompletionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        if (error) {
            // Calling the main thread to perform the operation
            [self performSelectorOnMainThread:@selector(processFailureError:) withObject:error waitUntilDone:NO];
        } else {
            // Calling the main thread to perform the operation
            NSMutableDictionary *dataDictionary = [NSMutableDictionary dictionary];
            
            if (data) {
                [dataDictionary setObject:data forKey:kDictionaryDataKey];
			}
            
            if (response) {
                [dataDictionary setObject:response forKey:kDictionaryURLResponseKey];
			}
            
            switch (fetcherJson.webserviceType) {
                case kWebserviceTypeSignOff: {
                    [dataDictionary setObject:kServiceSignOff forKey:kServiceType];
                    break;
				}
				
                default:
                    break;
            }
            
            [self performSelectorOnMainThread:@selector(processSuccessData:) withObject:dataDictionary waitUntilDone:NO];
        }
    }];
}


#pragma mark - Response process methods

- (void)processSuccessData:(NSMutableDictionary *)dataDictionary {
    NSData *data = [dataDictionary objectForKey:kDictionaryDataKey];
    NSURLResponse *urlResponse = [dataDictionary objectForKey:kDictionaryURLResponseKey];
    
    NSString *corelationId = nil;
    
    // Printing the repsonse string
    NSString *responseString = [[NSString alloc] initWithBytes: [data bytes] length:[data length] encoding:NSUTF8StringEncoding];
    LOG("\nResponse Data :\n%@", responseString);
    
    // Printing the header values
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*)urlResponse;
    
	if ([urlResponse respondsToSelector:@selector(allHeaderFields)]) {
		NSDictionary *dictionary = [httpResponse allHeaderFields];
		
        LOG("\nHttp Header values :\n%@", [dictionary description]);
        
        corelationId = [dictionary objectForKey:kCorrelationID];
	}
    
    if (corelationId && [corelationId length] > 0) {
        // Building success data dictionary containing ssosession and User values as keys and corresponding values as objects
        NSMutableDictionary *resultDictionary = [NSMutableDictionary dictionary];
        
        [resultDictionary setObject:corelationId forKey:KCrelationID];
        
        // Passing the received result dictionary back to the calling success block
        dispatch_async(dispatch_get_main_queue(), ^{
			if (self.successBlock) {
				self.successBlock(resultDictionary);
			}
        });
    } else {
        // Building error dictionary with status code, error title and error message as keys and corresponding values as objects
        TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:20];
        
        // Passing the received error back to the calling error block
        dispatch_async(dispatch_get_main_queue(), ^{
			if (self.errorBlock) {
				self.errorBlock(status);
			}
        });
    }
}


- (void)processFailureError:(NSDictionary *)errorDictionary
{
    // Building error dictionary with status code, error title and error message as keys and corresponding values as objects
    TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:kErrorCodeGenericError];
    
    // Passing the received error back to the calling error block
    dispatch_async(dispatch_get_main_queue(), ^{
        self.errorBlock(status);
    });
}


#pragma mark - Initialization method

- (id)initWithSsosession:(NSString *)applicationSsosession apiKey:(NSString *)applicationApiKey andAppName:(NSString *)applicationName
{
    if (self = [super init]) {
		self.ssosession = applicationSsosession;
        self.apiKey = applicationApiKey;
        self.appName = applicationName;
	}
	
	return self;
}


#pragma mark - Wrapper method

- (void)performSignOffWithSuccess:(TTGSignOffSuccessBlock)success andError:(TTGSignOffErrorBlock)error
{
    self.successBlock = success;
    self.errorBlock = error;
    
    if (([self.ssosession length] > 0) && ([self.apiKey length] > 0 ) && ([self.appName length] > 0)) {
        // Initiate sign off service call
        [self initiateSignOffService];
    } else {
        TTGStatus *status = [TTGHelper statusWithErrorForStatusCode:kErrorCodeGenericError];
        
        dispatch_async(dispatch_get_main_queue(), ^{
			if (self.errorBlock) {
				self.errorBlock(status);
			}
        });
    }
}


@end
