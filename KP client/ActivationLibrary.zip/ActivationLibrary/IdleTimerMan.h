//
//  IdleTimerMan.h
//  MobileCare
//
//  Created by Surya Pasula on 7/15/11.
//  Copyright 2011 TPMG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MobileCareAppDelegate.h"

#define kMaxIdleTimeInterval 900

@interface IdleTimerMan : NSObject <MobileCareAppDelegateDelegate> {
    
}

@property (nonatomic, retain) NSTimer *idleTimer;
@property (assign) BOOL passCodeActive;
@property (assign) BOOL changePasscodeActive;

+ (IdleTimerMan *) get;

- (void) killTimer;
- (void) resetIdleTimer;
- (void) merlinClosed;

@end
