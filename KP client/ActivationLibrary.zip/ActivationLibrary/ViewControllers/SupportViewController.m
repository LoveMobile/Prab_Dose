//
//  SupportViewController.m
//  MobileCare
//
//  Created by Surya Pasula on 7/12/11.
//  Copyright 2011 TPMG. All rights reserved.
//

#import "SupportViewController.h"
#import "WebServiceMan.h"
#import "AuthorizationMan.h"
#import "Utilities.h"
#import "Constants.h"

@implementation SupportViewController
@synthesize phoneHandler;

- (void)pop
{
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"_fromLandingView"]) {
        [self.navigationController popViewControllerAnimated:YES];
        [Utilities getAppDel].tabBarController.selectedIndex = 0;
        [Utilities action_TransitionFromLeft];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    self.phoneHandler = nil;
}

- (void)dealloc
{
    self.phoneHandler=nil;
    [super dealloc];
}

-(void)viewWillAppear:(BOOL)animated{
    
    // Google Analyser
    [Utilities postGATrackPageName:@"SupportViewClicked"];
    
    if (int_showMessage == 1) {
        int_showMessage = 0;
        [[Utilities getAppDel] hideMessage];
    }
    
    if (self.networkError) {
       // [[Utilities getAppDel].m_msgVC show]; 
        [self loadWebView];
    }
    
}

// Load the UIWebView using the configured mode
- (void)loadWebView
{
    
    
    if (int_showMessage == 1) {
        int_showMessage = 0;
        [[Utilities getAppDel] hideMessage];
    }
    UIImage* image3 = [UIImage imageNamed:@"icon_bkgd_back-arow.png"];
    CGRect frameimg = CGRectMake(0, 0, 40, 30);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(pop)
         forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *m_barSomeButton = [[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem = m_barSomeButton;
    [m_barSomeButton release];
    [someButton release];
    
    UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]];
	self.view.backgroundColor = background;
    [background release];
    
    //m_webView.dataDetectorTypes = 0;
    WebServiceMan* wsm = [WebServiceMan get];
    
    NSString *urlString = [NSString stringWithFormat:@"%@/%@%@", 
                           wsm.wsBaseUrl,
                           @"getAppSupport?appId=", wsm.appId];
    LOG("The support page URL is: %@", urlString);
    
	NSURL *url = [NSURL URLWithString:urlString];
    
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    self.curRequest=request;
	[self.m_webView loadRequest:request];
}




- (BOOL)webView:(UIWebView *)webView2 shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType 
{
    BOOL ret=YES;
    
    NSURL *url=[request URL];
    NSString *schemeStr=[url scheme];
    NSString *fullStr=[url absoluteString];
    
    
    if ([schemeStr isEqualToString:@"mailto"]) {
        NSString *recipient=[fullStr substringFromIndex:7];
        NSArray *recipients=[NSArray arrayWithObject:recipient];
        LOG("receipient: %@", recipients);
        if ([MFMailComposeViewController canSendMail])
        {
            [self displayComposerSheet:recipients];
        }
        else
        {
            [self launchMailAppOnDevice:recipient];
        }
        return NO;
    } else if ([schemeStr isEqualToString:@"tel"]) {
		NSRange theRange = [fullStr rangeOfString:@"tel:"];
		NSUInteger anIndex = theRange.location + theRange.length;
		NSString *thePhoneNumber = [fullStr substringFromIndex:anIndex];
		
		self.phoneHandler = [[PhoneLinkHandler alloc] init];
		[self.phoneHandler showPhoneAlertWithPhoneNum:thePhoneNumber];
		return NO;
	}

    
    ret=[super webView:webView2 shouldStartLoadWithRequest:request navigationType:navigationType];
    
    return ret;
}

@end
