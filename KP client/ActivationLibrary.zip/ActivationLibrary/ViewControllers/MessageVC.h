//
//  MessageVC.h
//  ActivationLibrary
//
//  Created by Zhanquan He on 9/10/12.
//  Copyright (c) 2012 Kaiser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageVC : UIViewController

@property (nonatomic, retain) IBOutlet UILabel * m_lblMessage;
@property (nonatomic, retain) IBOutlet UIButton * m_btnRetry;

- (void) show;
- (void) hide;
- (void) showMessage:(NSString*)szMessage withButtonText:(NSString*)btText target:(id)t andSelector:(SEL)sel;
- (void) showMessage:(NSString*)szMessage withButtonText:(NSString*)btText;
- (void) showMessage:(NSString*)szMessage;

@end
