//
//  SignInHelpViewController.h
//  ActivationLibrary
//
//  Created by Zhanquan He on 10/2/13.
//
//

#import <UIKit/UIKit.h>
#import "PhoneLinkHandler.h"

@interface SignInHelpViewController : UIViewController

@property (nonatomic, strong) PhoneLinkHandler *phoneHandler;

-(IBAction)action_RegisterHelp:(id)sender;

-(IBAction)action_ForgotUserIdHelp:(id)sender;

-(IBAction)action_ForgotPasswordHelp:(id)sender;

-(IBAction)action_CallForAssistanceHelp:(id)sender;

@end
