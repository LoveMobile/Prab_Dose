//
//  VCActivityIndicator.h
//
//  Created by Paul on 9/27/10.
//  Copyright 2010 Paiego. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "TextMessage.h"

@interface VCActivityIndicator : UIViewController 
{
	NSString* m_szText;
	UILabel* m_lbText;
	UIButton* m_btBackground;
	UIActivityIndicatorView* m_ai;
    
	BOOL m_bShowing;
}

@property (nonatomic, retain) NSString* m_szText;
@property (nonatomic, retain) IBOutlet UILabel* m_lbText;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView* m_ai;
@property (nonatomic, retain) IBOutlet UIButton* m_btBackground;

- (id)init;
- (id)initWithText:(NSString*)szText;
- (void)setText:(NSString*)szText;
- (void)show;
- (void)showWithoutBackground;
- (void)hide;
- (void)hideWithNoAnimation;
- (void)drawText;

@end
