//
//  SignInHelpViewController.m
//  ActivationLibrary
//
//  Created by Zhanquan He on 10/2/13.
//
//

#import "SignInHelpViewController.h"

@interface SignInHelpViewController ()

@end

@implementation SignInHelpViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)pop
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    /*
    UIImage* image2 = [UIImage imageNamed:@"bar_button_blue.png"];
    CGRect frameimg2 = CGRectMake(0, 0, 70, 30);
    UIButton *someButton2 = [[UIButton alloc] initWithFrame:frameimg2];
    [someButton2 setTitle:@"Done" forState:UIControlStateNormal];
    [someButton2.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12]];
    [someButton2 setBackgroundImage:image2 forState:UIControlStateNormal];
    [someButton2 addTarget:self action:@selector(clickDone:)
          forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *m_barSomeButton2 = [[UIBarButtonItem alloc] initWithCustomView:someButton2];
    self.navigationItem.rightBarButtonItem = m_barSomeButton2;
     */
    UIImage* image3 = [UIImage imageNamed:@"icon_bkgd_back-arow.png"];
    CGRect frameimg = CGRectMake(0, 0, 40, 30);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(pop)
         forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *m_barSomeButton = [[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem = m_barSomeButton;
    
    self.navigationItem.title=@"Sign In Help";
}

-(IBAction)action_RegisterHelp:(id)sender {
    NSURL *url = [NSURL URLWithString:@"https://healthy.kaiserpermanente.org/health/care/consumer/dis/registration"];
    [[UIApplication sharedApplication] openURL:url];
}

-(IBAction)action_ForgotUserIdHelp:(id)sender {
    NSURL *url = [NSURL URLWithString:@"https://healthy.kaiserpermanente.org/health/care/consumer/dis/forgotuserid"];
    [[UIApplication sharedApplication] openURL:url];
}

-(IBAction)action_ForgotPasswordHelp:(id)sender {
    NSURL *url = [NSURL URLWithString:@"https://healthy.kaiserpermanente.org/health/care/consumer/dis/forgotpassword"];
    [[UIApplication sharedApplication] openURL:url];
}

-(IBAction)action_CallForAssistanceHelp:(id)sender {
    PhoneLinkHandler *handler=[[PhoneLinkHandler alloc] init];
    NSString *phoneNumber=@"1-800-556-7677";
    self.phoneHandler=handler;
    [self.phoneHandler showPhoneAlertWithPhoneNum:phoneNumber];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
