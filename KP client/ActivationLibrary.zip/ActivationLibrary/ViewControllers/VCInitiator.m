//
//  VCInitiator.m
//  MobileCare
//
//  Created by Zhanquan He on 11/25/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "VCInitiator.h"
#import "Utilities.h"

@implementation VCInitiator

@synthesize m_szText;
@synthesize m_lbText;
@synthesize m_ai;
@synthesize _progressView;
@synthesize timer_Progress;

- (id)init
{
    self = [super initWithNibName:@"VCInitiator" bundle:nil];
	if (self)
	{
		m_bShowing = NO;
	}
	return self;
}

- (id)initWithText:(NSString*)szText
{
    self = [super initWithNibName:@"VCInitiator" bundle:nil];
	if (self)
	{
		self.m_szText = szText;
		m_bShowing = NO;
	}
	return self;
}

- (void)dealloc 
{
	self.m_szText = nil;
	self.m_lbText = nil;
	self.m_ai = nil;
    self._progressView=nil;
    self.timer_Progress=nil;
    
    [super dealloc];
}

- (void)viewDidLoad 
{
    [super viewDidLoad];
    
    self.view.hidden = NO;    
    
    [m_ai startAnimating];
    
    if (m_bShowing)
    {
        [self show];
    }
	[self drawText];
}

- (void)viewDidUnload 
{
    [super viewDidUnload];
	self.m_szText = nil;
    self.m_lbText = nil;
	self.m_ai = nil;
    self._progressView=nil;
    self.timer_Progress=nil;
}

- (void)drawText
{
	m_lbText.text = m_szText;
}

- (void)setText:(NSString*)szText
{
	self.m_szText = szText;
	[self drawText];
}

- (void)showWithoutBackground
{
	if (m_bShowing)
    {
        [self hide];
    }
    
    m_bShowing = YES;
    
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.67];
    
    self.view.backgroundColor = [UIColor clearColor];
    
    m_ai.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray; 
    
	m_lbText.alpha = (m_bShowing) ? 1 : 0;
	m_ai.alpha = (m_bShowing) ? 1 : 0;
	self.view.alpha = (m_bShowing) ? 1 : 0;
	
	[UIView commitAnimations];
}

- (void)show
{
    m_bShowing = YES;
    self.view.hidden = NO;
    [self action_progressBar];
    self.view.alpha = (m_bShowing) ? 1 : 0;
    //	[UIView beginAnimations:nil context:nil];
    //	[UIView setAnimationDuration:0.67];
    //    
    //    self.view.hidden = NO;
    //    
    //    self.view.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:.5];
    //    
    //    m_ai.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge; 
    //    
    //	m_lbText.alpha = (m_bShowing) ? 1 : 0;
    //	m_ai.alpha = (m_bShowing) ? 1 : 0;
    //	self.view.alpha = (m_bShowing) ? 1 : 0;
    //	
    //	[UIView commitAnimations];
}

-(void)action_progressBar{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(action_endTimer:) name:@"progressNoti" object:nil];
    
    //    imgBGView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo-white.png"]];
    //    imgBGView.frame = CGRectMake(60, 160, 200, 28);
    //    [self.view addSubview:imgBGView];
    
    double_timerProgress = 0.01;
    self._progressView = [[UIProgressView alloc]initWithProgressViewStyle:UIProgressViewStyleDefault];
    self._progressView.frame = CGRectMake(90, 260, 140, 40);
    
    self.timer_Progress = [NSTimer scheduledTimerWithTimeInterval:0.15 target:self selector:@selector(action_progerssTimer) userInfo:nil repeats:YES];   
    self._progressView.progress = double_timerProgress;
    
    [self.view addSubview:self._progressView];
    
}

-(void)action_progerssTimer{
    
    double_timerProgress = double_timerProgress + 0.01;
    
    if (double_timerProgress > 0.9) {
        self._progressView.progress = 0.9;
    }
    else{
        self._progressView.progress = double_timerProgress;
    }
    
}

-(void)action_endTimer:(NSNotification *)noti{
    
    if (self._progressView) {
        self._progressView.progress = 1.0;
        [self._progressView release];
        self._progressView = nil;
    }
    if (self.timer_Progress) {
        [self.timer_Progress invalidate];
        self.timer_Progress = nil;
    }
  //  [Utilities getAppDel].isSynchingCompleted = TRUE;
    //    if (imgBGView) {
    //        [imgBGView removeFromSuperview];
    //    }
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"progressNoti" object:nil];
    
}




- (void)hide
{
	m_bShowing = NO;
    
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.67];
    
	m_lbText.alpha = (m_bShowing) ? 1 : 0;
	m_ai.alpha = (m_bShowing) ? 1 : 0;
	self.view.alpha = (m_bShowing) ? 1 : 0;
	
	[UIView commitAnimations];	
}

- (void)hideWithNoAnimation
{
	m_lbText.alpha = 0;
	m_ai.alpha = 0;
	self.view.alpha = 0;
}
@end
