//
//  TermsAndConditionsViewController.h
//  MobileCare
//
//  Created by Sean Gilligan on 1/12/11.
//  Copyright 2011 Fingerpaint Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MCWebViewController.h"


@interface TermsAndConditionsViewController : MCWebViewController {
    
}


@end
