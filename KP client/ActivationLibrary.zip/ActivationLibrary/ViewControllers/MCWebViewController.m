//
//  MCWebViewController.m
//  MobileCare
//
//  Created by Zhanquan He on 7/18/11.
//  Copyright 2011 kaiser permanente. All rights reserved.
//

#import "MCWebViewController.h"
#import "Utilities.h"
#import "MessageVC.h"


@implementation MCWebViewController

@synthesize m_webView;
@synthesize networkError;
@synthesize curRequest;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    self.m_webView=nil;
    self.curRequest=nil;
    [super dealloc];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.    
    self.networkError=NO;
    
    //    UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]];
    //	self.view.backgroundColor = background;
    //    [background release];
    
    
    
    [self loadWebView];
    
}

- (void) viewWillAppear:(BOOL)animated
{    
    [super viewWillAppear:animated];
    
    if (self.networkError) {
       // [[Utilities getAppDel] showMessage:[NSString stringWithFormat:@"Network connection failed. We are are unable to connect to the %@ server at this time. Please try again later.",[[Utilities getAppDel] getAppDisplayName]]  withButtonText:@"Retry" target:self andSelector:@selector(doRetry)];
        [[Utilities getAppDel].m_msgVC show]; 
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
    
    //    if (self.networkError) 
    //    {
    /*
    if (![Utilities getAppDel].facOnly) {
        [[Utilities getAppDel] hideMessage];
    }*/        
    [[Utilities getAppDel] hideAi];
    [[Utilities getAppDel] hideMessage];
    
    //    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.m_webView=nil;
    self.curRequest=nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - core functions and UIWebViewDelegate

- (void)loadWebView
{
    NSAssert(NO, @"base-class shouldn't be called");
}

- (BOOL)webView:(UIWebView *)webView2 shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    //    self.curRequest=request;
    NSURL *url = request.URL;
    if (![url.scheme isEqual:@"http"] && ![url.scheme isEqual:@"https"]) {
        if ([[UIApplication sharedApplication]canOpenURL:url]) {
            [[UIApplication sharedApplication]openURL:url];
            return NO;
        }
    }
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    [[Utilities getAppDel] showAi];
    return YES;
}


- (void)webViewDidFinishLoad:(UIWebView *)webView2
{    
    if (self.networkError) {
        [[Utilities getAppDel] hideMessage];
        self.networkError=NO;
    }
    [[Utilities getAppDel] hideAi];
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
}


- (void) doRetry {
    [self.m_webView loadRequest:self.curRequest];    
}

- (void) webView:(UIWebView *)webView2 didFailLoadWithError:(NSError *)error
{
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    [[Utilities getAppDel] hideAi];
    
    //[[Utilities getAppDel] showMessage:@"We're unable to connect to retrieve your data at this time. Please try again later. " withButtonText:@"Retry" target:self andSelector:@selector(doRetry)];
    [[Utilities getAppDel].m_msgVC showMessage:@"We're unable to connect to retrieve your data at this time. Please try again later. " withButtonText:@"Retry" target:self andSelector:@selector(doRetry)];
    
    self.networkError=YES;
}

// Launches the Mail application on the device.
-(void)launchMailAppOnDevice:(NSString *)recipient
{
    
	NSString *recipients = [NSString stringWithFormat:@"mailto:%@?subject=%@ Support", recipient,[[Utilities getAppDel] getAppDisplayName]];
	NSString *body = @" ";
	
	NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

-(void) displayComposerSheet:(NSArray *)recipients
{
	MFMailComposeViewController *picker = [[[MFMailComposeViewController alloc] init] autorelease];
	picker.mailComposeDelegate = self;
    
    //Code to change E-mail Panel color.
    picker.navigationBar.tintColor = [UIColor colorWithRed: (CGFloat)0/256 
                                                     green: (CGFloat)109/256 
                                                      blue: (CGFloat)157/256 
                                                     alpha:1];
    
	
    [picker setToRecipients:recipients];
	[picker setSubject:[NSString stringWithFormat:@"%@ Support",[[Utilities getAppDel] getAppDisplayName]]];
	
	
	[picker setMessageBody:@" " isHTML:YES];	 
    
	
	[self presentModalViewController:picker animated:YES];
    //[picker release];
}


// Dismisses the email composition interface when users tap Cancel or Send. Proceeds to update the message field with the result of the operation.
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{	
	NSString *message;
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			message = @"Result: canceled";
			break;
		case MFMailComposeResultSaved:
			message = @"Result: saved";
			break;
		case MFMailComposeResultSent:
			message = @"Result: sent";
			break;
		case MFMailComposeResultFailed:
			message = @"Result: failed";
			break;
		default:
			message = @"Result: not sent";
			break;
	}
	[self dismissModalViewControllerAnimated:YES];
}

@end
