//
//  VCActivityIndicator.m
//
//  Created by Paul on 9/27/10.
//  Copyright 2010 Paiego. All rights reserved.
//

#import "VCActivityIndicator.h"

@implementation VCActivityIndicator

@synthesize m_szText;
@synthesize m_lbText;
@synthesize m_btBackground;
@synthesize m_ai;

- (id)init
{
    self = [super initWithNibName:@"VCActivityIndicator" bundle:nil];
	if (self)
	{
		m_bShowing = NO;
	}
	return self;
}

- (id)initWithText:(NSString*)szText
{
    self = [super initWithNibName:@"VCActivityIndicator" bundle:nil];
	if (self)
	{
		self.m_szText = szText;
		m_bShowing = NO;
	}
	return self;
}

- (void)dealloc 
{
	self.m_szText = nil;
	self.m_lbText = nil;
	self.m_ai = nil;
    self.m_btBackground = nil;
    
    [super dealloc];
}

- (void)viewDidLoad 
{
    [super viewDidLoad];
 
    self.view.hidden = NO;    
    
    [m_ai startAnimating];

    if (m_bShowing)
    {
        [self show];
    }
	[self drawText];
}

- (void)viewDidUnload 
{
    [super viewDidUnload];
	self.m_szText = nil;
    self.m_lbText = nil;
	self.m_ai = nil;
    self.m_btBackground = nil;
}

- (void)drawText
{
	self.m_lbText.text = m_szText;
}

- (void)setText:(NSString*)szText
{
	self.m_szText = szText;
	[self drawText];
}

- (void)showWithoutBackground
{
	if (m_bShowing)
    {
        [self hide];
    }
    
    m_bShowing = YES;
    
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.67];
        
    self.view.backgroundColor = [UIColor clearColor];
    
    m_ai.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray; 
    
	m_lbText.alpha = (m_bShowing) ? 1 : 0;
	m_ai.alpha = (m_bShowing) ? 1 : 0;
	self.view.alpha = (m_bShowing) ? 1 : 0;
	
	[UIView commitAnimations];
}

- (void)show
{
    m_bShowing = YES;

	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.67];
    
    self.view.hidden = NO;

    self.view.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:.5];
    //self.view.backgroundColor = [UIColor colorWithRed:127/255.0f green:190/255.0f blue:245/255.0f alpha:0.4];
    
    m_ai.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge; 
    
	m_lbText.alpha = (m_bShowing) ? 1 : 0;
	m_ai.alpha = (m_bShowing) ? 1 : 0;
	self.view.alpha = (m_bShowing) ? 1 : 0;
	
	[UIView commitAnimations];
}

- (void)hide
{
	m_bShowing = NO;

	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.67];
    
	m_lbText.alpha = (m_bShowing) ? 1 : 0;
	m_ai.alpha = (m_bShowing) ? 1 : 0;
	self.view.alpha = (m_bShowing) ? 1 : 0;
	
	[UIView commitAnimations];	
}

- (void)hideWithNoAnimation
{
	m_lbText.alpha = 0;
	m_ai.alpha = 0;
	self.view.alpha = 0;
}

@end
