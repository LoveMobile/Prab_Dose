//
//  VCGeneralDialog.m
//  MobileCare
//
//  Created by Paul on 5/5/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "VCGeneralDialog.h"
#import "WebServiceMan.h"
#import "AuthorizationMan.h"
//#import "CoreDataMan.h"
#import "Utilities.h"
//#import "ContainerMan.h"
//#import "BadgeMan.h"
#import "Constants.h"
#import <QuartzCore/QuartzCore.h>
#import "IdleTimerMan.h"
#import "TutorialViewController.h"
#import "SBJsonWriter.h"


@implementation VCGeneralDialog


@synthesize m_lbText;
@synthesize m_bt1;
@synthesize m_bt2;
@synthesize m_bt3;
//@synthesize m_ivHeader;
@synthesize m_ivBanner;
@synthesize m_statusChecker;
@synthesize m_authChecker;
@synthesize m_authReg;
@synthesize m_delegate;
// Abhinav Sehgal - AuthorizationViewController objectproperty remove
//@synthesize m_vcAuth;

@synthesize lbl_member1;
@synthesize lbl_member2;
@synthesize lbl_member3;
@synthesize lbl_member4;
@synthesize lbl_member5;
@synthesize lbl_member6;
@synthesize lbl_member7;
@synthesize lbl_member8;
@synthesize m_BGView;
@synthesize lbl_member9;
@synthesize lbl_member10;
@synthesize m_FooterIMG;
@synthesize deauthErrMsg;
@synthesize m_nonMemberView;
@synthesize lbl_nonMember;
@synthesize m_fetcherJson;

#pragma mark -
#pragma mark VC management

- (id)init
{
    self = [super initWithNibName:@"VCGeneralDialog" bundle:nil];
    
    if (self)
    {
        m_eState = INITIALIZE;
        m_delegate = nil;
        self.m_statusChecker = nil;
        self.m_authChecker = nil;
        self.m_authReg = nil;
    }
    
    return self;
}

// This is for opening Merlin with an error message.
- (id)initWithState:(WIZARD_STATE)eState
{
    self = [super initWithNibName:@"VCGeneralDialog" bundle:nil];
    
    if (self)
    {
        m_eState = eState;
        m_delegate = nil;
        self.m_statusChecker = nil;
        self.m_authChecker = nil;
        self.m_authReg = nil;
    }
    
    return self;
}

-(void)viewWillDisappear:(BOOL)animated{
    
    //    m_bt1.hidden = YES;
    //    m_bt2.hidden = YES;
    self.m_BGView.hidden = YES;
    self.m_nonMemberView.hidden=YES;
    
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];  
    if (int_decline == 1) {
        [self performSelectorOnMainThread:@selector(startProcess) withObject:nil waitUntilDone:NO];
    }
    
    if (isIphone5) {
        // code for 4-inch screen
        self.m_BGView.frame = CGRectMake(0, 504, 320, 46);
        self.m_ivBanner.frame = CGRectMake(0, 0, 320, 568);
        
    } else {
        // code for 3.5-inch screen
        self.m_BGView.frame = CGRectMake(0, 416, 320, 46);
        self.m_ivBanner.frame = CGRectMake(0, 0, 320, 480);
    }
    
    [self.view addSubview:self.m_BGView];
    self.m_BGView.hidden = YES;
    self.m_nonMemberView.hidden=YES;
    //    m_bt1.hidden = YES;
    //    m_bt2.hidden = YES;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"displayWarning" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayWarning) name:@"displayWarning" object:nil];
    
}


- (void)displayWarning
{
    WarningViewController *obj = [[WarningViewController alloc] initWithDelegate:self];
    obj.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:obj animated:YES];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    int_decline = 0;  
    
    [self.m_bt1 setBackgroundImage:[[UIImage imageNamed:@"bar_button_orange.png"]
                                    stretchableImageWithLeftCapWidth:10.0f
                                    topCapHeight:0.0f]
                          forState:UIControlStateNormal];
    self.m_bt1.layer.cornerRadius = 8;
    self.m_bt1.layer.borderWidth = 1;
    //btn_accept.layer.borderColor = [UIColor grayColor].CGColor;
    self.m_bt1.clipsToBounds = YES;
    
    [self.m_bt2 setBackgroundImage:[[UIImage imageNamed:@"bar_button_dkgrey.png"]
                                    stretchableImageWithLeftCapWidth:10.0f
                                    topCapHeight:0.0f]
                          forState:UIControlStateNormal];
    self.m_bt2.layer.cornerRadius = 8;
    self.m_bt2.layer.borderWidth = 1;
    //btn_decline.layer.borderColor = [UIColor grayColor].CGColor;
    self.m_bt2.clipsToBounds = YES;
    
    m_bt3.layer.cornerRadius = 8;
    //m_bt3.layer.borderWidth = 1;
    //m_bt3.layer.borderColor = [UIColor grayColor].CGColor;
    m_bt3.clipsToBounds = YES;
    
    [self.m_bt3 setBackgroundImage:[[UIImage imageNamed:@"bkgd_button_blue.png"]
                                    stretchableImageWithLeftCapWidth:10.0f
                                    topCapHeight:0.0f]
                          forState:UIControlStateNormal];
    [self.m_bt3 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.m_bt3.titleLabel.shadowColor = [UIColor lightGrayColor];
    self.m_bt3.titleLabel.shadowOffset = CGSizeMake(0, -1); 
    m_bt3.hidden=YES;
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (screenBounds.size.height == 568) {
        isIphone5=YES;
        backgroundImage=@"bkgd_kp_blue@2x.png";
    } else {
        isIphone5=NO;
        backgroundImage=@"bkgd_kp_blue.png";
    }
    
    m_ivBanner.image = [UIImage imageNamed:backgroundImage];
    // m_FooterIMG.hidden = YES;
    self.m_BGView.hidden = TRUE;
    self.m_nonMemberView.hidden=YES;
    self.lbl_member1.hidden = YES;
    self.lbl_member2.hidden = YES;
    self.lbl_member3.hidden = YES;
    self.lbl_member4.hidden = YES;
    self.lbl_member5.hidden = YES;
    self.lbl_member6.hidden = YES;
    self.lbl_member7.hidden = YES;
    self.lbl_member8.hidden = YES;
    self.lbl_member9.hidden = YES;
    self.lbl_member10.hidden = YES;
    
    if (m_eState == INITIALIZE)
    {
        [self.m_BGView setHidden:YES];
        self.m_nonMemberView.hidden=YES;
        [[Utilities getAppDel] hideMessage];
        [self performSelectorOnMainThread:@selector(startProcess) withObject:nil waitUntilDone:NO];
    }
    else
    {
        [self setState:m_eState];
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
/*    
    if ([HandshakeMan get].delegate == self)
    {
        [HandshakeMan get].delegate = nil;
    }
*/ 
    
    // Abhinav Sehgal - AuthorizationViewController objectproperty remove
    //if (m_vcAuth)
    //{
     //  self.m_vcAuth.delegate = nil;
       // self.m_vcAuth = nil;
       // m_vcAuth.delegate = nil;
//        [m_vcAuth release];
//        m_vcAuth = nil;
   // }    
    self.m_FooterIMG = nil;
    self.lbl_member1 = nil;
    self.lbl_member2 = nil;
    self.lbl_member3 = nil;
    self.lbl_member4 = nil;
    self.lbl_member5 = nil;
    self.lbl_member6 = nil;
    self.lbl_member7 = nil;
    self.lbl_member8 = nil;
    self.m_BGView = nil;
    self.lbl_member9 = nil;
    self.lbl_member10 = nil;
    
    self.m_lbText = nil;
    self.m_bt1 = nil;
    self.m_bt2 = nil;
    self.m_bt3=nil;
    //    self.m_ivHeader = nil;
    self.m_ivBanner = nil;
    self.m_statusChecker = nil;
    self.m_authChecker = nil;
    self.m_authReg = nil;
    self.deauthErrMsg = nil;
    self.m_nonMemberView=nil;
    self.lbl_nonMember=nil;
}

- (void)dealloc
{
    /*
    if ([HandshakeMan get].delegate == self)
    {
        [HandshakeMan get].delegate = nil;
    }*/
    
    // Abhinav Sehgal - AuthorizationViewController objectproperty remove
   // if (m_vcAuth)
    //{
        //  self.m_vcAuth.delegate = nil;
        // self.m_vcAuth = nil;
      //  m_vcAuth.delegate = nil;
       // [m_vcAuth release];
       // m_vcAuth = nil;
    //}    
    
    self.m_lbText = nil;
    self.m_bt1 = nil;
    self.m_bt2 = nil;
    self.m_bt3 = nil;
    //    self.m_ivHeader = nil;
    self.m_ivBanner = nil;
    self.m_statusChecker = nil;
    self.m_authChecker = nil;
    self.m_authReg = nil;
    
    self.m_FooterIMG = nil;
    self.lbl_member1 = nil;
    self.lbl_member2 = nil;
    self.lbl_member3 = nil;
    self.lbl_member4 = nil;
    self.lbl_member5 = nil;
    self.lbl_member6 = nil;
    self.lbl_member7 = nil;
    self.lbl_member8 = nil;
    self.m_BGView = nil;
    self.lbl_member9 = nil;
    self.lbl_member10 = nil;
    self.deauthErrMsg = nil;
    self.m_nonMemberView=nil;
    self.lbl_nonMember=nil;    
    [super dealloc];
}

#pragma mark -
#pragma mark Calls to dialogs

- (void)showSetPasscode
{
    // ABHI CHECK Passcode or Sign On view
    BOOL _bool = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOnAsBG"];
    if (_bool == TRUE) {
        
        [self setPasscodeFinished:YES];
    }
    else{
        SetPasscodeViewController* vc = [[[SetPasscodeViewController alloc] initWithDelegate:self] autorelease];
        vc.title = [[Utilities getAppDel] getAppDisplayName];
        [self showAsModal:vc];
    }
}

- (void)showPasscodeView
{
    // Abhinav sehgal - (No passcode required) 
    // We are getting the application enter background date time , so that we can get the interval with current date time on application active state.
    // If it is < 20 , then no passcode required and directly enter into the application.
    // else open passcode view screen.
   // [Utilities getAppDel].isSynchingCompleted = FALSE;
    LOG("foreground :- %@",[NSDate date]);
    LOG("userDefaults : - %@ ",[[NSUserDefaults standardUserDefaults] valueForKey:@"BackGroundTime"]);
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"BackGroundTime"] == nil) {
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_isEnteredPasscode"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        PasscodeViewController* vc = [[[PasscodeViewController alloc] initWithDelegate:self] autorelease];
        vc.title = [[Utilities getAppDel] getAppDisplayName];
        [[Utilities getAppDel] hideMessage]; 
        [self showAsModal:vc];
    }
    else{//
        NSDate *_mydate = [[NSUserDefaults standardUserDefaults] valueForKey:@"BackGroundTime"];
        NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:_mydate];
        LOG("interval = %f",interval);
        if (interval < kMaxIdleTimeInterval) {
            
            if([[NSUserDefaults standardUserDefaults] boolForKey:@"_isEnteredPasscode"]){
                //[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"_isLoggedIn"];
                //[[NSUserDefaults standardUserDefaults] synchronize];
           //     [Utilities getAppDel].isSynchingCompleted = YES;
                [self passcodeFinished:YES];
                // [self.m_tryMan reset]; 
                [[TryMan tryMan] reset];
            }
            else{
                [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_isEnteredPasscode"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                PasscodeViewController* vc = [[[PasscodeViewController alloc] initWithDelegate:self] autorelease];
                vc.title = [[Utilities getAppDel] getAppDisplayName];
                [[Utilities getAppDel] hideMessage]; 
                [self showAsModal:vc];
            }
        }
        else
        {
            [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_isEnteredPasscode"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            PasscodeViewController* vc = [[[PasscodeViewController alloc] initWithDelegate:self] autorelease];
            vc.title = [[Utilities getAppDel] getAppDisplayName];
            [[Utilities getAppDel] hideMessage]; 
            [self showAsModal:vc];
            
        }
    }
    
}

- (void)showAuthView
{
    AuthorizationViewController* vc = [[[AuthorizationViewController alloc] initWithDelegate:self] autorelease];
    vc.delegate = self;
    [self showAsModal:vc];
    /*
    LOG("foreground :- %@",[NSDate date]);
    LOG("userDefaults : - %@ ",[[NSUserDefaults standardUserDefaults] valueForKey:@"BackGroundTime"]);
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"BackGroundTime"] == nil) {
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_isLoggedIn"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        AuthorizationViewController* vc = [[[AuthorizationViewController alloc] initWithDelegate:self] autorelease];
        //m_vcAuth = [[[AuthorizationViewController alloc] initWithDelegate:self] autorelease];
        //    self.m_vcAuth.title = @"Sign In";
        //vc.navigationItem.titleView=[[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo-white.png"]] autorelease];
        vc.delegate = self;
        [self showAsModal:vc];
    }
    else{
        NSDate *_mydate = [[NSUserDefaults standardUserDefaults] valueForKey:@"BackGroundTime"];
        NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:_mydate];
        LOG("interval = %f",interval);
        if (interval < kMaxIdleTimeInterval) {
          
            if([[NSUserDefaults standardUserDefaults] boolForKey:@"_isLoggedIn"]){
                
                AuthorizationMan* am = [AuthorizationMan get];
                if ([am isAuthorized])
                {
                  //  [Utilities getAppDel].isSynchingCompleted = YES;
                    [self passcodeFinished:YES];
                    // [self.m_tryMan reset]; 
                    [[TryMan tryMan] reset];
                }
                else{
                    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_isLoggedIn"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    //    AuthorizationViewController* vc = [[[AuthorizationViewController alloc] initWithDelegate:self] autorelease];
                    AuthorizationViewController* vc = [[[AuthorizationViewController alloc] initWithDelegate:self] autorelease];
                    //    self.m_vcAuth.title = @"Sign In";
                    //vc.navigationItem.titleView=[[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo-white.png"]] autorelease];
                    vc.delegate = self;
                    [self showAsModal:vc];
                }
                
    
            }
            else{
                [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_isLoggedIn"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                //    AuthorizationViewController* vc = [[[AuthorizationViewController alloc] initWithDelegate:self] autorelease];
                AuthorizationViewController* vc = [[[AuthorizationViewController alloc] initWithDelegate:self] autorelease];
                //    self.m_vcAuth.title = @"Sign In";
                //vc.navigationItem.titleView=[[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo-white.png"]] autorelease];
                vc.delegate = self;
                [self showAsModal:vc];
            }
        }
        else
        {
            [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_isLoggedIn"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            AuthorizationViewController* vc = [[[AuthorizationViewController alloc] initWithDelegate:self] autorelease];
            //vc = [[[AuthorizationViewController alloc] initWithDelegate:self] autorelease];
            //    self.m_vcAuth.title = @"Sign In";
            //vc.navigationItem.titleView=[[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo-white.png"]] autorelease];
            vc.delegate = self;
            [self showAsModal:vc];
        }
    }*/
}

#pragma mark -
#pragma mark Core

- (void)showAsModal:(UIViewController*)vc
{
	UINavigationController* nc = [[[UINavigationController alloc] initWithRootViewController:vc] autorelease];
	nc.navigationBar.tintColor = [Utilities getAppDel].navBarColor;
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    if (version>=7.0) {
        nc.navigationBar.translucent=NO;
        nc.navigationBar.barTintColor=[Utilities getAppDel].navBarColor;
        [[UINavigationBar appearance] setTitleTextAttributes:
         [NSDictionary dictionaryWithObjectsAndKeys:
          [UIColor whiteColor], UITextAttributeTextColor,
          [UIFont fontWithName:@"Helvetica Neue" size:18.0], UITextAttributeFont,nil]];
    }
    nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:nc animated:YES];
}

- (void)setScreenByState:(WIZARD_STATE)eState
{
    // m_bt1.hidden = YES;
    // m_bt2.hidden = YES;
    
    m_bt3.hidden = YES;
    m_lbText.hidden = YES;
    m_ivBanner.image = [UIImage imageNamed:backgroundImage];
    
    self.m_BGView.hidden  = YES;
    self.m_nonMemberView.hidden=YES;
    
    //m_FooterIMG.hidden = YES;
    self.lbl_member1.hidden = YES;
    self.lbl_member2.hidden = YES;
    self.lbl_member3.hidden = YES;
    self.lbl_member4.hidden = YES;
    self.lbl_member5.hidden = YES;
    self.lbl_member6.hidden = YES;
    self.lbl_member7.hidden = YES;
    self.lbl_member8.hidden = YES;
    self.lbl_member9.hidden = YES;
    self.lbl_member10.hidden = YES;
    //    m_lbText.textColor = [UIColor whiteColor];
    m_lbText.textColor = [UIColor blackColor];
    switch (eState) 
    {
        case INITIALIZE: 
            // Don't populate facilities until we have a URL-ROOT
            // Load local facilities lazily (takes < 1s).
            break;
            
        case NORCAL_QUESTION:
            //   m_lbText.text = @"Welcome to MobileCare\nfor Northern California\n\nAs a Kaiser Permanente Northern California member you can:\n\n•	Check your appointment status\n•	follow up on preventive screenings\n•	Manage your family's health\n•	Receive Timely Tips\n•	Locate facilities, departments & services\n\nAre you a Northern California Member?";
            
            self.lbl_member1.hidden = NO;
            self.lbl_member2.hidden = NO;
            self.lbl_member3.hidden = NO;
            self.lbl_member4.hidden = NO;
            self.lbl_member5.hidden = NO;
            self.lbl_member6.hidden = NO;
            self.lbl_member7.hidden = NO;
            self.lbl_member8.hidden = NO;
            self.lbl_member9.hidden = NO;
            self.lbl_member10.hidden = NO;
            // m_lbText.hidden = NO;
            self.m_BGView.hidden = NO;
            
            //            m_bt1.hidden = NO;
            //            m_bt2.hidden = NO;
            //            m_FooterIMG.hidden = NO;
            [self.m_bt1 setTitle:@"Continue" forState:UIControlStateNormal];
            
            
            [self.m_bt2 setTitle:@"Cancel" forState:UIControlStateNormal];
            
            break;
            
        case AUTHORIZING:
            m_lbText.text = @"";
            m_ivBanner.image = [UIImage imageNamed:backgroundImage];
            self.m_BGView.hidden = YES;
            self.m_nonMemberView.hidden=YES;
            //            m_FooterIMG.hidden = YES;
            //            
            //            m_bt1.hidden = YES;
            //            m_bt2.hidden = YES;
            break;
            
        case DEAUTHORIZED:
            m_ivBanner.image = [UIImage imageNamed:@"bkgd_wht_ltgrey.png"];
            if (self.deauthErrMsg != nil) 
            {
                m_lbText.text = self.deauthErrMsg;    
            } else {
                m_lbText.text =  @"Your device has been deactivated. You can access your information upon re-activation.";
            }
            m_lbText.textColor = [UIColor blackColor];
            [self.m_bt3 setTitle:@"Reactivate" forState:UIControlStateNormal];
            m_lbText.hidden = NO;
            m_bt3.hidden=NO;
            break;
            
            
        case FORCED_UPDATE:
            m_ivBanner.image = [UIImage imageNamed:@"bkgd_wht_ltgrey.png"];
            m_lbText.text = [NSString stringWithFormat:@"You're using an outdated version of %@. Please download the latest version to continue.",[[Utilities getAppDel] getAppDisplayName]];
            m_lbText.hidden = NO;
            break;
            
        case ROTTEN_DATA_LOCKOUT_NET:
            m_ivBanner.image = [UIImage imageNamed:@"bkgd_wht_ltgrey.png"];
            m_lbText.text = @"The data on this device has expired. As a security precaution, please connect your device to the internet so your data can be refreshed.";
            m_lbText.hidden = NO;
            m_bt3.hidden = NO;
            [self.m_bt3 setTitle:@"Retry" forState:UIControlStateNormal];
            break;
            
        case ROTTEN_DATA_LOCKOUT_WS:
            m_ivBanner.image = [UIImage imageNamed:@"bkgd_wht_ltgrey.png"];
            m_lbText.text = @"We're sorry, we're unable to connect to retrieve your data at this time. Please try again later.";
            m_lbText.hidden = NO;
            m_bt3.hidden = NO;
            [self.m_bt3 setTitle:@"Retry" forState:UIControlStateNormal];
            break;
            
        case EMPTY_DATA_LOCKOUT_NET:
            m_ivBanner.image = [UIImage imageNamed:@"bkgd_wht_ltgrey.png"];
            m_lbText.text = @"Locked out: data issue. We are unable to connect to the internet to retrieve your data. Please try again later.";
            m_lbText.hidden = NO;
            m_bt3.hidden = NO;
            [self.m_bt3 setTitle:@"Retry" forState:UIControlStateNormal];
            break;
            
        case EMPTY_DATA_LOCKOUT_WS:
            m_ivBanner.image = [UIImage imageNamed:@"bkgd_wht_ltgrey.png"];
            m_lbText.text = @"We're sorry, we're unable to connect to retrieve your data at this time. Please try again later.";
            m_lbText.hidden = NO;
            m_bt3.hidden = NO;
            [self.m_bt3 setTitle:@"Retry" forState:UIControlStateNormal];
            break;
            
        case WS_FAILURE: // generic handler of ws errors.
            m_ivBanner.image = [UIImage imageNamed:@"bkgd_wht_ltgrey.png"];
            // Abhinav Sehgal - System Maintenance Check
            if (self.deauthErrMsg != nil) 
            {
                m_lbText.text = self.deauthErrMsg;    
            } else {
                m_lbText.text = @"We're sorry, we're unable to connect to retrieve your data at this time. Please try again later.";
            }
            m_lbText.hidden = NO;
            m_bt3.hidden = NO;
            [self.m_bt3 setTitle:@"Retry" forState:UIControlStateNormal];
            break;
            
        case NETWORK_FAILURE:
            m_ivBanner.image = [UIImage imageNamed:@"bkgd_wht_ltgrey.png"];
            m_lbText.text = @"This application requires a working network connection.  Please check your device's signal strength.";            
            m_lbText.hidden = NO;
            m_bt3.hidden = NO;
            [self.m_bt3 setTitle:@"Retry" forState:UIControlStateNormal];
            break;
            
        case QA_PROD_QUESTION:
            //            [m_bt1 setBackgroundImage:[UIImage imageNamed:@"bkgd_button_orange.png"] forState:UIControlStateNormal];
            m_lbText.text = @"Use QA URLs?\n(Yes for QA, No for Production)";
            m_lbText.textColor=[UIColor whiteColor];
            m_lbText.hidden = NO;
            self.m_BGView.hidden = NO;
            //            m_bt1.hidden = NO;
            //            m_bt2.hidden = NO;
            //            m_FooterIMG.hidden = NO;
            [self.m_bt1 setTitle:@"Yes" forState:UIControlStateNormal];
            [self.m_bt2 setTitle:@"No" forState:UIControlStateNormal];            
            break;
            
        default:
            break;
    }
}

- (void)setState:(WIZARD_STATE)eState
{
    m_eState = eState;
    
    switch (eState) 
    {            
        case INITIALIZE: 
        case DEAUTHORIZED:
        case FORCED_UPDATE:
        case ROTTEN_DATA_LOCKOUT_WS:
        case ROTTEN_DATA_LOCKOUT_NET:
        case EMPTY_DATA_LOCKOUT_WS:
        case EMPTY_DATA_LOCKOUT_NET:
        case WS_FAILURE: // generic handler of ws errors.
        case NETWORK_FAILURE:
        case NORCAL_QUESTION:
        case AUTHORIZING:
        case QA_PROD_QUESTION:
            [self setScreenByState:eState];
            break;
        case COMPLETE:
            // This should occur while being dismissed.
            break;
            
        default:
            NSAssert(NO, @"State not defined");
            break;
    }
}

- (IBAction)buttonPressed:(id)sender
{
    switch (m_eState)
    {
        case DEAUTHORIZED:
            // Initiate authorization
            [self setState:NORCAL_QUESTION];
            break;
            
        case NORCAL_QUESTION:
            if (m_bt1 == sender) // Yes
            {
                //                //                [m_bt1 setBackgroundImage:[UIImage imageNamed:@"bkgd_button_orange_on.png"] forState:UIControlStateNormal];
                //                
                //                // If this is a pre-release build, then ask the question for QA or RELEASE.
                //                if (YES) // PRE_RELEASE
                //                {
                //                    
                //                    
                //                    
                //                    
                //                    [self setState:QA_PROD_QUESTION];
                //                }
                //                else
                //                {
                //                    // Assume that we're using PROD urls
                //                    [[WebServiceMan get] setConfigType:WCT_PRODUCTION];
                //                    [self checkServerStatus];
                //                }
                // must release old and recreate all the viewControllers again
                
                [self checkServerStatus];
                [[Utilities getAppDel] setFullMode];
            }
            else // No
            {         
                //                [m_bt1 setBackgroundImage:[UIImage imageNamed:@"bkgd_button_blue_on.png"] forState:UIControlStateNormal];
                
                //[HandshakeMan get].delegate = self;
                
                //BOOL bRefreshing = [[HandshakeMan get] refreshFacilities];
                
                // Configure the main window for Facilities Only
                
                /* old way to handle cancel
                [[Utilities getAppDel] setFacOnlyMode];
                
                [self setState:COMPLETE];
                [m_delegate dismissModal];
                 */
                
                // new way to handle cancel
                self.lbl_nonMember.lineBreakMode = UILineBreakModeWordWrap;
                self.lbl_nonMember.numberOfLines = 0;
                self.lbl_nonMember.text=@"My KP Meds was developed by physicians of The Permanente Medical Group (TPMG).\n\n Its use at this time is limited to  Kaiser Permanente members in Northern California.";
                [self.view addSubview:self.m_nonMemberView];
                [self.view bringSubviewToFront:self.m_nonMemberView];
                self.m_nonMemberView.hidden=NO;
                /*
                if (NO == bRefreshing)
                {
                    [m_delegate dismissModal];
                }*/
            }
            break;
            
        case QA_PROD_QUESTION:
            if (m_bt1 == sender) // QA
            {
                //                [m_bt1 setBackgroundImage:[UIImage imageNamed:@"bkgd_button_orange_on.png"] forState:UIControlStateNormal];
                
                
                [[WebServiceMan get] setConfigType:WCT_QA];
            }
            else // Production
            {
                //                [m_bt1 setBackgroundImage:[UIImage imageNamed:@"bkgd_button_blue_on.png"] forState:UIControlStateNormal];
                [[WebServiceMan get] setConfigType:WCT_PRODUCTION];
            }
            [self checkServerStatus];
            break;
            
            
        case ROTTEN_DATA_LOCKOUT_NET:
        case ROTTEN_DATA_LOCKOUT_WS:
        case EMPTY_DATA_LOCKOUT_NET:
        case EMPTY_DATA_LOCKOUT_WS:
        case NETWORK_FAILURE:
        case WS_FAILURE:
            [self checkServerStatus];
            break;
            
        case INITIALIZE: 
        case FORCED_UPDATE:
        default:
            NSAssert(NO, @"button shouldn't be active in these states");
            break;
    }
}

- (void)startProcess
{
    LOG("startProcess");
    
    [[Utilities getAppDel] setFullModeWithCheck];
    
    
    BOOL signonFlag = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOn"];
    
    if (signonFlag==YES) {
        [self passcodeFinished:YES];
    } else {
        [self showAuthView];
    }
    /*
    
    [self setState:INITIALIZE];
    
    // Initialize the web-service manager, if not already
    [WebServiceMan get];
    
    // This will calculate the current auth state.
    AuthorizationMan* am = [AuthorizationMan get];
    
    // Check for a new bundle version and if yes delete 
    // the data repository and mark for repopulation.
    //[[CoreDataMan get] checkForNewAppVersion];
    
    if ([am isAuthorized])
    {
        LOG("isAuth");
        int_tabBarWhiteCsreen = 11;
        // Create the full tab-set, if needed.
        [[Utilities getAppDel] setFullModeWithCheck];
        
        // ABHI CHECK Passcode or Sign On view
        BOOL _bool = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOnAsBG"];
        if (_bool == TRUE) {
        
            [self showAuthView];
        }
        else{
            if ([am isSetPasscodeRequired]) {
                [self showSetPasscode];
            }
            else if ([am passcodeRequired])
            {
                [self showPasscodeView];
            }
            else
            {
                // Treat like a successful passcode entry
              //  [Utilities getAppDel].isSynchingCompleted = YES;
                [self passcodeFinished:YES];
            }

        }
        
    }
    else // not auth
    {     
        [self setState:NORCAL_QUESTION];
    }*/
}

// TODO - add state for each check
// TODO - make sure that these calls don't overlap.
- (void)checkServerStatus
{
    [[Utilities getAppDel] showAi];
    //    [[Utilities getAppDel] showInitiator];
    
    self.m_statusChecker = [[[ServerStatusCheck alloc] init] autorelease];
    self.m_statusChecker.delegate = self;
    [self.m_statusChecker startCheck];
    
    // TODO - Fix bug where status check informs a dealloced delegate!
}

- (void)checkAuthorization
{
    [[Utilities getAppDel] showAi];
    //    [[Utilities getAppDel] showInitiator];
    
    self.m_authChecker = [[[AuthorizationCheck alloc] init] autorelease];
    self.m_authChecker.delegate = self;
    [self.m_authChecker startCheck];
}

- (void)registerDevice
{
    [[Utilities getAppDel] showAi];
    //    [[Utilities getAppDel] showInitiator];
    
    self.m_authReg = [[[AuthorizationReg alloc] init] autorelease];
    self.m_authReg.delegate = self;
    [self.m_authReg startCheck];
}

// == Delegate Callbacks Begin ==

#pragma mark -
#pragma mark AuthorizationViewController delegate

- (void)signOnComplete:(BOOL)valid
{
    LOG("signOnComplete start");
    
    if (shouldClearData) {
        //[[NSNotificationCenter defaultCenter] postNotificationName:@"DeviceDeactivateNotification" object:nil];
        LOG("delegate clearAllData is being called!");
        [m_delegate clearAllData];
        shouldClearData=NO;
    }
    
    if (isTutorialNeeded) {
        self.m_fetcherJson = [[[FetcherJson alloc] initWithMethod:@"getTutorialAndWarningContent" andParams:nil] autorelease];
        self.m_fetcherJson.delegate = self;
        [self.m_fetcherJson fetch];
        
        // AI is dismissed in the delegate.
        [[Utilities getAppDel] showAi];
        
        /*
        TutorialViewController *tv = [[TutorialViewController alloc] initWithMode:NO];//[[TutorialViewController alloc]initWithNibName:@"TutorialViewController" bundle:nil];
        tv.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentModalViewController:tv animated:YES];
        isTutorialNeeded=NO;
         */
    } else {
        [self setPasscodeFinished:YES];
    }
    
    //[self setPasscodeFinished:YES];
    /*
    //surya Bug Fix DE78 start
    NSAssert(self.modalViewController, @"modal dlg should exist");
    
    [self dismissModalViewControllerAnimated:NO];
    //if (m_vcAuth != nil)
    //{
    //    LOG("signOnComplete dismissModalViewControllerAnimated start");
    //    [m_vcAuth dismissModalViewControllerAnimated:NO];
    //    LOG("signOnComplete dismissModalViewControllerAnimated end");
    //}
    //surya Bug Fix DE78 end
    
	if (valid)
	{
        // for other app, not checking any more and skip device Registration
        // will directly save UID or token into Key chain 
        
        LOG("signOnComplete checkAuthorization start");
        [self checkAuthorization];
        LOG("signOnComplete checkAuthorization end");
        
        LOG("Auth check complete and saving value to KC!");
        AuthorizationMan* am = [AuthorizationMan get];
        
        // This informs the app that the passcode needs to be set.
        [am assignPC:@"-1"];
        
        // Save the keychain info now that the
        // device's UDID and APNS TOKEN have been registered in the server.
        // At this point isAuthorized is YES.
        
        [am saveValuesToKC];
        
        [self showSetPasscode];        
	}
    
   	else // cancel selected
	{
        
        // Abhinav
        // Go into Deauth state
        [self setState:NORCAL_QUESTION];
        
        //       [self checkAuthorization];
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"error at backend" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil , nil];
        //        [alert show];
        //        [alert release];
    }*/
    
    LOG("signOnComplete end");
}

#pragma mark -
// ABHI CHECK Passcode or Sign On view
-(void)AuthDone:(BOOL)valid{
    if (self.modalViewController)
    {
        [self dismissModalViewControllerAnimated:NO];
    }
    
    if (valid)
    {
        // [self checkServerStatus];
        
        // For release 1, we're going to bypass the server status check which
        // used to occur whenever the user enters his passcode. 
        // Bypass this by creating a phantom m_statusChecker object and sending
        // a success
        /*
        ContainerMan* cm = [ContainerMan get];
        
        if ([cm getDateState]==DATA_FRESH) { // only when the data is fresh, don't make the server check
            self.m_statusChecker = [[[ServerStatusCheck alloc] init] autorelease];
            self.m_statusChecker.delegate = self;
            
            // disable the actual network check. 
            // [self.m_statusChecker startCheck];
            
            LOG("faking the server status check since data is fresh!");
            [self postResult:WSC_GOOD sender:self.m_statusChecker];
        } else { // for other cases, the server check is necessary
            [self checkServerStatus];
        }*/
        [m_delegate dismissModal];         
        
    }
    // else -- invalid entries are handled by the dlg.

}



#pragma mark PasscodeViewControllerDelegate

- (void)passcodeFinished:(BOOL)valid
{
    if (self.modalViewController)
    {
        [self dismissModalViewControllerAnimated:NO];
    }
    
    if (valid)
    {
        // [self checkServerStatus];
        
        // For release 1, we're going to bypass the server status check which
        // used to occur whenever the user enters his passcode. 
        // Bypass this by creating a phantom m_statusChecker object and sending
        // a success
        /*
        ContainerMan* cm = [ContainerMan get];
        
        if ([cm getDateState]==DATA_FRESH) { // only when the data is fresh, don't make the server check
            self.m_statusChecker = [[[ServerStatusCheck alloc] init] autorelease];
            self.m_statusChecker.delegate = self;
            
            // disable the actual network check. 
            // [self.m_statusChecker startCheck];
            
            LOG("faking the server status check since data is fresh!");
            [self postResult:WSC_GOOD sender:self.m_statusChecker];
        } else { // for other cases, the server check is necessary
            [self checkServerStatus];
        }
         */
        [m_delegate dismissModal];         
        
    }
    // else -- invalid entries are handled by the dlg.
}

- (void)deauthorize
{
    // If exists, dismiss the Passcode set dlg.
    if (self.modalViewController)
    {
        [self dismissModalViewControllerAnimated:NO];
    }
    
    [[AuthorizationMan get] deauthorize];
    [self setState:DEAUTHORIZED];
    [[NSNotificationCenter defaultCenter] postNotificationName:DEVICE_DEACTIVATE_NOTIFICATION object:nil];
}

#pragma mark -
#pragma mark SetPasscodeViewControllerDelegate

- (void)setPasscodeFinished:(BOOL)confirmed
{
    if (!confirmed)
    {
    //    [[AuthorizationMan get] assignPC:@"0"];
    // make user to set passcode again if they click cancel, but this way the cancel button cannot make the passcode optional    
        [[AuthorizationMan get] reset];
    }
    
    // Send notification whether set or reset.
    [[NSNotificationCenter defaultCenter] postNotificationName:MCPasscodeLockEnableChangedNotification 
                                                        object:self];
    
    if (self.modalViewController)
    {
        [self dismissModalViewControllerAnimated:NO];
    }    
    
    if (confirmed) {
        // Now that passocode has been set...
        // reset the refresh date, so that the repository is cleaned (except for facs)
        // and repopulated with the current mrn's data.
        //[[ContainerMan get] resetRefreshDate];
        
        // Implementing Progress Bar
        
        // Abhinav
        // Register with HandshakeMan and populate data for this MRN.
        
        /*
        [[Utilities getAppDel] showInitiator:@"initializing, please wait ..."];
        [HandshakeMan get].delegate = self;
        if (NO == [[HandshakeMan get] shakeHandsIfNeeded])
        {
            [HandshakeMan get].delegate = nil;
        }
        */
        AuthorizationMan *am=[AuthorizationMan get];
        LOG("Dismissing modal! The final user name is: %@", am.userName);
        LOG("Dismissing modal! The final user id is: %@", am.userId);
        [m_delegate dismissModal];
    } else {
        [self setState:NORCAL_QUESTION];
        //12/29/11 surya commented as its confusing to send the user to non-member mode after cancel
        //[HandshakeMan get].delegate = self;
        
        //BOOL bRefreshing = [[HandshakeMan get] refreshFacilities];
        
        // Configure the main window for Facilities Only
        //[[Utilities getAppDel] setFacOnlyMode];
        
        //[self setState:COMPLETE];
        
        //if (NO == bRefreshing)
        //{
        //    [m_delegate dismissModal];
        //}        
    }
}

#pragma mark -
#pragma mark WSCheckDelegate

// Add a param to this callback where the sender is sent
- (void)postResult:(SERVER_STATUS_RESULT)nState sender:(id)sender
{
    // SSC returns:
    //    WSC_GOOD,
    //    WSC_DEAUTH,
    //    WSC_NOT_KP,
    //    WSC_FORCED_UP,
    //    WSC_NET_FAIL,
    //    WSC_WS_FAIL,
    
    // Merlin states:
    //    * INITIALIZE,
    //    NETWORK_FAILURE,
    //    DEAUTHORIZED,
    //    FORCED_UPDATE,
    //    * ROTTEN_DATA_LOCKOUT,
    //    WS_FAILURE,
    //
    // (* handled elsewhere)
    //
    
    // Hide the activity indicator
    [[Utilities getAppDel] hideAi];
    //    [[Utilities getAppDel] hideInitiator];
    
    [m_lbText setFont:[UIFont fontWithName:@"Helvetica" size:16]];
    
    LOG("Server Status %i", nState);
    
    switch (nState)
    {
        case WSC_GOOD:
            if (sender == self.m_statusChecker)
            {
                LOG("Status check complete");
                if ([[AuthorizationMan get] isAuthorized])
                {
                    
                    /*
                    [HandshakeMan get].delegate = self;
                    if ([[HandshakeMan get] shakeHandsIfNeeded])
                    {
                        // Refresh is needed. So, show UI and wait for delegate callback.
                        
                        // Abhinav
                        
                        [[Utilities getAppDel] showInitiator:@"refreshing data, please wait ..."];
                        
                    }
                    else
                    {
                        // Dismiss Merlin
                        [HandshakeMan get].delegate = nil;
                        [m_delegate dismissModal];
                    }*/
                    // may not be called
                    [m_delegate dismissModal];
                }
                else
                {
                    [self setState:AUTHORIZING];
                    [self showAuthView];
                }
            }
            else if (sender == self.m_authChecker)
            {
                LOG("Auth check complete");
                [self registerDevice];
            }
            else if (sender == self.m_authReg)
            {
                LOG("Auth Reg complete");
                AuthorizationMan* am = [AuthorizationMan get];
                
                // This informs the app that the passcode needs to be set.
                [am assignPC:@"-1"];
                
                // Save the keychain info now that the
                // device's UDID and APNS TOKEN have been registered in the server.
                // At this point isAuthorized is YES.
                
                [am saveValuesToKC];
                
                [self showSetPasscode];
            }
            else{
                // Abhinav
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Unable to parse from server. Please try again later." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil , nil];
                alert.tag = 420;
                [alert show];
                
                [alert release];
                
            }
            
            // else do nothing.
            
            break;
            
        case WSC_NOT_KP:
        case WSC_DEAUTH:
            self.deauthErrMsg=@"Your device has been deactivated. You can access your information upon re-activation.";
            [[AuthorizationMan get] deauthorize];
            [self setState:DEAUTHORIZED];
            break;
            
        case WSC_AUTHORIZE_FAIL:
            self.deauthErrMsg=@"Authorization failed. Please go to kp.org to activate your account. Your device has been deactivated and your data has been cleared from the device.";
            [[AuthorizationMan get] deauthorize];
            [self setState:DEAUTHORIZED];
            break;
            
        case WSC_AUTHENT_LOCKOUT:
            self.deauthErrMsg=@"There is a problem with your account. Please go to kp.org for details. Your device has been deactivated and your data has been cleared from the device.";
            [[AuthorizationMan get] deauthorize];
            [self setState:DEAUTHORIZED];
            break;
            
        case WSC_NOT_NCAL:
            self.deauthErrMsg=@"This app is available only to Kaiser Permanente members in Northern California at this time. Your device has been deactivated and your data has been cleared from the device.";
            [[AuthorizationMan get] deauthorize];
            [self setState:DEAUTHORIZED];
            break;
            
        case WSC_USERID_CHANGED:
            self.deauthErrMsg=@"It appears you've changed your kp.org user ID or password.  Your device has been deactivated and your data has been removed. Please reactivate to continue using this app.";
            [[AuthorizationMan get] deauthorize];
            [self setState:DEAUTHORIZED];
            break;    
            
            // Abhinav Sehgal - System Maintenance Check
        case WSC_SYS_MNTNC: 
            [m_lbText setFont:[UIFont fontWithName:@"Helvetica-Bold" size:16]];
            self.deauthErrMsg=@"KP Preventive Care is currently undergoing routine maintenance.  Please try again later.";
            if (![[AuthorizationMan get] isAuthorized])
            {
                [self setState:WS_FAILURE];
            }
            /*
            else if (DATA_ROTTEN == [[ContainerMan get] getDateState])
            {
                [self setState:ROTTEN_DATA_LOCKOUT_WS];
            }
            else if (DATA_EMPTY == [[ContainerMan get] getDateState])
            {
                [self setState:EMPTY_DATA_LOCKOUT_WS];
            }*/
            else
            {
                // Calculate badges and show data w/o update
                //[[BadgeMan get] calculateBadgeCounts];
                [m_delegate dismissModal];
            }
            break;   
            
        case WSC_FORCED_UP:
            [self setState:FORCED_UPDATE];
            break;
            
        case WSC_WS_FAIL:
            if (sender == self.m_statusChecker) {
                LOG("checkServerStatus returned WSC_WS_FAIL");
            }
            // Lock out only if data is rotten or if user is unauth
            if (![[AuthorizationMan get] isAuthorized])
            {
                [self setState:WS_FAILURE];
            }
            /*
            else if (DATA_ROTTEN == [[ContainerMan get] getDateState])
            {
                [self setState:ROTTEN_DATA_LOCKOUT_WS];
            }
            else if (DATA_EMPTY == [[ContainerMan get] getDateState])
            {
                [self setState:EMPTY_DATA_LOCKOUT_WS];
            }*/
            else
            {
                // Calculate badges and show data w/o update
                //[[BadgeMan get] calculateBadgeCounts];
                [m_delegate dismissModal];
            }
            break;
            
        case WSC_NET_FAIL:
            if (sender == self.m_statusChecker) {
                LOG("checkServerStatus returned WSC_NET_FAIL");
            }
            // Lock out only if data is rotten or if user is unauth
            if (![[AuthorizationMan get] isAuthorized])
            {
                [self setState:NETWORK_FAILURE];
            }
            /*
            else if (DATA_ROTTEN == [[ContainerMan get] getDateState])
            {
                [self setState:ROTTEN_DATA_LOCKOUT_NET];
            }
            else if (DATA_EMPTY == [[ContainerMan get] getDateState])
            {
                [self setState:EMPTY_DATA_LOCKOUT_NET];
            }*/
            else
            {
                // Calculate badges and show data w/o update
                //[[BadgeMan get] calculateBadgeCounts];
                [m_delegate dismissModal];
            }
            break;
            
        default:
            NSAssert(NO, @"Undefined return value");
            break;
    }
    
    if (sender == self.m_authChecker)
    {
        self.m_authChecker = nil;
    }
    else if (sender == self.m_authReg)
    {
        self.m_authReg = nil;
    }
    else if (sender == self.m_statusChecker)
    {
        self.m_statusChecker = nil;
    }
    
}

#pragma mark -
#pragma mark HandshakeManDelegate
/*

- (void)handshakeManSucceeded:(HandshakeMan*)hm
{
    hm.delegate = nil;
    [m_delegate dismissModal];
    [[Utilities getAppDel] hideInitiator];
}*/

/*
- (void)handshakeMan:(HandshakeMan*)hm failedWithError:(int)err
{
    switch (err)
    {
        case WSC_AUTHORIZE_FAIL:
        case WSC_AUTHENT_LOCKOUT:
        case WSC_USERID_CHANGED:
        case WSC_NOT_NCAL:
        case WSC_DEAUTH: 
        case WSC_FORCED_UP:
            [self postResult:err sender:self];            
            break;
            
        case WSC_NET_FAIL:
        case WSC_WS_FAIL:
        case FF_FAILED:
        case FF_CANCELED:
        case FF_TIMEOUT:
            if ([[AuthorizationMan get] isAuthorized])
            {
                WIZARD_STATE nWS = (WSC_WS_FAIL == err) ? WS_FAILURE : NETWORK_FAILURE; 
                
                // Lock out only if data is rotten
                if (DATA_ROTTEN == [[ContainerMan get] getDateState] || DATA_EMPTY == [[ContainerMan get] getDateState])
                    [self setState:nWS];
                else
                    [m_delegate dismissModal];
            }
            else
            {
                // This is a delegate call, but not called from delegate client.
                [self postResult:WSC_NET_FAIL sender:self];
            }
            break;
            
        case FAC_POPULATION_FAILED:
            [m_delegate dismissModal];
            break;
            
        default:
            NSAssert1(NO, @"unexpected error:%d", err);
            break;
    }
    
    hm.delegate = nil;
    [[Utilities getAppDel] hideInitiator];
}*/

- (double)getLastMemberMedsSyncTime;
{
    return [m_delegate getLastMemberMedsSyncTime];
}

#pragma mark -
#pragma mark Fetcher Delegate Methods

- (BOOL)fetcher:(Fetcher*)fetcher didSucceedWithValue:(id)value
{
    [[Utilities getAppDel] hideAi];
    
    if (![value isKindOfClass:[NSDictionary class]])
    {
        LOG("error in web service %@", value);
        return NO;
    }
    
    if (value != nil) {
        //NSDictionary* dResponse = [value objectForKey:@"response"];
        NSDictionary *dValue=(NSDictionary *)value;
        LOG("The response is: %@", dValue);
        SBJsonWriter *jsonWriter = [[SBJsonWriter alloc] init];
        
        NSString *jsonString = [jsonWriter stringWithObject:dValue];
        
        NSString *filePath=[self getTutorialJsonFilePath];
        
        NSError *error;
        if ([jsonString writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:&error]) {
            LOG("tutorial.json file created!");
        } else {
            LOG("Unresolved error %@, %@", error, [error userInfo]);
        }
        
        [self checkTutorialContentFile];
        
        [self invokeTutorialVC];
        
        [jsonWriter release];
    }
    
    return YES;
}

- (BOOL)fetcher:(Fetcher*)fetcher didFailWithError:(FETCHER_FAILURE)value
{
    [[Utilities getAppDel] hideAi];
    // invoke tutorial with old json
    [self checkTutorialContentFile];
    [self invokeTutorialVC];
    return YES;
}

- (void)invokeTutorialVC
{
    TutorialViewController *tv = [[TutorialViewController alloc] initWithMode:NO];
    tv.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:tv animated:YES];
    isTutorialNeeded=NO;
}

- (void)checkTutorialContentFile
{
    // make sure the tutorial json file exist in document folder
    NSString *filePath=[self getTutorialJsonFilePath];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        if ([[NSFileManager defaultManager] copyItemAtPath:[[NSBundle mainBundle] pathForResource:@"tutorial" ofType:@"json"] toPath:filePath error:nil]) {
            LOG("tutorial.json file copied!");
        } else {
            LOG("no tutorial.json file for screen text!");
        }
    }
}

- (NSString *)getTutorialJsonFilePath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath= [NSString stringWithFormat:@"%@/%@", documentsDirectory, @"tutorial.json"];
    LOG("tutorial json filePath %@", filePath);
    return filePath;
}


@end
