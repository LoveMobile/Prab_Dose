//
//  VCInitiator.h
//  MobileCare
//
//  Created by Zhanquan He on 11/25/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VCInitiator : UIViewController
{
	NSString* m_szText;
	UILabel* m_lbText;
	UIActivityIndicatorView* m_ai;
    
	BOOL m_bShowing;
    
//    UIImageView *imgBGView;
    NSTimer *timer_Progress;
    UIProgressView *_progressView;
    double double_timerProgress;
    
    
}

@property (nonatomic, retain) NSString* m_szText;
@property (nonatomic, retain) IBOutlet UILabel* m_lbText;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView* m_ai;
@property (nonatomic, retain) NSTimer *timer_Progress;
@property (nonatomic, retain) UIProgressView *_progressView;

- (id)init;
- (id)initWithText:(NSString*)szText;
- (void)setText:(NSString*)szText;
- (void)show;
- (void)showWithoutBackground;
- (void)hide;
- (void)hideWithNoAnimation;
- (void)drawText;
-(void)action_progressBar;

@end
