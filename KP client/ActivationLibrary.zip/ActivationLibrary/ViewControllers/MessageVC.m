//
//  MessageVC.m
//  ActivationLibrary
//
//  Created by Zhanquan He on 9/10/12.
//  Copyright (c) 2012 Kaiser. All rights reserved.
//

#import "MessageVC.h"
#import "MobileCareAppDelegate.h"

@implementation MessageVC
@synthesize m_lblMessage;
@synthesize m_btnRetry;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    self.m_lblMessage = nil;
    self.m_btnRetry = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)show
{
    int_showMessage = 1;
    
    self.view.hidden = NO;
    
    //self.view.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:.5];
    //self.view.backgroundColor = [UIColor colorWithRed:127/255.0f green:190/255.0f blue:245/255.0f alpha:0.4];
    
	self.m_lblMessage.alpha = 1;
	self.m_btnRetry.alpha = 1;
	self.view.alpha = 1;
}

- (void)hide
{
	int_showMessage = 0;
    
	self.m_lblMessage.alpha = 0;
	self.m_btnRetry.alpha = 0;
	self.view.alpha = 0;
}

- (void)showMessage:(NSString*)szMessage withButtonText:(NSString*)btText target:(id)t andSelector:(SEL)sel
{    
    int_showMessage = 1;
    self.view.hidden = NO;
    
	self.m_lblMessage.alpha = 1;
	self.m_btnRetry.alpha =1;
	self.view.alpha = 1;
    
    self.m_lblMessage.text=szMessage;   
    
    if (nil == btText)
    {
        self.m_btnRetry.hidden = YES;
    }
    else
    {
        
        [self.m_btnRetry setTitle:btText forState:UIControlStateNormal];
        [self.m_btnRetry setFrame:CGRectMake(20, 340, 280, 35)];
        [self.m_btnRetry setBackgroundImage:[[UIImage imageNamed:@"bkgd_button_blue.png"]
                                              stretchableImageWithLeftCapWidth:10.0f
                                              topCapHeight:0.0f]
                                    forState:UIControlStateNormal];
        [self.m_btnRetry setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];      
        self.m_btnRetry.titleLabel.shadowColor = [UIColor lightGrayColor];
        self.m_btnRetry.titleLabel.shadowOffset = CGSizeMake(0, -1); 
        
        
        // Clear all the previously assigned control events.
        [self.m_btnRetry removeTarget:nil 
                                action:NULL 
                      forControlEvents:UIControlEventAllEvents];
        
        if (t == nil)
        {
            [self.m_btnRetry addTarget:self 
                                 action:@selector(authoizeButtonPressed:) 
                       forControlEvents:UIControlEventTouchUpInside];
        }
        else
        {
            [self.m_btnRetry addTarget:t 
                                 action:sel 
                       forControlEvents:UIControlEventTouchUpInside];
        }
    }
    
}

- (void)showMessage:(NSString*)szMessage withButtonText:(NSString*)btText
{
    int_showMessage = 1;
    [self showMessage:szMessage withButtonText:btText target:nil andSelector:nil];    
}

- (void)showMessage:(NSString*)szMessage
{
    int_showMessage = 1;
    [self showMessage:szMessage withButtonText:nil];
}

@end
