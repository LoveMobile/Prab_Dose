//
//  TermsAndConditionsViewController.m
//  MobileCare
//
//  Created by Sean Gilligan on 1/12/11.
//  Copyright 2011 Fingerpaint Labs. All rights reserved.
//

#import "TermsAndConditionsViewController.h"
#import "WebServiceMan.h"
#import "AuthorizationMan.h"
#import "Utilities.h"
#import "Constants.h"
#import "PrivacyPracticesViewController.h"

@implementation TermsAndConditionsViewController

- (void)pop
{
    /*
    if (intPrivacy == 2) {
        intPrivacy = 0;
        [[Utilities getAppDel] hideAi];

        [self dismissModalViewControllerAnimated:YES];
    }
    else
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"_fromLandingView"]) {
        [self.navigationController popViewControllerAnimated:YES];
        [Utilities getAppDel].tabBarController.selectedIndex = 0;
        [Utilities action_TransitionFromLeft];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }*/
    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"_fromLandingView"]) {
        [self.navigationController popViewControllerAnimated:YES];
        [Utilities getAppDel].tabBarController.selectedIndex = 0;
        [Utilities action_TransitionFromLeft];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}

-(void)viewWillAppear:(BOOL)animated{
    
    
    
//    if (int_showTermsNavbar == 1) {
//        
//        UIImage* image3 = [UIImage imageNamed:@"icon_bkgd_back-arow.png"];
//        CGRect frameimg = CGRectMake(0, -20, 40, 30);
//        UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
//        [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
//        [someButton addTarget:self action:@selector(pop)
//             forControlEvents:UIControlEventTouchUpInside];
//        UIBarButtonItem *m_barSomeButton = [[UIBarButtonItem alloc] initWithCustomView:someButton];
//        self.navigationItem.leftBarButtonItem = m_barSomeButton;
//        [m_barSomeButton release];
//        [someButton release];
//        
//        UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]];
//        self.view.backgroundColor = background;
//        [background release];
//
//        int_showTermsNavbar = 0;
//        self.view.frame = CGRectMake(0, 60, 320, 568);
//        
//    }
    
    
    self.title = @"Terms & Conditions";
    // Google Analyser
    [Utilities postGATrackPageName:@"Terms&ConditionViewClicked"];
    
    if (int_showMessage == 1) {
        int_showMessage = 0;
        [[Utilities getAppDel] hideMessage];
    }
    
    if (self.networkError) {
        //[[Utilities getAppDel].m_msgVC show]; 
        [self loadWebView];
    }
    
}

// Load the UIWebView using the configured mode
- (void)loadWebView
{
    if (int_showMessage == 1) {
        int_showMessage = 0;
        [[Utilities getAppDel] hideMessage];
    }
    UIImage* image3 = [UIImage imageNamed:@"icon_bkgd_back-arow.png"];
    CGRect frameimg = CGRectMake(0, 0, 40, 30);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(pop)
         forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *m_barSomeButton = [[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem = m_barSomeButton;
    [m_barSomeButton release];
    [someButton release];
    
    UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]];
	self.view.backgroundColor = background;
    [background release];

    self.m_webView.dataDetectorTypes = 0;
    WebServiceMan* wsm = [WebServiceMan get];
    
    NSString *urlString = [NSString stringWithFormat:@"%@/%@%@", 
                           wsm.wsBaseUrl, 
                           @"getTermsAndConditions?appId=", wsm.appId];
    
    LOG("The T&C url is: %@", urlString);
    
	NSURL *url = [NSURL URLWithString:urlString];
    
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    self.curRequest=request;
	[self.m_webView loadRequest:request];
}

- (BOOL)webView:(UIWebView *)webView2 shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType 
{
    BOOL ret=YES;
    
    NSURL *url=[request URL];
    NSString *schemeStr=[url scheme];
    NSString *fullStr=[url absoluteString];
    
    
    if ([schemeStr isEqualToString:@"mailto"]) {
        NSString *recipient=[fullStr substringFromIndex:7];
        NSArray *recipients=[NSArray arrayWithObject:recipient];
        LOG("receipient: %@", recipients);
        if ([MFMailComposeViewController canSendMail])
        {
            [self displayComposerSheet:recipients];
        }
        else
        {
            [self launchMailAppOnDevice:recipient];
        }
        return NO;
    }
    else if([fullStr isEqualToString:@"mobilecare:privacy"]){
        intPrivacy = 1;
        PrivacyPracticesViewController *obj = [[PrivacyPracticesViewController alloc]initWithNibName:@"PrivacyPracticesViewController" bundle:nil];
        [self.navigationController pushViewController:obj animated:YES];
        
        return NO;
    }
    
    ret=[super webView:webView2 shouldStartLoadWithRequest:request navigationType:navigationType];
    
    return ret;
}

@end
