//
//  VCGeneralDialog.h
//  MobileCare
//
//  Created by Paul on 5/5/11.
//  Copyright 2011 Appstem. All rights reserved.
//
//  This VC is intenteded to be used modally 
//

#import <UIKit/UIKit.h>
#import "PasscodeViewController.h"
#import "Fetcher.h"
#import "AuthorizationViewController.h"
#import "SetPasscodeViewController.h"
#import "VCActivityIndicator.h"
#import "ServerStatusCheck.h"
#import "AuthorizationCheck.h"
#import "AuthorizationReg.h"
#import "WarningViewController.h"
#import "FetcherJson.h"
//#import "HandshakeMan.h"


typedef enum
{
    INITIALIZE,
    NORCAL_QUESTION,  // dont know if I like this.
    AUTHORIZING,
    NETWORK_FAILURE,
    DEAUTHORIZED,
    FORCED_UPDATE,
    ROTTEN_DATA_LOCKOUT_WS,
    ROTTEN_DATA_LOCKOUT_NET,
    EMPTY_DATA_LOCKOUT_WS,
    EMPTY_DATA_LOCKOUT_NET,
    WS_FAILURE,
    QA_PROD_QUESTION,
    COMPLETE,
} WIZARD_STATE;

#define ALERT_NORCAL 301
#define ALERT_DEAUTH 302

@protocol VCMerlinDelegate <NSObject>
- (void)dismissModal;
- (void)clearAllData;
- (double)getLastMemberMedsSyncTime;
@end

@interface VCGeneralDialog : UIViewController<PasscodeViewControllerDelegate, WarningViewControllerDelegate,
AuthorizationViewControllerDelegate,
SetPasscodeViewControllerDelegate,
WSCheckDelegate, FetcherDelegate>
//HandshakeManDelegate>
{
    WIZARD_STATE m_eState;
    UILabel* m_lbText;
    UIButton* m_bt1;
    UIButton* m_bt2;
    //    UIImageView* m_ivHeader;
    UIImageView* m_ivBanner;
    UIImageView *m_FooterIMG;
    AuthorizationCheck* m_authChecker;
    ServerStatusCheck* m_statusChecker;
    AuthorizationReg* m_authReg;
    //AuthorizationViewController* m_vcAuth;
    
    id<VCMerlinDelegate> m_delegate; // don't retain
    
     UILabel *lbl_member1;
     UILabel *lbl_member2;
     UILabel *lbl_member3;
     UILabel *lbl_member4;
     UILabel *lbl_member5;
     UILabel *lbl_member6;
     UILabel *lbl_member7;
     UILabel *lbl_member8;
     UIView *m_BGView;
     UILabel *lbl_member9;
     UILabel *lbl_member10;
    
    BOOL isIphone5;
    NSString * backgroundImage;
}

@property (nonatomic, retain) IBOutlet UILabel* m_lbText;
@property (nonatomic, retain) IBOutlet UIButton* m_bt1;
@property (nonatomic, retain) IBOutlet UIButton* m_bt2;
@property (nonatomic, retain) IBOutlet UIButton* m_bt3;
//@property (nonatomic, retain) IBOutlet UIImageView* m_ivHeader;
@property (nonatomic, retain) IBOutlet UIImageView* m_ivBanner;
@property (nonatomic, retain) ServerStatusCheck* m_statusChecker;
@property (nonatomic, retain) AuthorizationCheck* m_authChecker;
@property (nonatomic, retain) AuthorizationReg* m_authReg;
// Abhinav Sehgal - AuthorizationViewController objectproperty remove
//@property (nonatomic, retain) AuthorizationViewController* m_vcAuth;

@property (assign) id<VCMerlinDelegate> m_delegate;

@property (nonatomic, retain) IBOutlet UILabel *lbl_member1;
@property (nonatomic, retain) IBOutlet UILabel *lbl_member2;
@property (nonatomic, retain) IBOutlet UILabel *lbl_member3;
@property (nonatomic, retain) IBOutlet UILabel *lbl_member4;
@property (nonatomic, retain) IBOutlet UILabel *lbl_member5;
@property (nonatomic, retain) IBOutlet UILabel *lbl_member6;
@property (nonatomic, retain) IBOutlet UILabel *lbl_member7;
@property (nonatomic, retain) IBOutlet UILabel *lbl_member8;
@property (nonatomic, retain) IBOutlet UILabel *lbl_nonMember;
@property (nonatomic, retain) IBOutlet UIView *m_BGView;
@property (nonatomic, retain) IBOutlet UIView *m_nonMemberView;
@property (nonatomic, retain) IBOutlet UILabel *lbl_member9;
@property (nonatomic, retain) IBOutlet UILabel *lbl_member10;
@property (nonatomic, retain) IBOutlet UIImageView *m_FooterIMG;
@property (nonatomic, retain) NSString *deauthErrMsg;
@property (nonatomic, retain) FetcherJson* m_fetcherJson;


- (id)init;
- (id)initWithState:(WIZARD_STATE)eState;
- (void)showSetPasscode;
- (void)setState:(WIZARD_STATE)nState;
- (void)showAsModal:(UIViewController*)vc;
- (void)checkServerStatus;
- (IBAction)buttonPressed:(id)sender;


@end
