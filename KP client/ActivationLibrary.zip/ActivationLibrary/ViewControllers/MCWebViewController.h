//
//  MCWebViewController.h
//  MobileCare
//
//  Created by Zhanquan He on 7/18/11.
//  Copyright 2011 kaiser permanente. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

@interface MCWebViewController : UIViewController <UIWebViewDelegate, MFMailComposeViewControllerDelegate> {
    
}

@property (nonatomic, retain) IBOutlet UIWebView* m_webView;
@property (nonatomic, retain) NSURLRequest *curRequest;
@property (nonatomic, assign) BOOL networkError;

- (void)loadWebView;
-(void)launchMailAppOnDevice:(NSString *)recipient;
-(void)displayComposerSheet:(NSArray *)recipients;

@end
