//
//  SupportViewController.h
//  MobileCare
//
//  Created by Surya Pasula on 7/12/11.
//  Copyright 2011 TPMG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MCWebViewController.h"
#import "PhoneLinkHandler.h"


@interface SupportViewController : MCWebViewController {
    
}

@property (nonatomic, retain) PhoneLinkHandler *phoneHandler;

@end

