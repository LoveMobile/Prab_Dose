//
//  Constants.h
//  MobileCare
//
//  Created by Richard Bottoms on 3/5/11.
//  Copyright 2011 GlassHand Media. All rights reserved.
//

#define RGB(r, g, b)  [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1];
#define RGBA(r, g, b, a)  [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a];
#define kHostName @"http://www.kp.org"
#define kHost @"kp.org"
#define DEVICE_DEACTIVATE_NOTIFICATION @"DeviceDeactivateNotification"

#ifdef KPLOGGING
#define LOG(fmt, ...) NSLog(@fmt, ##__VA_ARGS__)
#else
#define LOG(fmt, ...) 
#endif  


@protocol VCRootListDelegate <NSObject>
- (void)pushViewController:(UIViewController*)vc;
@end
