//
//  EncryptDecryptTransferableType.m
//  MobileCare
//
//  Created by Hursh Prasad on 4/21/11.
//  Copyright 2011 AppStem, Inc. All rights reserved.
//

#import "EncryptDecryptTransferableStringType.h"
#import "Constants.h"

@implementation EncryptDecryptTransferableStringType
+ (Class)transformedValueClass {
   return [NSData class];
}
+ (BOOL)allowsReverseTransformation {
    return YES;
}
- (NSString *)encryptString:(NSString *)value{    
#if TARGET_IPHONE_SIMULATOR
    return value;
#else
    NSData *data = [value dataUsingEncoding:NSISOLatin1StringEncoding];
    
    NSData *symKey = [[SecKeyWrapper sharedWrapper] getSymmetricKeyBytes];
   
    //If key has not been generate for device then generate and add to keychain
    if (symKey == NULL) {
            [[SecKeyWrapper sharedWrapper] generateSymmetricKey];
            symKey = [[SecKeyWrapper sharedWrapper] getSymmetricKeyBytes];
    }
    
    CCOptions pad = 0;
    
    NSData *encryptedData = [[SecKeyWrapper sharedWrapper] doCipher:data key:symKey context:kCCEncrypt padding:&pad];
    
    LOG("The encrypted data is %@", encryptedData);
    
    NSString *encryptedString = [[[NSString alloc] initWithData:encryptedData encoding:NSISOLatin1StringEncoding] autorelease];
                    
    return encryptedString;
#endif
}

- (NSString *)encryptString:(NSString *)value withKey:(NSString *)key{    
#if TARGET_IPHONE_SIMULATOR
    return value;
#else
    NSAssert(nil!=key, @"key should not be nil");
    
    NSData *data = [value dataUsingEncoding:NSISOLatin1StringEncoding];
    
    NSData *keyData = [key dataUsingEncoding:NSISOLatin1StringEncoding];
    
    CCOptions pad = 0;
    
    NSData *encryptedData = [[SecKeyWrapper sharedWrapper] doCipher:data key:keyData context:kCCEncrypt padding:&pad];
    
    LOG("The encrypted data is %@", encryptedData);
    
    NSString *encryptedString = [[[NSString alloc] initWithData:encryptedData encoding:NSISOLatin1StringEncoding] autorelease];
    
    return encryptedString;
#endif
}

- (NSString *)decryptString:(NSString *)value{
#if TARGET_IPHONE_SIMULATOR
    return value; 
#else    
    NSData *data = [value dataUsingEncoding:NSISOLatin1StringEncoding];
    
    NSData *symKey = [[SecKeyWrapper sharedWrapper] getSymmetricKeyBytes];
    
    CCOptions pad = 0;
    
    NSData *decryptedData = [[SecKeyWrapper sharedWrapper] doCipher:data key:symKey context:kCCDecrypt padding:&pad];
    LOG("The decrypted data is %@", decryptedData);
    
    NSString *decryptedString = [[[NSString alloc] initWithData:decryptedData encoding:NSISOLatin1StringEncoding] autorelease];
    
    NSString *trimmedString = [decryptedString stringByTrimmingCharactersInSet:[NSCharacterSet controlCharacterSet]];
    return trimmedString;

#endif
}

- (NSString *)decryptString:(NSString *)value withKey:(NSString *)key{
#if TARGET_IPHONE_SIMULATOR
    return value; 
#else    
    NSAssert(nil!=key, @"key should not be nil");
    
    NSData *data = [value dataUsingEncoding:NSISOLatin1StringEncoding];
    
    NSData *keyData = [key dataUsingEncoding:NSISOLatin1StringEncoding];
    
    CCOptions pad = 0;
    
    NSData *decryptedData = [[SecKeyWrapper sharedWrapper] doCipher:data key:keyData context:kCCDecrypt padding:&pad];
    LOG("The decrypted data is %@", decryptedData);
    
    NSString *decryptedString = [[[NSString alloc] initWithData:decryptedData encoding:NSISOLatin1StringEncoding] autorelease];
    
    NSString *trimmedString = [decryptedString stringByTrimmingCharactersInSet:[NSCharacterSet controlCharacterSet]];
    return trimmedString;
    
#endif
}

- (id)transformedValue:(id)value{    
#if TARGET_IPHONE_SIMULATOR
    return [(NSString *)value dataUsingEncoding:NSASCIIStringEncoding];
#else
    NSData *data = [(NSString *)value dataUsingEncoding:NSASCIIStringEncoding];
    
    NSData *symKey = [[SecKeyWrapper sharedWrapper] getSymmetricKeyBytes];
    
    //If key has not been generate for device then generate and add to keychain
    if (symKey == NULL) {
        [[SecKeyWrapper sharedWrapper] generateSymmetricKey];
        symKey = [[SecKeyWrapper sharedWrapper] getSymmetricKeyBytes];
    }
    
    CCOptions pad = 0;
    
    NSData *encryptedData = [[SecKeyWrapper sharedWrapper] doCipher:data key:symKey context:kCCEncrypt padding:&pad];
    
    return encryptedData;
#endif
}

                    
- (id)reverseTransformedValue:(id)value{
#if TARGET_IPHONE_SIMULATOR
    return [[[NSString alloc] initWithData:value encoding:NSASCIIStringEncoding] autorelease]; 
#else    

    NSData *symKey = [[SecKeyWrapper sharedWrapper] getSymmetricKeyBytes];
    
    CCOptions pad = 0;
    
    NSData *decryptedData = [[SecKeyWrapper sharedWrapper] doCipher:(NSData *)value key:symKey context:kCCDecrypt padding:&pad];
    
    NSString *str = [[[NSString alloc] initWithData:decryptedData encoding:NSASCIIStringEncoding] autorelease];
    NSString *trimmedString = [str stringByTrimmingCharactersInSet:[NSCharacterSet controlCharacterSet]];
    return trimmedString;
    
#endif
}



@end