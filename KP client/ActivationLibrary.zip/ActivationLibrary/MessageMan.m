//
//  MessageMan.m
//  HOS
//
//  Created by Paul on 7/14/10.
//  Copyright 2010 Paiego. All rights reserved.
//

#import "MessageMan.h"
#import "Utilities.h"

#define ERROR_TITLE [NSString stringWithFormat:@"%@ Error", [[Utilities getAppDel] getAppDisplayName]]

@implementation MessageMan

+ (void)showMessage:(NSString*)szMessage
{
	[MessageMan showMessage:szMessage withTitle:ERROR_TITLE];
}

+ (void)showYesNoMessage:(NSString*)szMessage withTitle:(NSString*)szTitle andDelegate:(id<UIAlertViewDelegate>)del
{
    [self showYesNoMessage:szMessage withTitle:szTitle tag:0 andDelegate:del];
}

+ (void)showYesNoMessage:(NSString*)szMessage withTitle:(NSString*)szTitle tag:(NSInteger)tag andDelegate:(id<UIAlertViewDelegate>)del
{

	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:szTitle 
													 message:szMessage 
													delegate:del
										   cancelButtonTitle:@"Yes" 
										   otherButtonTitles:@"No", nil] autorelease];
    alert.tag = tag;
    
	[alert show];
}


+ (void)showMessage:(NSString*)szMessage withTitle:(NSString*)szTitle
{

	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:szTitle 
													 message:szMessage 
													delegate:self 
										   cancelButtonTitle:@"OK" 
										   otherButtonTitles:nil] autorelease];
	[alert show];
}

+ (void)showNetworkErrorMessage
{

	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:ERROR_TITLE 
													 message:@"We are having trouble establishing a nework connection. Please try again later."
													delegate:self 
										   cancelButtonTitle:@"Retry" 
										   otherButtonTitles:nil] autorelease];
	[alert show];

}


@end
