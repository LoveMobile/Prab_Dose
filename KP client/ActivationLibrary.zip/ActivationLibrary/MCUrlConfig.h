//
//  MCUrlConfig.h
//  MobileCare
//
//  Created by Sean Gilligan on 12/3/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MCUrlConfig : NSObject

//@property (nonatomic, retain) NSString *ssoURL;
@property (nonatomic, retain) NSString *wsBaseURL;
@property (nonatomic, retain) NSString *webBaseURL;

- (id)initWithKey:(NSString *)key;

@end
