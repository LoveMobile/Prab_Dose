//
//  MessageMan.h
//  HOS
//
//  Created by Paul on 7/14/10.
//  Copyright 2010 Paiego. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageMan : NSObject 
{
}

+ (void)showMessage:(NSString*)szMessage;
+ (void)showMessage:(NSString*)szMessage withTitle:(NSString*)szTitle;
+ (void)showNetworkErrorMessage;
+ (void)showYesNoMessage:(NSString*)szMessage withTitle:(NSString*)szTitle andDelegate:(id<UIAlertViewDelegate>)del;
+ (void)showYesNoMessage:(NSString*)szMessage withTitle:(NSString*)szTitle tag:(NSInteger)tag andDelegate:(id<UIAlertViewDelegate>)del;

@end
