//
//  LandingViewCell.h
//  MobileCare
//
//  Created by Abhinav Sehgal.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LandingViewCell : UITableViewCell{
    
}
@property (retain, nonatomic) IBOutlet UIImageView *m_image;
@property (retain, nonatomic) IBOutlet UILabel *m_lbl;

@end
