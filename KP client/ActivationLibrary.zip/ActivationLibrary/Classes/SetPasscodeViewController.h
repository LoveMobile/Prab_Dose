//
//  PhoneAuthorizeView.h
//  MobileCare
//
//  Created by Sean Gilligan on 10/11/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//
//  Redone by pcy.
//
#import <UIKit/UIKit.h>
#import "MCPasscodeView.h"
#import "PDColoredProgressView.h"


@protocol SetPasscodeViewControllerDelegate
- (void)setPasscodeFinished:(BOOL)confirmed;
@end

@interface SetPasscodeViewController : UIViewController <UITextFieldDelegate, MCPasscodeViewDelegate>
{
    UIView					*scrollView;
    
	MCPasscodeView			*codeView1;
	MCPasscodeView			*codeView2;
	NSString				*enteredCode1;
	IBOutlet UIButton		*buttonContinue;
	IBOutlet UIButton		*buttonCancel;
	id<SetPasscodeViewControllerDelegate> delegate;
    
    //    enter first time
    
    UIView *m_passCodeCustomView;
    NSString *str_enteredCode;
    UITextField *txt_passCode;
    UILabel *lbl_dynamicNewReenter;
    
    UILabel *lbl_errorDescription;
    UILabel *lbl_static2;
    UILabel *lbl_strength;
    // IBOutlet UIProgressView *m_codeStatus;
    PDColoredProgressView *progressView;
    // Re enter code
    
    IBOutlet UIButton *btn_cancelNew;
    IBOutlet UIButton *btn_doneNew;
    IBOutlet UIView *m_desinBtnView;
    UILabel *lbl_text2;
    UILabel *lbl_text1;
    UILabel *lbl_Title;
    UILabel *lbl_noMatch;
    NSString *str_reEnteredCode;
    UIView *m_rePassCodeCustomView;
    UITextField *txt_rePasscode;
    int int_error;
    int int_reEnter;
}
@property (nonatomic, retain) IBOutlet UIButton *btn_cancelNew;
@property (nonatomic, retain) IBOutlet UILabel *lbl_errorDescription;
@property (nonatomic, assign) BOOL                  changePasscode;
@property (nonatomic, assign) BOOL                  activateEnterPasscode;
@property (nonatomic, assign) BOOL                  weakPIN;
@property (nonatomic, retain) IBOutlet UIImageView  *bkgImgView;
@property (nonatomic, retain) IBOutlet UILabel      *lbMessage;
@property (nonatomic, retain) IBOutlet UIButton *btn_doneNew;
@property (nonatomic, retain) IBOutlet UIButton *btn_skipNew;
@property (nonatomic, retain) IBOutlet UIView *m_desinBtnView;
@property (nonatomic , retain) IBOutlet UIView *m_passCodeCustomView;
@property (nonatomic , retain) PDColoredProgressView *progressView;

@property (nonatomic , retain) IBOutlet UITextField *txt_passCode;
@property (nonatomic , retain) IBOutlet UILabel *lbl_dynamicNewReenter;
@property (nonatomic , retain) IBOutlet UILabel *lbl_static2;
@property (nonatomic , retain) IBOutlet UILabel *lbl_strength;

@property (nonatomic , retain) IBOutlet UILabel *lbl_text2;
@property (nonatomic , retain) IBOutlet UILabel *lbl_text1;
@property (nonatomic , retain) IBOutlet UILabel *lbl_Title;
@property (nonatomic , retain) IBOutlet UILabel *lbl_noMatch;
@property (nonatomic , retain) IBOutlet UIView *m_rePassCodeCustomView;
@property (nonatomic , retain) IBOutlet UITextField *txt_rePasscode;

@property (nonatomic, retain) IBOutlet  UIView *m_errorPasscodeView;
@property (nonatomic , retain) IBOutlet UILabel *lbl_errorTitle;
@property (nonatomic , retain) IBOutlet UILabel *lbl_errorMsg;


-(void)validatestrengthMeter:(NSString *)codeVal;
- (id)initWithDelegate:(id<SetPasscodeViewControllerDelegate>)del;
- (void)touchCancel;
- (IBAction)touchContinue:(id)sender;
- (IBAction)startOver:(id)sender;
-(void)action_SetPassCodeView;
-(BOOL)isValidCodeEntered:(NSString *)text;
@end