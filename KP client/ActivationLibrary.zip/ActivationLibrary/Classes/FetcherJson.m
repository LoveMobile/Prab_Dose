//
//  FetcherJson.m
//  MobileCare
//
//  Created by Paul on 5/18/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "FetcherJson.h"
#import "JSON.h"
#import "NetworkMan.h"
#import "Constants.h"

@implementation FetcherJson

@synthesize m_szMethod;
@synthesize m_dParams;

- (id)initWithMethod:(NSString *)szMethod andParams:(NSDictionary *)dParams 
{
    self = [super init];
    if (self)
    {
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(cleanup)
                                                     name:kNotification_FetcherJson_CancelConnection object:nil];
        self.m_szMethod = szMethod;
        self.m_dParams = dParams;
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kNotification_FetcherJson_CancelConnection object:nil];
    
    self.m_szMethod = nil;
    self.m_dParams = nil;
    [super dealloc];
}

- (void)fetch
{
    [super fetch];

    NSURL* url = [NetworkMan makeURLWithMethod:m_szMethod];
    
    LOG("profile:fetching method : %@", self.m_szMethod);
    
    self.m_nsUrlConnection = [NetworkMan getResultFromUrl:url withMethod:m_szMethod withParams:m_dParams andDelegate:self];
}

// Called by Main Thread
- (void)informDelegate:(NSDictionary*)dRoot
{
    LOG("In informDelegate of FetcherJson %@: ", dRoot);
    NSDictionary* dResponse = [dRoot objectForKey:@"response"];
    LOG("profile:fetching complete : %@  with status code: %@", self.m_szMethod, [dResponse objectForKey:@"statusCode"]);
    LOG("Is the delegate is null? %@", (self.delegate==nil? @"YES":@"NO"));
    [self.delegate fetcher:self didSucceedWithValue:dRoot];
    [self cleanup];
}

// Called by BG Thread
- (void)extract
{
    NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
    
    NSString* szData = [[[NSString alloc] initWithData:m_msdData encoding:NSUTF8StringEncoding] autorelease];
    
    // Parse the JSON string into an object - assuming json_string is a NSString of JSON data
    SBJsonParser* parser = [[[SBJsonParser alloc] init] autorelease];
    
    // Assume top-level dictionary
    NSDictionary* dRoot = [parser objectWithString:szData error:nil];
        
    // Make this synchronous to retain autoreleased objects.
    [self performSelectorOnMainThread:@selector(informDelegate:) withObject:dRoot waitUntilDone:YES];
    
    [pool release];
}

@end