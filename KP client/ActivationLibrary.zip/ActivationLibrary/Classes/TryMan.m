//
//  TryMan.m
//  MobileCare
//
//  Created by Paul Yago on 6/10/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "TryMan.h"
#import "KeychainItemWrapper.h"

@implementation TryMan

@synthesize usedTries = m_nUsedTries;

+ (TryMan*)tryMan
{
    return [[[TryMan alloc] init] autorelease];
}

- (id)initWithMaxTries:(int)nMaxTries
{
    self = [super init];
    if (self)
    {
        KeychainItemWrapper* kiw = [[[KeychainItemWrapper alloc] initWithIdentifier:UD_KEY_USED_TRIES 
                                                                        accessGroup:nil] autorelease];
        NSString *usedTriesStr = [kiw objectForKey:(id)kSecAttrService];
        m_nUsedTries=[usedTriesStr intValue];
        
        // removed per security recommendation
        // m_nUsedTries = [[NSUserDefaults standardUserDefaults] integerForKey:UD_KEY_USED_TRIES]; 
        m_nMaxTries = nMaxTries;
    }
    return self;
}

- (id)init
{
    return [self initWithMaxTries:PASSCODE_MAX_TRIES];
}

- (void)addTry
{
    m_nUsedTries++;
    KeychainItemWrapper* kiw = [[[KeychainItemWrapper alloc] initWithIdentifier:UD_KEY_USED_TRIES 
                                                                    accessGroup:nil] autorelease];
    [kiw setObject:[NSString stringWithFormat:@"%d", m_nUsedTries] forKey:(id)kSecAttrService]; 
}

- (int)tryUsed
{
    return m_nUsedTries;
}

- (int)hasTries
{
    return m_nMaxTries - m_nUsedTries;
}

- (void)reset
{
    m_nUsedTries = 0;
    
    KeychainItemWrapper* kiw = [[[KeychainItemWrapper alloc] initWithIdentifier:UD_KEY_USED_TRIES 
                                                                    accessGroup:nil] autorelease];
    [kiw setObject:[NSString stringWithFormat:@"%d", m_nUsedTries] forKey:(id)kSecAttrService];
    
    // removed per security recommendation
    //    [[NSUserDefaults standardUserDefaults] setInteger:m_nUsedTries forKey:UD_KEY_USED_TRIES];
}

@end
