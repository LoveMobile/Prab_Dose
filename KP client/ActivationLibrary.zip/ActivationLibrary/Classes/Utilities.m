//
//  Utilities.m
//  MobileCare
//
//  Created by Paul on 4/21/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "Utilities.h"
//#import "Member.h"
//#import "CoreDataMan.h"
#import "FormatMan.h"
#import "JSON.h"
#import "Constants.h"
// US508 - Abhinav Sehgal
#import "UIDevice+IdentifierAddition.h"
#import "GANTracker.h"
#import "AuthorizationMan.h"
#import "IdleTimerMan.h"
#import <CommonCrypto/CommonDigest.h>

@implementation Utilities

+ (NSString*)getDocsPath
{
	NSArray* szPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	return [szPaths objectAtIndex:0];
}

+ (NSString*)getCachesPath
{
	NSArray* szPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	return [szPaths objectAtIndex:0];
}

+ (BOOL)isVersionSwipeable
{
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    return (version >= 3.2);
}

+ (MobileCareAppDelegate*)getAppDel
{
    return (MobileCareAppDelegate*)[[UIApplication sharedApplication] delegate];
}

+ (void)showVc:(UIViewController*)vcModal AsModalTo:(UIViewController*)vcBase
{
	//UINavigationController* nc = 
    //[[[UINavigationController alloc] initWithRootViewController:vcModal] autorelease];
	
    //nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
	//nc.navigationBar.tintColor = [Utilities getAppDel].navBarColor;
    
    [vcBase presentModalViewController:vcModal animated:YES];    
}

+ (NSString*)getTokenAsString:(NSData*)deviceToken
{
	const unsigned *tokenBytes = [deviceToken bytes];
	
    NSString *hexToken = [NSString stringWithFormat:@"%08X%08X%08X%08X%08X%08X%08X%08X",
                          ntohl(tokenBytes[0]), ntohl(tokenBytes[1]), ntohl(tokenBytes[2]),
                          ntohl(tokenBytes[3]), ntohl(tokenBytes[4]), ntohl(tokenBytes[5]),
                          ntohl(tokenBytes[6]), ntohl(tokenBytes[7])];
	return hexToken;
}

+ (NSString*) getTestMrn
{
    return @"11409864";
}

//----------------------------------------------------------------------------
// extracts hour/minutes/seconds from NSDate, converts to seconds since midnight
//----------------------------------------------------------------------------
+ (int)secondOfTheDay:(NSDate*)time
{
    NSCalendar* curCalendar = [NSCalendar currentCalendar];
    const unsigned units = NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    NSDateComponents* comps = [curCalendar components:units fromDate:time];
    int hour = [comps hour];
    int min  = [comps minute];
    int sec  = [comps second];
    
    return ((hour * 60) + min) * 60 + sec;
}

+ (NSDictionary*)getDeviceParamsDict
{
    // US508 - Abhinav Sehgal
    
    NSString *globalUniqueID = [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier];
    LOG("Global Unique id -> %@",globalUniqueID);
    
    NSString* szUdid = [[UIDevice currentDevice] uniqueIdentifier];
//    NSData* dtDeviceToken = [Utilities getAppDel].apnsDeviceToken;
    
    // Does it make sense that this device token is nil?
    // Why would the device token not be set in the app delegate?
    
    // Verify that device token exists.
    //    NSAssert(dtDeviceToken, @"device token should exist");
    
//    NSString* szTokenString = (dtDeviceToken) ? [Utilities getTokenAsString:dtDeviceToken] : @"no_token";    
    NSString* szTokenString = @"no_token";
    NSMutableDictionary* di = [NSMutableDictionary dictionaryWithCapacity:8];
    
    UIDevice* dev = [UIDevice currentDevice];
    
    //[di setValue:szUdid forKey:@"udid"];
    
    // US508 - Abhinav Sehgal
    // Now sending Global Unique ID
    [di setValue:globalUniqueID forKey:@"udid"];
    [di setValue:@"" forKey:@"phoneNumber"];
    
    //    
    //    NSString *safeDeviceName =[devicename stringByReplacingOccurrencesOfString:@"&" withString:@"-"];
    NSString *devicename= [[dev name] stringByReplacingOccurrencesOfString:@"’" withString:@"'"];
    NSString *safeDeviceName = [self formatIdentificationNumber:devicename];
    safeDeviceName = [safeDeviceName stringByReplacingOccurrencesOfString:@"," withString:@"-"];
    
    LOG("The old device name is %@ and the safe device name is :%@", [dev name], safeDeviceName);
    [di setValue:safeDeviceName forKey:@"deviceMake"];
    [di setValue:[dev systemName] forKey:@"deviceOs"];
    [di setValue:[dev systemVersion] forKey:@"deviceOsVersion"];
    [di setValue:szTokenString forKey:@"apnsToken"];
    [di setValue:[dev model] forKey:@"deviceModel"];
    
    //set debug mode depending on environment/debug/dist mode
    int debugMode = 0;
    
#if !TARGET_IPHONE_SIMULATOR
#if TOKEN_ENV_SANDBOX == 0
    LOG("TOKEN_ENV  is sandbox");
    debugMode = 1;
#endif
    
#if TOKEN_ENV_SANDBOX > 0
    LOG("TOKEN_ENV  is production");
    debugMode = 2;
#endif
#endif
    
    [di setValue:[NSNumber numberWithInt:debugMode] forKey:@"debugMode"];
    
    NSMutableDictionary* diHL = [NSMutableDictionary dictionaryWithCapacity:1];
    [diHL setValue:di forKey:@"deviceInfo"];
    
    SBJsonWriter* jw = [[[SBJsonWriter alloc] init] autorelease];
    
    NSError *error = nil;
    NSString* szJson = [jw stringWithObject:diHL error:&error];
    
    di = [NSMutableDictionary dictionaryWithCapacity:1];
    [di setValue:szJson forKey:@"dataInput"];
    
    return [NSDictionary dictionaryWithDictionary:di];
}

+(NSString *) formatIdentificationNumber:(NSString *)string
{
    NSCharacterSet * invalidNumberSet = [NSCharacterSet characterSetWithCharactersInString:@"\n_!@#$%^&*()[]{}'\".,<>:;|\\/?+=\t~`"];
    
    NSString  * result  = @"";
    NSScanner * scanner = [NSScanner scannerWithString:string];
    NSString  * scannerResult;
    
    [scanner setCharactersToBeSkipped:nil];
    
    while (![scanner isAtEnd])
    {
        if([scanner scanUpToCharactersFromSet:invalidNumberSet intoString:&scannerResult])
        {
            result = [result stringByAppendingString:scannerResult];
        }
        else
        {
            if(![scanner isAtEnd])
            {
                result = [result stringByAppendingString:@"-"];
                [scanner setScanLocation:[scanner scanLocation]+1];
            }
        }
    }
    
    return result;
}  

/*
+(NSString*)formatDisplayName:(Member *)member {
    NSString* displayName = member.displayName;
    
    if (([[CoreDataMan get].contextMgr countMembers] > 1) && [member.memberType isEqualToString:@"primary"]) {
        displayName = [NSString stringWithFormat:@"%@ (%@)", member.displayName, @"You"];
    }
    
    return displayName;
    
}*/

+ (NSString*)getStringFromJson:(id)jsonField {
    NSString* value = @"";
    
    if ([jsonField isKindOfClass:[NSString class]]) {
        value      = jsonField;
    } else if ([jsonField respondsToSelector:@selector(stringValue)]) {
        value       = [jsonField stringValue];
    }
    return value;
}

+ (NSNumber*)getNumberFromJson:(id)jsonField {
    NSNumber* value;
    
    if ([jsonField isKindOfClass:[NSString class]]) {
        value      = [[FormatMan get].numberFormatter numberFromString:jsonField];
    } else {
        value       = jsonField;
    }
    return value;
}

+ (NSString*)getEmailWarningMessage {
    return [NSString stringWithFormat:@"If you share this by email, your personal health information will no longer be protected by the secure %@ application.\nContinue if you are sure you want to send this information in an email.",[[Utilities getAppDel] getAppDisplayName]];
}

+ (BOOL)validateUrl:(NSString*)url 
{
    NSString* theURL = @"(http|https)://([a-zA-Z0-9.\x20-\x7E])*";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", theURL]; 
    BOOL b = [urlTest evaluateWithObject:url];
    return b;
}

+ (NSString *)getPureURL:(NSURL*)url
{
    NSString* urlStr= [url absoluteString];
    NSString* scheme= [url scheme];
    NSRange r=[urlStr rangeOfString:scheme];
    NSUInteger i=r.location+r.length+3;
    NSString *pureUrl=[urlStr substringFromIndex:i];    
    return pureUrl;
}

+ (NSString *)base64Encode:(NSString *)plainText
{
    NSData *plainTextData = [plainText dataUsingEncoding:NSUTF8StringEncoding];
    NSString *base64String = [plainTextData base64EncodedString];
    return base64String;
}
+ (NSString *)base64Decode:(NSString *)base64String
{
    NSData *plainTextData = [NSData dataFromBase64String:base64String];
    NSString *plainText = [[NSString alloc] initWithData:plainTextData encoding:NSUTF8StringEncoding];
    return plainText;
}
#pragma mark -
#pragma mark Transition

// Abhinav - Transition type

+(void)action_TransitionFromRight{
    
    CATransition *transition = [CATransition animation];
    transition.duration = .35;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    
    transition.type =kCATransitionPush; 
    transition.subtype =kCATransitionFromRight;
    transition.delegate = self;
    [[[Utilities getAppDel].tabBarController.view layer] addAnimation:transition forKey:nil];
    
}

+(void)action_TransitionFromLeft{
    
    CATransition *transition = [CATransition animation];
    transition.duration = .35;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    
    transition.type =kCATransitionPush; 
    transition.subtype =kCATransitionFromLeft;
    transition.delegate = self;
    [[[Utilities getAppDel].tabBarController.view layer] addAnimation:transition forKey:nil];
    
}

#pragma mark -
#pragma mark Cookies

// Abhinav - Cookies

+(void)saveCookieName:(NSString *)CookieName Value:(NSString *)CookieValue  Domain:(NSString *)CookieDomain  Path:(NSString *)CookiePath  andExpires:(NSDate *)CookieExpires{

    NSMutableDictionary *cookieProperties = [NSMutableDictionary dictionary];
    [cookieProperties setObject:CookieName forKey:NSHTTPCookieName];
    [cookieProperties setObject:CookieValue forKey:NSHTTPCookieValue];
    [cookieProperties setObject:CookieDomain forKey:NSHTTPCookieDomain];
    [cookieProperties setObject:CookiePath forKey:NSHTTPCookiePath];
    [cookieProperties setObject:CookieExpires forKey:NSHTTPCookieExpires];

    NSHTTPCookie *cookie = [NSHTTPCookie cookieWithProperties:cookieProperties];
    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
    
}

//+(BOOL)isCookieExists{
//
////    NSString *cookieName = @"WPP_SEC_CHK_ID";
//    
//    NSArray                 *cookies;
//    NSDictionary            *cookieHeaders;
//    NSMutableURLRequest     *request;
//    
//    cookies = [[ NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];
//    for (int i = 0; i<[cookies count]; i++) {
//        NSHTTPCookie *temp = [cookies objectAtIndex:i];
//        
//        if([temp.name isEqualToString:@"WPP_SEC_CHK_ID"])
//        {
//            LOG("Exists !!!");
//            if (temp.expiresDate) {
//                NSDate *dt = temp.expiresDate;
//                NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:dt];
//                LOG("interval = %f",interval);
//                return YES;
//            }
//        }
//        
//    }
//    if ( !cookies ) {
//        /* kick off new NSURLConnection to retrieve new auth cookie */
//        return NO;
//    }
//    return NO;
//    
//    
//}

#pragma mark -
#pragma mark Google Analyser

+(void)postGATrackEventName:(NSString *)name withActionName:(NSString *)action andlabel:(NSString *)label{
    NSError *err;
    if (![[GANTracker sharedTracker] trackEvent:name
                                         action:action
                                          label:label
                                          value:10
                                      withError:&err]) {
        // Error Handling
        
    }
}

+(void)postGATrackPageName:(NSString *)pageName{
    NSError *error;
    if (![[GANTracker sharedTracker] trackPageview:pageName
                                         withError:&error]) {
        // Error Handling
    }
}

+(BOOL) isValidPhoneNumber:(NSString *)string1
{
    NSString *string = [NSString stringWithFormat:@"%@",string1];
    string = [string stringByReplacingOccurrencesOfString:@"-" withString:@""];
    
    BOOL isMatch = YES;
    for (int i = 0; i < [string length]; i++) {
        unichar c = [string characterAtIndex:i];
        if (!isalnum(c) && c != '_') {
            isMatch = NO;
            break;
        }
    }
    if (isMatch) {
        return YES;
    } else {
        return NO;
    }
    
}

//This is to encode any special chars in name/value pairs in request params
+(NSString *)encodeURLString:(NSString *) sourceString {
    
    if (sourceString != nil) {
        return  (NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,(CFStringRef)sourceString,
                                                                                      NULL,
                                                                                      (CFStringRef)@"!*'\"();:@&=+$,/?%#[]^§°£€ç ",
                                                                                      kCFStringEncodingUTF8);
    } else {
        return sourceString;
    }
}

+(BOOL)isiPhone5{
    
    CGSize result = [[UIScreen mainScreen] bounds].size;
    
    if(result.height == 480)
    {
        return FALSE;
    }
    else if(result.height == 568)
    {
        return TRUE;
    }
    else{
    }
    return FALSE;
}

// hashing algorithm
+(NSString *)hashed_string:(NSString *)input
{
    const char *cstr = [input cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:input.length];
    uint8_t digest[CC_SHA256_DIGEST_LENGTH];
    
    // This is an iOS5-specific method.
    // It takes in the data, how much data, and then output format, which in this case is an int array.
    CC_SHA256(data.bytes, data.length, digest);
    
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH * 2];
    
    // Parse through the CC_SHA256 results (stored inside of digest[]).
    for(int i = 0; i < CC_SHA256_DIGEST_LENGTH; i++) {
        [output appendFormat:@"%02x", digest[i]];
    }
    
    return output;
}


+ (NSData *)sha1:(NSData *)data {
    unsigned char hash[CC_SHA1_DIGEST_LENGTH];
    if ( CC_SHA1([data bytes], [data length], hash) ) {
        NSData *sha1 = [NSData dataWithBytes:hash length:CC_SHA1_DIGEST_LENGTH];
        return sha1;
    }
    return nil;
}

+ (void) signOff {
    [Utilities doesAlertViewExist];
    int i=[Utilities getAppDel].tabBarController.selectedIndex;
    [[[[Utilities getAppDel].tabBarController viewControllers] objectAtIndex:i] dismissModalViewControllerAnimated:NO];
    [[[[Utilities getAppDel].tabBarController viewControllers] objectAtIndex:i] popToRootViewControllerAnimated:NO];
    [Utilities getAppDel].tabBarController.selectedIndex = 0;
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"flagSignOn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[IdleTimerMan get] killTimer];
    [[Utilities getAppDel] showMerlin];
}

+ (NSDictionary *) readTutorialJsonFile {
    NSString *docDirPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        
    NSString *filePath = [docDirPath stringByAppendingPathComponent:@"tutorial.json"];
    LOG("tutorial json filePath %@", filePath);
        
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
            [[NSFileManager defaultManager] copyItemAtPath:[[NSBundle mainBundle] pathForResource:@"tutorial" ofType:@"json"] toPath:filePath error:nil];
    }
        
    NSString *content = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    NSDictionary *dict = [content JSONValue];
    LOG("The readed tutorial json file is: %@",dict);
    return dict;
}

+(void) doesAlertViewExist {
    /*
    for (UIWindow* window in [UIApplication sharedApplication].windows) {
        NSArray* subviews = window.subviews;
        if ([subviews count] > 0) {
            
            BOOL alert = [[subviews objectAtIndex:0] isKindOfClass:[UIAlertView class]];
            //   BOOL action = [[subviews objectAtIndex:0] isKindOfClass:[UIActionSheet class]];
            
            if (alert){
                UIAlertView *alertView = (UIAlertView *)[subviews objectAtIndex:0];
                [alertView dismissWithClickedButtonIndex:0 animated:YES];
            }
        }
    }*/
    if ([[Utilities getAppDel].alerts count]>0) {
        for (UIAlertView* alertView in [Utilities getAppDel].alerts) {
            [alertView dismissWithClickedButtonIndex:0 animated:YES];
        }
        [[Utilities getAppDel].alerts removeAllObjects];
    }
}

+(BOOL) AppBecomeActiveActions {
    NSDate *_mydate = [[NSUserDefaults standardUserDefaults] valueForKey:@"BackGroundTime"];
    NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:_mydate];
    LOG("interval = %f",interval);
    
    AuthorizationMan *am=[AuthorizationMan get];
    BOOL signonFlag = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOn"];
    
    if (signonFlag==YES) {
        if ((interval > kMaxIdleTimeInterval) || (![am hasWarningAccepted])) {
            
            [Utilities signOff];
            return YES;
        }
    } else {
        if (int_fromLaunch==1) {
            LOG("Just show the merlin!");
            [[Utilities getAppDel] showMerlin];
            return YES;
        } else {
            LOG("It should be signed off!");
            [Utilities signOff];
            return YES;
        }
        /*
            else if (interval > kMaxIdleTimeInterval) {
            LOG("I am here now!");
            [Utilities signOff];
            return YES;
        }
         */
    }
    
    if (signonFlag==YES) {
        [[IdleTimerMan get] resetIdleTimer];
    }
    
    [Utilities getAppDel].splashView.alpha=0.0;
    return NO;
}

+(void) AppLaunchActions {
    [Utilities getAppDel].alerts=[[NSMutableArray alloc] init];
	int_fromLaunch=1;
    int_SwitchBtn = [[NSUserDefaults standardUserDefaults]integerForKey:@"int_SwitchBtn"];
    if (int_SwitchBtn==0) {
        // this mean it has no value before, it should only have 1 and 2
        
        int_SwitchBtn = 1;
        [[NSUserDefaults standardUserDefaults]setInteger:1 forKey:@"int_SwitchBtn"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
	[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"flagSignOn"];
	[[NSUserDefaults standardUserDefaults] synchronize];
    
	[[NSUserDefaults standardUserDefaults] setObject:[NSDate date] forKey:@"BackGroundTime"];
	[[NSUserDefaults standardUserDefaults] synchronize];
}

+(BOOL)isIOS7AndAbove {
    BOOL isIOS7 = NO;
    
#if __IPHONE_7_0 >= __IPHONE_OS_VERSION_MAX_ALLOWED
    isIOS7 = YES;
#endif
    
    if (isIOS7 && [[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        isIOS7 = YES;
    } else {
        isIOS7 = NO;
    }
    LOG("%i",isIOS7);
    
    
    Class itemClass = NSClassFromString(@"MKMapItem");
    
    if (isIOS7 && itemClass != nil && [itemClass respondsToSelector:@selector(openMapsWithItems:launchOptions:)]) {
        isIOS7 = YES;
    } else {
        isIOS7 = NO;
    }
    
    return isIOS7;
}

+ (NSString *)hashString:(NSString *)input
{
    const char *cstr = [input cStringUsingEncoding:NSISOLatin1StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:input.length];
    uint8_t digest[CC_SHA512_DIGEST_LENGTH];
	
    // It takes in the data, how much data, and then output format, which in this case is an int array.
    CC_SHA512(data.bytes, data.length, digest);
	
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA512_DIGEST_LENGTH * 2];
	
    // Parse through the CC_SHA256 results (stored inside of digest[]).
    for(int i = 0; i < CC_SHA512_DIGEST_LENGTH; i++) {
        [output appendFormat:@"%02x", digest[i]];
    }
	
    return output;
}

+ (NSString *) deviceIdentifier
{
    NSString *myDeviceIdentifier = @"";
    if ([Utilities isIOS7AndAbove]) {
        myDeviceIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        LOG("iOS7 and Above Device ID: %@", myDeviceIdentifier);
        
    }
    else
    {
        myDeviceIdentifier = [[UIDevice currentDevice] uniqueDeviceIdentifier];
    }
    return myDeviceIdentifier;
}

@end
