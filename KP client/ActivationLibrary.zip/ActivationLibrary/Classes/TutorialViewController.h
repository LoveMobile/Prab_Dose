//
//  CustomPageControlExampleViewController.h
//  CustomPageControlExample
//
//

#import <UIKit/UIKit.h>
#import "CustomPageControl.h"
#import "FetcherJson.h"


@interface TutorialViewController : UIViewController <UIScrollViewDelegate, FetcherDelegate> {
    
    IBOutlet UIButton *backBtn;
    IBOutlet UIButton *nextBtn;
    
    IBOutlet UITextView *textView1;
    IBOutlet UITextView *textView2;
    IBOutlet UITextView *textView3;
    IBOutlet UITextView *textView4;
    IBOutlet UITextView *textView5;
    
    IBOutlet UIButton *closeBtn;
    IBOutlet UIButton *xBtn;
    IBOutlet UIButton *x1Btn;
    IBOutlet UIButton *x2Btn;
    IBOutlet UIButton *x3Btn;

    IBOutlet UIView *warningView;

}

@property (nonatomic, retain) IBOutlet UIScrollView *scrollView2;
@property (nonatomic, retain) IBOutlet CustomPageControl *pageControl2;
@property (nonatomic, retain) IBOutlet UIView *contentView2;
@property (nonatomic, retain) IBOutlet UIView *warningView;
@property (nonatomic, assign) BOOL standalone;
@property (nonatomic, retain) NSDictionary *jsonDict;

- (id)initWithMode:(BOOL)isStandalone;
- (IBAction)pageControlAction:(CustomPageControl *)sender;
-(IBAction)nextClicked:(id)sender;
-(IBAction)backClicked:(id)sender;
-(IBAction)closeBtnClicked;
-(IBAction)closeBtnTapClicked;

@end
