//
//  PrivacyPracticesViewController.m
//  MobileCare
//
//  Created by Abhinav Sehgal.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.

#import "PrivacyPracticesViewController.h"
#import "WebServiceMan.h"
#import "AuthorizationMan.h"
#import "Utilities.h"
#import "Constants.h"

@interface PrivacyPracticesViewController ()

@end

@implementation PrivacyPracticesViewController

@synthesize isloadCompleted;
@synthesize m_webView;
@synthesize isBackClicked;
@synthesize phoneHandler;

- (void)pop
{
 /*
    if (intPrivacy == 2) {
        intPrivacy = 0;
        [[Utilities getAppDel] hideAi];

        [self dismissModalViewControllerAnimated:YES];
    }
    else{
        if ([[NSUserDefaults standardUserDefaults] boolForKey:@"_fromLandingView"]) {
            [self.navigationController popViewControllerAnimated:YES];
            [Utilities getAppDel].tabBarController.selectedIndex = 0;
            [Utilities action_TransitionFromLeft];
        }
        else{
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
  */
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewWillAppear:(BOOL)animated{
    
    self.title = @"Privacy Statement";
    // Google Analyser
    [Utilities postGATrackPageName:@"Privacy Practices View"];
    
    if (int_showMessage == 1) {
        int_showMessage = 0;
        [[Utilities getAppDel] hideMessage];
    }
    
    if (self.networkError) {
        //[[Utilities getAppDel].m_msgVC show];
        [self loadWebView];
    }
    
}

// Load the UIWebView using the configured mode
- (void)loadWebView
{
    if (int_showMessage == 1) {
        int_showMessage = 0;
        [[Utilities getAppDel] hideMessage];
    }
    UIImage* image3 = [UIImage imageNamed:@"icon_bkgd_back-arow.png"];
    CGRect frameimg = CGRectMake(0, 0, 40, 30);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(pop)
         forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *m_barSomeButton = [[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem = m_barSomeButton;
    [m_barSomeButton release];
    [someButton release];
    
    UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]];
	self.view.backgroundColor = background;
    [background release];
    
    self.m_webView.dataDetectorTypes = UIDataDetectorTypePhoneNumber; //UIDataDetectorTypeAll;

    WebServiceMan* wsm = [WebServiceMan get];
    
    //NSString *urlString = @"https://native.usablenet.com/mt/healthy.kaiserpermanente.org/health/poc?uri=center:privacy-statement&un_jtt_application_platform=iphone";
    
    
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",
                           wsm.wsBaseUrl,
                           @"getPrivacyContent"];
    
	NSURL *url = [NSURL URLWithString:urlString];
    
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    self.curRequest=request;
	[self.m_webView loadRequest:request];
    
    /*
    NSString *contentWrapper = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"contentWrapper" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
    LOG("The contentWrapper is: %@", contentWrapper);
    NSString *contentBody = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"privacyStatement" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
    LOG("The content body is: %@", contentBody);
    
    NSString *content = [contentWrapper stringByReplacingOccurrencesOfString:@"#content#" withString:contentBody];
    LOG("The final content is: %@", content);
    
    [self.m_webView loadHTMLString:content baseURL:nil]; //[[NSBundle mainBundle] bundleURL]
     
     */
    
}

- (BOOL)webView:(UIWebView *)webView2 shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    BOOL ret=YES;
    
    NSURL *url=[request URL];
    NSString *schemeStr=[url scheme];
    NSString *fullStr=[url absoluteString];
    
    
    if ([schemeStr isEqualToString:@"mailto"]) {
        NSString *recipient=[fullStr substringFromIndex:7];
        NSArray *recipients=[NSArray arrayWithObject:recipient];
        LOG("receipient: %@", recipients);
        if ([MFMailComposeViewController canSendMail])
        {
            [self displayComposerSheet:recipients];
        }
        else
        {
            [self launchMailAppOnDevice:recipient];
        }
        return NO;
    } else if ([schemeStr isEqualToString:@"tel"]) {
		NSRange theRange = [fullStr rangeOfString:@"tel:"];
		NSUInteger anIndex = theRange.location + theRange.length;
		NSString *thePhoneNumber = [fullStr substringFromIndex:anIndex];
		
		self.phoneHandler = [[PhoneLinkHandler alloc] init];
		[self.phoneHandler showPhoneAlertWithPhoneNum:thePhoneNumber];
		return NO;
	}
    
    ret=[super webView:webView2 shouldStartLoadWithRequest:request navigationType:navigationType];
    
    return ret;
}

- (void) webView:(UIWebView *)webView2 didFailLoadWithError:(NSError *)error
{
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    [[Utilities getAppDel] hideAi];
    
    //[[Utilities getAppDel].m_msgVC showMessage:@"We're unable to connect to retrieve your data at this time. Please try again later. " withButtonText:@"Retry" target:self andSelector:@selector(doRetry)];

    NSString *content = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"privacyStatement" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
    LOG("The local privacy policy content is: %@", content);
    
    [self.m_webView loadHTMLString:content baseURL:nil]; //[[NSBundle mainBundle] bundleURL]
    
    self.networkError=YES;
}

@end
