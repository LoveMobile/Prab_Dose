// 
//  MobileCareAppDelegate.m
//  MobileCare
//
//  Created by Sean Gilligan on 8/16/10.
//  Copyright Fingerpaint Labs 2010. All rights reserved.
//

#import <unistd.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import "MobileCareAppDelegate.h"
#import "Constants.h"
#import "AuthorizationMan.h"
#import "VCGeneralDialog.h"
#import "LocationMan.h"
#import "ActivationSettingsViewController.h"
#import "TermsAndConditionsViewController.h"
#import "SupportViewController.h"
#import "IdleTimerMan.h"
#import "Utilities.h"
#import "TutorialViewController.h"
#import "WarningViewController.h"


#define kAPNSAlert 25

NSString *pushStatus()
{
	return [[UIApplication sharedApplication] enabledRemoteNotificationTypes] ?
        @"Notifications were active for this application" :
        @"Remote notifications were not active for this application";
}

NSString * const MCPasscodeLockEnableChangedNotification	= @"MCPasscodeLockEnableChangedNotification";
NSString * const MCReloadDataNotification					= @"MCReloadDataNotification";


@implementation MobileCareAppDelegate

@synthesize isApptBooking;
@synthesize window;
@synthesize tabBarController;
@synthesize apnsDeviceToken;
@synthesize warnBeforeEmail;
@synthesize changePasscodeActive;
@synthesize navBarColor;
@synthesize webDirBaseURL;
@synthesize progressUpdate;
@synthesize emailDisclaimerType;
@synthesize apptContentURLString;
@synthesize m_vcMerlin;
@synthesize m_ai;
@synthesize m_initiator;
@synthesize m_datePickerReference;
@synthesize m_pickerReference;
@synthesize messageView = m_messageView;
@synthesize btAuthorize = m_btAuthorize;
@synthesize lbMessage = m_lbMessage;
//@synthesize m_badges = m_aBadges;
@synthesize splashView;
@synthesize m_maCurrentVCs;
@synthesize launchTabIndex;
@synthesize notificationInfo;
@synthesize delegate = m_delegate;
// Abhinav Sehgal - Landing View
@synthesize m_nTabBarMode;
//@synthesize isSynchingCompleted;
@synthesize m_msgVC;
@synthesize alerts;

#pragma mark -
#pragma mark Application lifecycle


- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application 
{

}

- (void)dealloc 
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];	
    [tabBarController release];
    [window release];
    self.navBarColor = nil;
    self.m_vcMerlin = nil;
    self.m_ai = nil;
    self.m_msgVC = nil;
    self.m_initiator = nil;
    self.messageView = nil;
    self.btAuthorize = nil;
    self.lbMessage = nil;
//    self.m_badges = nil;
    self.m_maCurrentVCs = nil;
    self.notificationInfo=nil;
    self.alerts=nil;
    [super dealloc];
}

- (NSString *)appVersion
{
	return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}

- (NSString*)getBundleVersion
{
	return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
}


- (int)getAppEnvironment
{
    NSString* env = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"AppEnv"];
    int envType = 0;
    
    if ([env isEqualToString:@"QA"] || [env isEqualToString:@"ALPHA"])
    {
        envType = 1;
    } else if ([env isEqualToString:@"PROD"] || [env isEqualToString:@"LIVE"] || [env isEqualToString:@"ITUNES"])
    {
        envType = 2;
    }
    else if ([env isEqualToString:@"PP"] || [env isEqualToString:@"BETA"])
    {
        envType = 3;
    }
    else if ([env isEqualToString:@"LOCAL"])
    {
        envType = 4;
    }
    else if ([env isEqualToString:@"DEV"])
    {
        envType = 5;
    }
    return envType;
}

- (NSString *)getAppEnvironmentAsString
{
    NSString* env = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"AppEnv"];
    return env;
}

// For Google Account ID
-(NSString *)getGoogleAccountID{
    NSString *accountId = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"GoogleAccountID"];
    return accountId;
}

// For Name of app (eg: Mobile Care )
-(NSString *)getAppDisplayName{
     NSString* env = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"AppDisplayName"];
    //LOG(" %@", env);
    return env;
    
}

- (void)showMessage:(NSString*)szMessage withButtonText:(NSString*)btText target:(id)t andSelector:(SEL)sel
{
    int_showMessage = 1;
    self.messageView.hidden = NO;
    self.btAuthorize.hidden = NO;
    UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]];
    self.window.backgroundColor = background;
    [background release];
    self.lbMessage.text = szMessage;    
    
    if (nil == btText)
    {
        self.btAuthorize.hidden = YES;
    }
    else
    {
        
        [self.btAuthorize setTitle:btText forState:UIControlStateNormal];
        [self.btAuthorize setFrame:CGRectMake(20, 285, 280, 35)];
        [self.btAuthorize setBackgroundImage:[[UIImage imageNamed:@"bkgd_button_blue.png"]
                                           stretchableImageWithLeftCapWidth:10.0f
                                           topCapHeight:0.0f]
                                 forState:UIControlStateNormal];
        [self.btAuthorize setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        //        self.deleteButton.titleLabel.font = [UIFont boldSystemFontOfSize:20];
        // [m_btDirection.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:18.0]];        
        self.btAuthorize.titleLabel.shadowColor = [UIColor lightGrayColor];
        self.btAuthorize.titleLabel.shadowOffset = CGSizeMake(0, -1); 
        
        
        // Clear all the previously assigned control events.
        [self.btAuthorize removeTarget:nil 
                           action:NULL 
                 forControlEvents:UIControlEventAllEvents];
        
        if (t == nil)
        {
            [self.btAuthorize addTarget:self 
                                 action:@selector(authoizeButtonPressed:) 
                       forControlEvents:UIControlEventTouchUpInside];
        }
        else
        {
             [self.btAuthorize addTarget:t 
                                     action:sel 
                           forControlEvents:UIControlEventTouchUpInside];
        }
    }
}

- (void)showMessage:(NSString*)szMessage withButtonText:(NSString*)btText
{
    int_showMessage = 1;
    [self showMessage:szMessage withButtonText:btText target:nil andSelector:nil];    
}

- (void)showMessage:(NSString*)szMessage
{
    int_showMessage = 1;
    [self showMessage:szMessage withButtonText:nil];
}

- (void)hideMessage
{
    //self.messageView.hidden = YES;
    [self.m_msgVC hide];
}

- (IBAction)authoizeButtonPressed:(id)sender 
{ 
    if ([self facOnly]) { 
        [self hideMessage]; 
    } 
    [self showMerlin]; 
} 

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    
    self.isApptBooking = FALSE;
     intPrivacy = 0;
    // Google Analyser
    [Utilities postGATrackPageName:@"applicationlaunched"];
       
    // ABHI CHECK Passcode or Sign On view
    /*
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"flagSignOnAsBG"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_isLoggedIn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_isEnteredPasscode"];
    [[NSUserDefaults standardUserDefaults] synchronize];
     */
    
    // new integration point
    [Utilities AppLaunchActions];
    
    int_refresh = 0;
    is_profile = YES;
    
   // self.isSynchingCompleted = FALSE;
   
    char* szZombie = getenv("NSZombieEnabled");
    if (szZombie && 0 == strcasecmp(szZombie, "YES"))
    {
            
        LOG("NSZombieEnabled enabled!");
    }
    
    LOG("Logging enabled");
            
	self.progressUpdate = 0.0;
	self.apptContentURLString = @"";
    self.launchTabIndex=0;
    
	// Add the tab bar controller's view to the window and display.
	self.navBarColor = [UIColor colorWithRed:(CGFloat)0/256 
                                   green:(CGFloat)109/256 
                                    blue:(CGFloat)157/256 
                                    alpha:1];// retain];

    int_tabBarWhiteCsreen = 1;
    tabBarController.delegate = self;
	[self setFullMode];
    [window addSubview:tabBarController.view];

    // Configure the message panel
    self.messageView.hidden = YES;
    CGRect r = self.messageView.frame;
    r.origin.y = 20.0 + 44.0;
    self.messageView.frame = r;
    [window addSubview:self.messageView];    
    
    [window makeKeyAndVisible];
    
    // ?
//	settings = [[MCSettings alloc] init];
//	[settings load];
	
    
#if TARGET_IPHONE_SIMULATOR
	self.apnsDeviceToken = [@"SimulatorDeviceToken" dataUsingEncoding:NSUTF8StringEncoding];
#else
	NSUInteger notifyTypes = UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound;
	[[UIApplication sharedApplication] registerForRemoteNotificationTypes:notifyTypes];
	self.apnsDeviceToken = nil; //[@"not-yet-received" dataUsingEncoding:NSUTF8StringEncoding];
#endif
	
	NSDictionary *remoteOptions = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
	if (remoteOptions != nil)
	{        
		[self handlePushNotification:remoteOptions];
	}
	
    [[LocationMan get] firstStart];
    /*
    [[MaintenanceMan get] loadFlags];
    
    if ([[ContainerMan get] getDateState]==DATA_FRESH) {
        [[MaintenanceMan get] doMaintenance];
    }*/
    //[[MaintenanceMan get] restartTimer];
    self.changePasscodeActive=NO;
    
	
	NSString *imagePath = [[NSBundle mainBundle] resourcePath];
	imagePath = [imagePath stringByAppendingString:@"/www"];
	imagePath = [imagePath stringByReplacingOccurrencesOfString:@"/" withString:@"//"];
	imagePath = [imagePath stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
	self.webDirBaseURL = [NSURL URLWithString: [NSString stringWithFormat:@"file:/%@//", imagePath]];
		        
    m_bObserving = NO;

    self.m_ai = [[VCActivityIndicator alloc] init];
    
    r = self.m_ai.view.frame;
    r.origin.y = 61.0;
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    
    if (screenBounds.size.height == 568) {
        // code for 4-inch screen
        r.size.height = r.size.height + 50;
        r.origin.y = r.origin.y+5;
    } else {
        // code for 3.5-inch screen
    }
        
    self.m_ai.view.frame = r;
    
    [window addSubview:self.m_ai.view];
    
    self.m_msgVC = [[MessageVC alloc] init];
    
    [window addSubview:self.m_msgVC.view];  
    
    [self.m_msgVC hide];
    
    self.m_initiator = [[VCInitiator alloc] init];
    
    [window addSubview:self.m_initiator.view];   
    
    [self hideInitiator];
    
	[splashView setAutoresizesSubviews:NO];
    splashView.contentMode = UIViewContentModeScaleAspectFit;
    [window addSubview:splashView];

    self.splashView.alpha = 0.0;
    self.delegate = nil;
    //[self showMerlin];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    if (self.changePasscodeActive) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"dismissPasscodeAppDelNoti" object:nil];
        self.changePasscodeActive=NO;
    }    
    self.splashView.alpha = 1.0;    
    /*
    [[MaintenanceMan get] saveFlags];
    [[MaintenanceMan get] killTimer];
     */
    [[IdleTimerMan get] killTimer];
    //[[CoreDataMan get] saveContext];
    //[[HandshakeMan get] clearAll];
    /*
    if (self.m_vcMerlin.modalViewController) {
        [self.m_vcMerlin dismissModalViewControllerAnimated:NO];
    }*/
    //[self.m_initiator hide];
    LOG("The App is backgrounded. Timer is killed!");
//    [settings save];    
}

- (void)showAi:(NSString*)szText
{
    if (szText && [szText length] > 0)
    {
        self.m_ai.m_lbText.text = szText;
    }
    [self.m_ai show];    
}

- (void)showInitiator:(NSString*)szText
{
    if (szText && [szText length] > 0)
    {
        self.m_initiator.m_lbText.text = szText;
    }
    [self.m_initiator show];    
}

- (void)showAiWithoutBackground
{
    [self.m_ai showWithoutBackground];
}

- (void)showAi
{
    [self showAi:nil];
}

- (void)showInitiator
{
    [self showInitiator:nil];
}

- (void)hideAi
{
    NSString *lbText=self.m_ai.m_lbText.text;
    if (lbText && [lbText length] > 0)
    {
        self.m_ai.m_lbText.text = nil;
    }    
    [self.m_ai hide];
}

- (void)hideInitiator
{
    NSString *lbText=self.m_initiator.m_lbText.text;
    if (lbText && [lbText length] > 0)
    {
        self.m_initiator.m_lbText.text = nil;
    }    
    [self.m_initiator hide];
}

// AppClient must implement - start
- (void)showMerlinWithVC:(UIViewController*)vcBase andState:(WIZARD_STATE)eWizardState
{
    if (nil != self.m_vcMerlin)
    {
        [vcBase dismissModalViewControllerAnimated:NO];
        self.m_vcMerlin = nil;
    }
    
    self.m_vcMerlin = [[[VCGeneralDialog alloc] initWithState:eWizardState] autorelease];
    //self.m_vcMerlin.navigationItem.titleView=[[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo-white.png"]] autorelease];
    self.m_vcMerlin.m_delegate = self;
//    m_vcMerlin.m_delegate = self;   
//    UINavigationController* nc = [[[UINavigationController alloc] initWithRootViewController:self.m_vcMerlin] autorelease];
//    nc.navigationBar.tintColor = self.navBarColor;
    
    //nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    //[vcBase presentModalViewController:nc animated:NO];
    [vcBase presentModalViewController:self.m_vcMerlin animated:NO];
}
// AppClient must implement - end

// AppClient must implement - start
- (void)showMerlinWithState:(WIZARD_STATE)eWizardState
{
    // If this is called before a selected VC is available, then listen until it is.
    if (!m_bObserving)
    {
        [tabBarController addObserver:self forKeyPath:@"selectedViewController" options:0 context:nil];
        m_bObserving = YES;
    }

    UIViewController* vc = tabBarController.selectedViewController;
    
    if (self.isApptBooking == TRUE) {
        [(UINavigationController*)vc popToRootViewControllerAnimated:NO];
    }
    
    // If the app isn't loaded yet, then vc will be nil. Use observer to wait.
    if (nil == vc)
    {
        return;
    }

    vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    
    // Assume there is an observer
    [tabBarController removeObserver:self forKeyPath:@"selectedViewController"];
    m_bObserving = NO;
    
    if ([vc isKindOfClass:[UINavigationController class]])
    {
        LOG("selected viewController inside showMerlinWithState: %@", vc);
        UINavigationController* nc = (UINavigationController*)vc;
        UIViewController* vc2 = nil;

        if ([nc.viewControllers count] == 0)
        {
         //   if ([[ContainerMan get] getDateState]==DATA_FRESH) {
                int version = [[[UIDevice currentDevice] systemVersion] intValue];
                LOG("Current device ios version :%d", version);
                if (version>=5) { // there is an issue with Modal View Controller in iOS 5
                    [self popAllTabsToRoot];
                    vc2 = tabBarController.selectedViewController;
                } else {
                    vc2=nc;
                }
            /*    
            } else {
                [tabBarController.moreNavigationController popToRootViewControllerAnimated:NO];
                vc2=tabBarController.moreNavigationController.topViewController;
            }*/
        }
        else
        {
            int vc_count=[nc.viewControllers count];
            //   don't pop to RootViewController based on requirement
            //   when no data refresh is happening
            // go back to the last view controller was viewing
            // if ([[ContainerMan get] getDateState]==DATA_FRESH) {
                vc2 = [nc.viewControllers objectAtIndex:vc_count-1];
            /*
            } else {
                [nc popToRootViewControllerAnimated:NO];
                vc2=[nc.viewControllers objectAtIndex:0];
            }*/
        }
        
        if (![vc2 isViewLoaded])
        {
            LOG("App Del - forcing viewDidLoad");
            LOG("View Name : %@",[vc2 nibName]);
            // Force the viewDidLoad
            [vc2 loadView];
            
        }
        
        NSAssert([vc2 isViewLoaded], @"view should be loaded at this point");
        [self showMerlinWithVC:vc2 andState:(WIZARD_STATE)eWizardState];
    }
}
// AppClient must implement - end

// AppClient must implement - start
- (void)showMerlin
{
    self.splashView.alpha = 0.0;
    [self showMerlinWithState:INITIALIZE];
}
// AppClient must implement - end

- (void)observeValueForKeyPath:(NSString *)keyPath 
                      ofObject:(id)object
                        change:(NSDictionary *)change 
                       context:(void *)context 
{
    // TODO : autorelease pool (to all callbacks)
    if (object == tabBarController)
    {
        [self showMerlin];
    }
}

- (void)applicationDidEnterBackground:(UIApplication *)application{
    
    // Abhinav sehgal - (No passcode required) 
    // saving current time in userdefault while application entering into background
    LOG("back : - %@",[NSDate date]);
    [[NSUserDefaults standardUserDefaults] setObject:[NSDate date] forKey:@"BackGroundTime"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
   // self.isSynchingCompleted = FALSE;
    
    for (UIView *view in self.window.subviews) {
        if (view == self.m_pickerReference  || view == self.m_datePickerReference) {
            view.alpha = 0;
        }
    }
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    [[NSNotificationCenter defaultCenter] postNotificationName:kNotification_FetcherJson_CancelConnection object:nil];
    
}

-(void)myAlertView{
    
    UIAlertView *alertView= [[UIAlertView alloc] initWithTitle:nil message:@"You have to reactivate device to use another account " delegate:self cancelButtonTitle:@"Reactivate" otherButtonTitles:@"Cancel", nil];
    alertView.tag = 1000;
    [alertView show];
    [alertView release];
    alertView = nil;
    
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{    
    
    [self hideAi];
    if (int_refresh == 1) {
        // int_refresh = 0;
        [rootclassappts stopApptReload];
    }
    [[LocationMan get] firstStart];
    //[[MaintenanceMan get] loadFlags];
    /*
    if ([[ContainerMan get] getDateState]==DATA_FRESH) {
        [[MaintenanceMan get] doMaintenance];
    }*/
    //[[MaintenanceMan get] restartTimer];
    [[IdleTimerMan get] resetIdleTimer];
    self.changePasscodeActive=NO;
    // Abhinav Sehgal
    // For terminating appt if user background application while booking his/her appt.
//    if (self.isApptBooking == TRUE) {
//        [self action_terminateApptBooking];
//    }
    
}


- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [self hideAi];
    self.messageView.hidden = YES;
    self.splashView.alpha = 0.0;
    // AppClient must implement - start
    BOOL hasMerlinShown=[Utilities AppBecomeActiveActions];
    LOG("Has the Merlin shown? %d", hasMerlinShown);
    
    //[self showMerlin];
    // AppClient must implement - end
    
    // adding more calls to setBadge
    // comment it since paul may fix the issue
    //    [[BadgeMan get] calculateBadgeCounts];
}

#pragma mark - VCMerlinDelegate

- (void)dismissModal
{
	[tabBarController.selectedViewController dismissModalViewControllerAnimated:NO];
    self.m_vcMerlin = nil;
    if (self.delegate)
    {
        [self.delegate merlinClosed];
    }
}

// AppClient must implement - start
/*
- (void)displayWarning
{
    WarningViewController *obj = [[WarningViewController alloc]initWithNibName:@"WarningViewController" bundle:nil];
    [self.m_vcMerlin presentModalViewController:obj animated:YES];
}
*/
// AppClient must implement - end

#pragma mark - Application life cycle

- (void)applicationWillTerminate:(UIApplication *)application 
{
    // Persist the current context.
   // [[CoreDataMan get] saveContext];	
//    [settings save];
    /*
    [[MaintenanceMan get] saveFlags];
    [[MaintenanceMan get] killTimer];
     */
}

// Retrieve the device token
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{	
	// new mod comment out logging
	//NSUInteger rntypes = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];	
	//NSString *results = [NSString stringWithFormat:@"Badge: %@, Alert:%@, Sound: %@",
	//					 (rntypes & UIRemoteNotificationTypeBadge) ? @"Yes" : @"No", 
	//					 (rntypes & UIRemoteNotificationTypeAlert) ? @"Yes" : @"No",
	//					 (rntypes & UIRemoteNotificationTypeSound) ? @"Yes" : @"No"];
	
	//NSString *status = [NSString stringWithFormat:@"%@\nRegistration succeeded.\n\nDevice Token: %@\n%@", pushStatus(), deviceToken, results];
	//	[self showString:status];
	
	self.apnsDeviceToken = deviceToken;
}

// Provide a user explanation for when the registration fails
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error 
{
	NSString *status = [NSString stringWithFormat:@"%@\nRegistration failed.\n\nError: %@", pushStatus(), [error localizedDescription]];
 	LOG("didFailToRegisterForRemoteNotificationsWithError. status: %@", status); 
	LOG("didFailToRegisterForRemoteNotificationsWithError. Error in registration. Error: %@", error); 
}

// Handle an actual notification
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary*)userInfo
{    
    UIApplicationState state = [application applicationState];    
    if (state==UIApplicationStateActive) {
        NSString* alertString = [userInfo valueForKeyPath:@"aps.alert"];
        
        NSString *str_title = [self getAppDisplayName];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:str_title 
                                                        message:alertString 
                                                       delegate:self 
                                              cancelButtonTitle:@"Close" 
                                              otherButtonTitles:@"View", nil];
        alert.tag = kAPNSAlert;
        self.notificationInfo=userInfo;
        [alert show];
        [alert release];        
    } else {
        [self handlePushNotification:userInfo];
    }
}

// Report the notification payload when launched by alert
- (void)launchNotification:(NSNotification*)notification
{
	[self performSelector:@selector(showString:) withObject:[[notification userInfo] description] afterDelay:1.0f];
}

-(void) handlePushNotification:(NSDictionary *)userInfo
{
    
    //	NSString* alertString = [userInfo valueForKeyPath:@"aps.alert"];
    //	
    //    NSNumber* badgeCount = [userInfo valueForKeyPath:@"aps.badge"];
    //    //    
    ////    MCBadges* badges = self.m_badges;
    ////    int totalnumber=badges.newAppointments+badges.newPhpItems+badges.newTips;
    //    
    ////    if ([badgeCount intValue] != totalnumber) {
    //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"KP Push Notification" 
    //                                                        message:@"There might be new information for you. Do you want to download them now?" 
    //                                                       delegate:self 
    //                                              cancelButtonTitle:@"CANCEL" 
    //                                              otherButtonTitles:@"OK", nil];
    //        alert.tag = kAPNSAlert;
    //        [alert show];
    //        [alert release];
    ////    }
    NSString *tabAction=[userInfo valueForKey:@"tab"];
	
    if ([tabAction isEqualToString:@"php"]) {
        tabBarController.selectedIndex = 1;
        self.launchTabIndex=0;
    } else if ([tabAction isEqualToString:@"appt"]) {
        tabBarController.selectedIndex = 2;
        self.launchTabIndex=0;
    } else if ([tabAction isEqualToString:@"tip"]) {
        tabBarController.selectedIndex = 3;
        self.launchTabIndex=0;
    }
    
    // the rest are "default"
}

// non-public method
/*
- (void)setBadgesInGui
{  
    LOG("Setting badges in GUI");
    MCBadges* badges = self.m_badges;
    
    // surya added ... check tab bar count. sometimes see crashes with index being out of range
    //when badge setting seems to start before all tab bar items getting initialzed
    if ([tabBarController.tabBar.items count] > 0) {
        [[tabBarController.tabBar.items objectAtIndex:1] setBadgeValue:
         (badges.newPhpItems ? [NSString stringWithFormat:@"%d", badges.newPhpItems] : nil)];
    }
    if ([tabBarController.tabBar.items count] > 2) {
        [[tabBarController.tabBar.items objectAtIndex:2] setBadgeValue: 
         (badges.newAppointments ? [NSString stringWithFormat:@"%d", badges.newAppointments] : nil)];
    }
	
    if ([tabBarController.tabBar.items count] > 3) {
        [[tabBarController.tabBar.items objectAtIndex:3] setBadgeValue: 
         (badges.newTips ? [NSString stringWithFormat:@"%d", badges.newTips] : nil)];
    }
    
    [UIApplication sharedApplication].applicationIconBadgeNumber = 
    badges.newAppointments + badges.newPhpItems + badges.newTips;
}*/

/*
- (void)clearBadges
{
    MCBadges* badges = [[[MCBadges alloc] init] autorelease]; 
    badges.newAppointments = 0; 
    badges.newPhpItems = 0;
    badges.newTips = 0;

    [self setBadges:badges];
}*/

/*
- (void)setBadges:(MCBadges*)badges
{
    self.m_badges = badges;
    [self setBadgesInGui];
}
 */

- (void)addToTabVC:(UIViewController*)vc tabTitle:(NSString*)szTabTitle tabIcon:(NSString*)szTabIcon andNavTitle:(NSString*)szNavTitle
{
    LOG("IN addToTabVC");
    UINavigationController* nav = [[[UINavigationController alloc] initWithRootViewController:vc] autorelease];
	
	UITabBarItem* tbi = [[[UITabBarItem alloc] initWithTitle:szTabTitle image:nil tag:0] autorelease];
	[tbi setImage:[UIImage imageNamed:szTabIcon]];
    
    nav.tabBarItem = tbi;
    nav.navigationBar.tintColor = navBarColor;
    nav.navigationBar.topItem.title = szNavTitle;

    [m_maCurrentVCs addObject:nav];
}

- (BOOL)facOnly
{
    return TBM_FAC_ONLY == m_nTabBarMode;
}

- (void)setFacOnlyMode
{
    
    m_nTabBarMode = TBM_FAC_ONLY;

    // Create a new set of VCs
    self.m_maCurrentVCs = [NSMutableArray arrayWithCapacity:0];
    
    [self addToTabVC:[[[LandingViewController alloc] init] autorelease] 
            tabTitle:@"Home" 
             tabIcon:@"Icon_Home_Off.png" 
         andNavTitle:@"My preventive care"];
    
    [self addToTabVC:[[[SupportViewController alloc] init] autorelease] 
            tabTitle:@"App support" 
             tabIcon:@"icon_support.png" 
         andNavTitle:@"App support"];    
    
    [self addToTabVC:[[[TermsAndConditionsViewController alloc] init] autorelease] 
            tabTitle:@"Terms & conditions" // this will be in the more VC. 
             tabIcon:@"icon_terms.png" 
         andNavTitle:@"Terms & conditions"];    
    
//    [self addToTabVC:[[[TutorialViewController alloc] init] autorelease]
//            tabTitle:@"App support"
//             tabIcon:@"icon_support.png"
//         andNavTitle:@"App support"];

    /*
    [self addToTabVC:[[[VCRootListPhp alloc] init] autorelease]
            tabTitle:@"Prevention" 
             tabIcon:@"tabprev.png" 
         andNavTitle:@"My preventive care"];
    
    [self addToTabVC:[[[VCRootListAppts alloc] init] autorelease] 
     //    [self addToTabVC:[[[VCWTF alloc] init] autorelease] 
            tabTitle:@"Appts" 
             tabIcon:@"tabappt.png" 
         andNavTitle:@"My appointments"];
    
    [self addToTabVC:[[[FacilitiesMainListView alloc] init] autorelease]
            tabTitle:@"Facilities" 
             tabIcon:@"tabfac.png" 
         andNavTitle:@"Locate a facility"];

    [self addToTabVC:[[[TipListViewController alloc] init] autorelease] 
            tabTitle:@"Timely tips" 
             tabIcon:@"tabtips.png" 
         andNavTitle:@"Timely health tips"];
    
    [self addToTabVC:[[[MyDoctorView alloc] init] autorelease] 
            tabTitle:@"My personal doctor" 
             tabIcon:@"icon_MyDoctors_Black.png" 
         andNavTitle:@"My personal doctor"];
    
    [self addToTabVC:[[[TermsAndConditionsViewController alloc] init] autorelease] 
            tabTitle:@"Terms & conditions " 
             tabIcon:@"tabterms.png" 
         andNavTitle:@"Terms & conditions"];
     */
    
    // Abhinav Sehgal - Landing View
    NSMutableArray *arr = [[NSMutableArray alloc] init];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_Support_@2x.png",@"imageNameBlue",
                    @"Icon_Support_White_@2x.png",@"imageNameWhite",
                    @"App support",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_terms@2x.png",@"imageNameBlue",
                    @"Icon_terms@2x.png",@"imageNameWhite",
                    @"Terms & conditions",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_Support_@2x.png",@"imageNameBlue",
                    @"Icon_Support_White_@2x.png",@"imageNameWhite",
                    @"App tutorial",@"title", nil]];

    /*
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_Prevention_@2x.png",@"imageNameBlue",
                    @"Icon_Prevention_White_@2x.png",@"imageNameWhite",
                    @"My preventive care",@"title", nil]];
    
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_MyAppointments_@2x.png",@"imageNameBlue",
                    @"Icon_MyAppointments_White_@2x.png",@"imageNameWhite",
                    @"My appointments",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_TimelyTips_@2x.png",@"imageNameBlue",
                    @"Icon_TimelyTips_White_@2x.png",@"imageNameWhite",
                    @"Timely health tips",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_LocateAFacility_@2x.png",@"imageNameBlue",
                    @"Icon_LocateAFacility_White_@2x.png",@"imageNameWhite",
                    @"Locate a facility",@"title", nil]];
   
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_MyDoctors_@2x.png",@"imageNameBlue",
                    @"Icon_MyDoctors_White_@2x.png",@"imageNameWhite",
                    @"My personal doctor",@"title", nil]];
     */
   
    [[NSUserDefaults standardUserDefaults] setObject:arr forKey:@"TabBarIconDetails"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [arr release];
    
    tabBarController.viewControllers = m_maCurrentVCs;
    tabBarController.selectedIndex = self.launchTabIndex;
    
    /*
    [self.tabBarController.tabBar setHidden:NO];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"_fromLandingView"];
    tabBarController.selectedIndex = 2;
    */
    
	tabBarController.customizableViewControllers = [NSArray arrayWithObjects:nil]; // No edit button    
        
}


- (void)popAllTabsToRoot
{
    for (UIViewController* vc in tabBarController.viewControllers)
    {
        if ([vc isKindOfClass:[UINavigationController class]])
        {
            UINavigationController* nc = (UINavigationController*)vc;                    
            [nc popToRootViewControllerAnimated:NO];
        }
    }

    // Pop the more nav controller to root
    [tabBarController.moreNavigationController popToRootViewControllerAnimated:NO];
    
    tabBarController.selectedIndex = 0;
}

- (void)setFullModeWithCheck
{
    if (TBM_FULL == m_nTabBarMode)
    {
        return;
    }
    
    [self setFullMode];
}

- (void)setFullMode
{
    
    m_nTabBarMode = TBM_FULL;    
    
    // Create a new set of VCs
    self.m_maCurrentVCs = [NSMutableArray arrayWithCapacity:0];
    
    [self addToTabVC:[[[LandingViewController alloc] init] autorelease] 
            tabTitle:@"Home" 
             tabIcon:@"Icon_Home_Off.png" 
         andNavTitle:@"My preventive care"];

    [self addToTabVC:[[[ActivationSettingsViewController alloc] init] autorelease] 
            tabTitle:@"Settings" 
             tabIcon:@"icon_settings.png" 
         andNavTitle:@"Settings"];
    
    /*
    [self addToTabVC:[[[VCRootListPhp alloc] init] autorelease] 
            tabTitle:@"Prevention" 
             tabIcon:@"tabprev.png" 
         andNavTitle:@"My preventive care"];
    
    [self addToTabVC:[[[VCRootListAppts alloc] init] autorelease] 
            tabTitle:@"Appts" 
             tabIcon:@"tabappt.png" 
         andNavTitle:@"My appointments"];
    
    [self addToTabVC:[[[TipListViewController alloc] init] autorelease] 
            tabTitle:@"Timely tips" 
             tabIcon:@"tabtips.png" 
         andNavTitle:@"Timely health tips"];    
    
    [self addToTabVC:[[[MyDoctorView alloc] init] autorelease] 
            tabTitle:@"My personal doctor" 
             tabIcon:@"icon_MyDoctors_Black.png" 
         andNavTitle:@"My personal doctor"];    
    
    [self addToTabVC:[[[CallViewController alloc] init] autorelease] 
            tabTitle:@"Call" 
             tabIcon:@"icon_call.png" 
         andNavTitle:@"Call"];
    
    [self addToTabVC:[[[FacilitiesMainListView alloc] init] autorelease]
            tabTitle:@"Locate a facility" 
             tabIcon:@"tabfac.png" 
         andNavTitle:@"Locate a facility"];
    
    // ABhinav - For app store code
//    [self addToTabVC:[[[SecureMessageView alloc] init] autorelease]
//            tabTitle:@"Secure Message" 
//             tabIcon:@"tabfac.png" 
//         andNavTitle:@"Secure Message"];
    
    // ABhinav - For app store code

    
    [self addToTabVC:[[[ProfileListViewController alloc] init] autorelease] 
            tabTitle:@"My profile" 
             tabIcon:@"icon_profiles.png" 
         andNavTitle:@"My profile"];
    
    [self addToTabVC:[[[SettingsViewController alloc] init] autorelease] 
            tabTitle:@"Settings" 
             tabIcon:@"icon_settings.png" 
         andNavTitle:@"Settings"];
     */
    
    [self addToTabVC:[[[SupportViewController alloc] init] autorelease] 
            tabTitle:@"App support" 
             tabIcon:@"icon_support.png" 
         andNavTitle:@"App support"];    
    
    [self addToTabVC:[[[TermsAndConditionsViewController alloc] init] autorelease] 
            tabTitle:@"Terms & conditions" // this will be in the more VC. 
             tabIcon:@"icon_terms.png" 
         andNavTitle:@"Terms & conditions"];
     
    [self addToTabVC:[[[TutorialViewController alloc] initWithMode:YES] autorelease]
            tabTitle:@"Tutorial"
             tabIcon:@"icon_support.png"
         andNavTitle:@"App support"];
    
    // Abhinav Sehgal - Landing View
    NSMutableArray *arr = [[NSMutableArray alloc] init];
    /*
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_Prevention_@2x.png",@"imageNameBlue",
                    @"Icon_Prevention_White_@2x.png",@"imageNameWhite",
                    @"My preventive care",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_MyAppointments_@2x.png",@"imageNameBlue",
                    @"Icon_MyAppointments_White_@2x.png",@"imageNameWhite",
                    @"My appointments",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_MyDoctors_@2x.png",@"imageNameBlue",
                    @"Icon_MyDoctors_White_@2x.png",@"imageNameWhite",
                    @"My personal doctor",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"icon_call_blue.png",@"imageNameBlue",
                    @"icon_call_white.png",@"imageNameWhite",
                    @"Call",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_TimelyTips_@2x.png",@"imageNameBlue",
                    @"Icon_TimelyTips_White_@2x.png",@"imageNameWhite",
                    @"Timely health tips",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_LocateAFacility_@2x.png",@"imageNameBlue",
                    @"Icon_LocateAFacility_White_@2x.png",@"imageNameWhite",
                    @"Locate a facility",@"title", nil]];
    
    // ABhinav - For app store code
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_MyProfile_@2x.png",@"imageNameBlue",
                    @"Icon_MyProfile_White_@2x.png",@"imageNameWhite",
                    @"My profile",@"title", nil]];
     */
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"icon_Settings_Blue@2x.png",@"imageNameBlue",
                    @"icon_Settings_White@2x.png",@"imageNameWhite",
                    @"Settings",@"title", nil]];
    

    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_Support_@2x.png",@"imageNameBlue",
                    @"Icon_Support_White_@2x.png",@"imageNameWhite",
                    @"App support",@"title", nil]];

    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_terms@2x.png",@"imageNameBlue",
                    @"Icon_terms@2x.png",@"imageNameWhite",
                    @"Terms & conditions",@"title", nil]];
    
    [arr addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                    @"Icon_Support_@2x.png",@"imageNameBlue",
                    @"Icon_Support_White_@2x.png",@"imageNameWhite",
                    @"App tutorial",@"title", nil]];

    // ABhinav - For app store code
    

    [[NSUserDefaults standardUserDefaults] setObject:arr forKey:@"TabBarIconDetails"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [arr release];
    
    tabBarController.viewControllers = m_maCurrentVCs;
    tabBarController.selectedIndex = self.launchTabIndex;
	tabBarController.customizableViewControllers = [NSArray arrayWithObjects:nil]; // No edit button    
    tabBarController.moreNavigationController.navigationBar.tintColor = navBarColor;    
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alert clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alert.tag==kAPNSAlert) {
        if (buttonIndex==1) {
//            // reset viewing level
//            UIViewController* vc=tabBarController.selectedViewController;                        
//            if ([vc isKindOfClass:[UINavigationController class]])
//            {
//                UINavigationController* nc = (UINavigationController*)vc;
//                
//                if ([nc.viewControllers count] == 0)
//                {
//                    [tabBarController.moreNavigationController popToRootViewControllerAnimated:NO];
//                    
//                }
//                else
//                {
//                    [nc popToRootViewControllerAnimated:NO];
//                }
//            }
//            
//            // force full refresh?
//            [[HandshakeMan get] refreshEverything];
            [self handlePushNotification:self.notificationInfo];
        }
    }
    
    if (alert.tag == 1000) {
        if (buttonIndex == 0)
        {
            
            // Google Analyser
            [Utilities postGATrackEventName:@"DeviceDeactivated" withActionName:@"Tracking Deactivation" andlabel:@""];
                      
            int_deactivate = 1;
            [self hideMessage];
            [[AuthorizationMan get] deauthorize];
            [self showMerlinWithState:DEAUTHORIZED];
        }

    }
}

#pragma mark -
#pragma mark UITabBarControllerDelegate methods

- (void) tabBarController:(UITabBarController*)aTabBarController didSelectViewController:(UIViewController*)viewController
{
    [[Utilities getAppDel] hideAi];
    if (aTabBarController.selectedIndex == 0) {
        if ([Utilities getAppDel].facOnly)
        { 
        }
        else{
            if (int_showMessage == 1) {
                int_showMessage = 0;
                [self hideMessage];
            }
        }
        if (self.isApptBooking == TRUE) {
            UIViewController *vc = [[self.tabBarController viewControllers] objectAtIndex:1];
            [(UINavigationController *)vc popToRootViewControllerAnimated:NO];
           // self.isApptBooking = FALSE;
           // [self action_terminateApptBooking];
        }
    }
    else if (aTabBarController.selectedIndex == 1) {
        if (self.isApptBooking == TRUE) {
            UIViewController *vc = [[self.tabBarController viewControllers] objectAtIndex:1];
            [(UINavigationController *)vc popToRootViewControllerAnimated:NO];
            // self.isApptBooking = FALSE;
            // [self action_terminateApptBooking];
        }
       // [(UINavigationController *)viewController popToRootViewControllerAnimated:YES] ;
        
    }
    else if (aTabBarController.selectedIndex == 2) {
        if (self.isApptBooking == TRUE) {
            UIViewController *vc = [[self.tabBarController viewControllers] objectAtIndex:1];
            [(UINavigationController *)vc popToRootViewControllerAnimated:NO];
           // self.isApptBooking = FALSE;
           // [self action_terminateApptBooking];
        }
    }
    else if (aTabBarController.selectedIndex == 3) {
        if (self.isApptBooking == TRUE) {
            UIViewController *vc = [[self.tabBarController viewControllers] objectAtIndex:1];
            [(UINavigationController *)vc popToRootViewControllerAnimated:NO];
          //  self.isApptBooking = FALSE;
            
           // [self action_terminateApptBooking];
        }
    }
    else if (aTabBarController.selectedIndex == 4) {
        if (self.isApptBooking == TRUE) {
            UIViewController *vc = [[self.tabBarController viewControllers] objectAtIndex:1];
            [(UINavigationController *)vc popToRootViewControllerAnimated:NO];
          //  self.isApptBooking = FALSE;
           // [self action_terminateApptBooking];
        }
    }
    else{
        if (self.isApptBooking == TRUE) {
            UIViewController *vc = [[self.tabBarController viewControllers] objectAtIndex:1];
            [(UINavigationController *)vc popToRootViewControllerAnimated:NO];
         //  self.isApptBooking = FALSE;
           // [self action_terminateApptBooking];
        }
        if (int_showMessage == 1) {
            int_showMessage = 0;
            [self hideMessage];
        }
    }
    
  //  if (aTabBarController.selectedIndex > 3) {
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"_fromLandingView"];
  //  }
    
//    UINavigationController* nc = (UINavigationController*)viewController;
//
//    [nc popToRootViewControllerAnimated:NO];
//    
//    AppointmentViewGroupedController *ac = [[[AppointmentViewGroupedController alloc] initWithNibName:@"AppointmentViewGrouped" 
//                                                                                               bundle:nil] autorelease];
//            
//    [nc pushViewController:ac animated:YES];
//    viewController.tabBarItem.badgeValue = nil;
}

- (void)registerDefaultsFromSettingsBundle 
{
    NSString *settingsBundle = [[NSBundle mainBundle] pathForResource:@"Settings" ofType:@"bundle"];

    if (!settingsBundle) 
    {
        return;
    }
	
    NSDictionary *settingsList = [NSDictionary dictionaryWithContentsOfFile:[settingsBundle stringByAppendingPathComponent:@"Root.plist"]];
    
    NSArray *preferences = [settingsList objectForKey:@"PreferenceSpecifiers"];
	
    NSMutableDictionary *defaultsToRegister = [[NSMutableDictionary alloc] initWithCapacity:[preferences count]];
    
    for (NSDictionary *prefSpecification in preferences) 
    {
        NSString *key = [prefSpecification objectForKey:@"Key"];
    
        if (key) 
        {
            [defaultsToRegister setObject:[prefSpecification objectForKey:@"DefaultValue"] forKey:key];
        }
    }
    
    [[NSUserDefaults standardUserDefaults] registerDefaults:defaultsToRegister];
    
    [defaultsToRegister release];
}

/*
-(void)action_terminateApptBooking{
    
   // [[Utilities getAppDel] showAi];
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    
    NSMutableDictionary *dict = [[NSUserDefaults standardUserDefaults] objectForKey:@"ApptBooking"];
    if (dict != nil) {
        
        if ([[NSUserDefaults standardUserDefaults] boolForKey:@"Context_ID"]){
            [ApptScheduleMan terminateBook:self WithTargetMrn:[dict objectForKey:@"mrn"] contextID:[dict objectForKey:@"contextID"] bookingCode:[dict objectForKey:@"bookingCode"] isNewAppt:[dict objectForKey:@"isNew"]];
        }
        
    }
    else{
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
        [[Utilities getAppDel] hideAi];
    }
}
 */

- (BOOL)fetcher:(Fetcher*)fetcher didSucceedWithValue:(id)value
{
    if ([value isKindOfClass:[NSDictionary class]]) {
        NSDictionary* dRoot = (NSDictionary*)value;
        
        if ([[Utilities getStringFromJson:[[dRoot objectForKey:@"response"] objectForKey:@"statusCode"]] intValue] == 0 ) {
            LOG("Appt booking Terminated successfully");
            //self.isApptBooking = FALSE;
            [[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"ApptBooking"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
//        else{
//            [MessageMan showMessage:[NSString stringWithFormat:@"%@, Please try again later.", [[dRoot objectForKey:@"response"] objectForKey:@"message"]] withTitle:@"Error"];
//        }
    }
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    [[Utilities getAppDel] hideAi];
    return YES;
}

- (BOOL)fetcher:(Fetcher*)fetcher didFailWithError:(FETCHER_FAILURE)value
{
    [[Utilities getAppDel] hideAi];
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    return YES;
}

- (double)getLastMemberMedsSyncTime {
    return 1000000.00;
}

- (void)clearAllData {
    LOG("The App will clear all device data!");
}

@end
