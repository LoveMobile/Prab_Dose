//
//  AuthorizationCheck.h
//  MobileCare
//
//  Created by Paul on 5/17/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WSCheck.h"

@interface AuthorizationCheck : WSCheck 
{
}

@end
