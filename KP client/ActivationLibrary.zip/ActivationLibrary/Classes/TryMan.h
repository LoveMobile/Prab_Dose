//
//  TryMan.h
//  MobileCare
//
//  Created by Paul Yago on 6/10/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>

#define UD_KEY_USED_TRIES @"UD_KEY_USED_TRIES"
#define PASSCODE_MAX_TRIES 5

@interface TryMan : NSObject 
{
    int m_nMaxTries;
    int m_nUsedTries;
}

@property (assign) int usedTries;

+ (TryMan*)tryMan;
- (id)initWithMaxTries:(int)nMaxTries;
- (int)tryUsed;
- (void)addTry;
- (int)hasTries;
- (void)reset;

@end
