//
//  PasscodeViewController.h
//  MobileCare
//
//  Created by Sean Gilligan on 10/12/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MCPasscodeView.h"
#import "TryMan.h"

@protocol PasscodeViewControllerDelegate
- (void)passcodeFinished:(BOOL)valid;
- (void)deauthorize;
@end

@interface PasscodeViewController : UIViewController <MCPasscodeViewDelegate, UITextFieldDelegate>
{
	int startMode;
    
	MCPasscodeView* codeView; 
    
	UILabel* enterPasscodePrompt;
    //	UILabel* pleaseEnterPasscodePrompt;	
	UILabel* failedAttemptPrompt;	
	UILabel* tapReauthorizePrompt;	
    
    TryMan* m_tryMan;
    
	id<PasscodeViewControllerDelegate> m_delegate;
    
    // Abhinav
    
    UIView *m_passCodeView;
    
    UILabel *lbl_attempts;
    UILabel *lbl_title;
    UITextField *txt_passcode;
    NSString *str_enteredCode;
    UIButton *btn_reactivate;
    IBOutlet UIButton *btn_Done;
    
}
@property(nonatomic, retain) IBOutlet UIButton *btn_Done;
@property (nonatomic, assign) int startMode;
@property (nonatomic, retain) MCPasscodeView* codeView;
@property (nonatomic, retain) IBOutlet UIImageView*  bkgImgView;
@property (nonatomic, retain) IBOutlet UILabel* enterPasscodePrompt;
//@property (nonatomic, retain) IBOutlet UILabel* pleaseEnterPasscodePrompt;	
@property (nonatomic, retain) IBOutlet UILabel* failedAttemptPrompt;	
@property (nonatomic, retain) IBOutlet UILabel* tapReauthorizePrompt;	
@property (nonatomic, retain) TryMan* m_tryMan;
@property (retain, nonatomic) IBOutlet UIView *m_desinBtnView;

@property (nonatomic, retain) IBOutlet UIView *m_passCodeView;
@property (nonatomic, retain) IBOutlet UILabel *lbl_attempts;
@property (nonatomic, retain) IBOutlet UILabel *lbl_title;
@property (nonatomic, retain) IBOutlet UITextField *txt_passcode;
@property (nonatomic, retain) IBOutlet UIButton *btn_reactivate;

@property (nonatomic, retain) IBOutlet  UIView *m_errorPasscodeView;
@property (nonatomic , retain) IBOutlet UILabel *lbl_errorTitle;
@property (nonatomic , retain) IBOutlet UILabel *lbl_errorMsg;

- (IBAction)action_Done:(id)sender;

- (id)initWithDelegate:(id<PasscodeViewControllerDelegate>)del;
- (IBAction)reauthorize:(id)sender;

@end
