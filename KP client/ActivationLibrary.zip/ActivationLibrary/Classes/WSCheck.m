//
//  WSCheck.m
//  MobileCare
//
//  Created by Paul on 5/17/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "WSCheck.h"
#import "Constants.h"

@implementation WSCheck

@synthesize m_fetcher;
@synthesize delegate;

// The code can be sent from either the Fetcher or from the web-service.
// Therefore both are handled.
+ (SERVER_STATUS_RESULT)getStatusResultFromCode:(int)code
{    
    switch (code) 
    {
        case FF_CANCELED:
        case FF_FAILED:
        case FF_TIMEOUT:
            return WSC_NET_FAIL;
            break;
        case 0:
            return WSC_GOOD;
            break;
        case 1:
            return WSC_DEAUTH;
            break;
        case 2:
            return WSC_NOT_KP;
            break;
        case 3:
            return WSC_FORCED_UP;
            break;
        case 5:
            return WSC_AUTHENT_FAIL;
            break;
        case 6:
            return WSC_AUTHENT_LOCKOUT;
            break;
        case 7:
            return WSC_AUTHORIZE_FAIL;
            break;
        case 8:
            return WSC_NOT_NCAL;
            break;
        case 9:
            return WSC_USERID_CHANGED;
            break;
        // Abhinav Sehgal - System Maintenance Check    
        case 100:
            return WSC_SYS_MNTNC;
            break;
        default:
            return WSC_WS_FAIL;
            break;
    }
}

- (void)dealloc
{
    self.m_fetcher.delegate = nil;
    self.m_fetcher = nil;
    self.delegate = nil;
    
    [super dealloc];
}

- (void)startCheck
{}

- (BOOL)fetcher:(Fetcher*)fetcher didSucceedWithValue:(id)value
{
    // Assume no network failure
    // ... but check for WS failure
    int nRes = 20;
    
    if ([value isKindOfClass:[NSDictionary class]]) {
        NSDictionary* dRoot = (NSDictionary*)value;
    
        NSDictionary* dResponse = [dRoot objectForKey:@"response"];
    
    
        if ([dResponse objectForKey:@"statusCode"] != nil) {
            nRes = [[dResponse objectForKey:@"statusCode"] intValue];
        }
    }
    
    SERVER_STATUS_RESULT nSSR = [WSCheck getStatusResultFromCode:nRes];
    
    [delegate postResult:nSSR sender:self];

   // self.m_fetcher = nil;

    return YES;
}

- (BOOL)fetcher:(Fetcher*)fetcher didFailWithError:(FETCHER_FAILURE)ff
{   
    LOG("fetcher didFailWithError:%d", ff);
    SERVER_STATUS_RESULT nSSR = [WSCheck getStatusResultFromCode:ff];
    
    [delegate postResult:nSSR sender:self];
    
    return YES;
}

@end
