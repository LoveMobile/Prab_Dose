//
//  WarningViewController.h
//  ActivationLibrary
//
//
//

#import <UIKit/UIKit.h>
#import "FetcherJson.h"

@protocol WarningViewControllerDelegate
- (void)setPasscodeFinished:(BOOL)valid;
@end

@interface WarningViewController : UIViewController <FetcherDelegate>
{
    id<WarningViewControllerDelegate> m_delegate;
}

@property (nonatomic, retain) FetcherJson* m_fetcherJson;
@property (nonatomic, retain) NSDictionary *jsonDict;
@property (nonatomic, retain) NSString *serviceType;


-(id)initWithDelegate:(id<WarningViewControllerDelegate>)del;
-(IBAction)closeBtnTapClicked;

@end
