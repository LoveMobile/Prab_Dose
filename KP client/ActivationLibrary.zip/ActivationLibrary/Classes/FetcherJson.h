//
//  FetcherJson.h
//  MobileCare
//
//  Created by Paul on 5/18/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Fetcher.h"

#define kNotification_FetcherJson_CancelConnection @"FetcherJson_CancelConnection"

@interface FetcherJson : Fetcher
{
    // specific to KP - API
    NSString* m_szMethod;
    NSDictionary* m_dParams;
}

@property (nonatomic, copy) NSString* m_szMethod;
@property (nonatomic, retain) NSDictionary* m_dParams;

- (id)initWithMethod:(NSString *)szMethod andParams:(NSDictionary *)dParams;

@end
