//
//  TouchCapturingWindow.h
//  MobileCare
//
//  Created by Zhanquan He on 5/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TouchCapturingWindow : UIWindow {
    NSMutableArray *views;
    
@private
    UIView *touchView;
}

- (void)addViewForTouchPriority:(UIView*)view;
- (void)removeViewForTouchPriority:(UIView*)view;    

-(void)action_resetCookies;

@end
