//
//  PasscodeViewController.m
//  MobileCare
//
//  Created by Sean Gilligan on 10/12/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//
//  Refit; pyago 5/12

#import <AudioToolbox/AudioServices.h>

#import "PasscodeViewController.h"
#import "MobileCareAppDelegate.h"
#import "AuthorizationMan.h"
#import "Utilities.h"

@implementation PasscodeViewController

@synthesize btn_Done;
@synthesize startMode;
@synthesize codeView;
@synthesize bkgImgView;
@synthesize enterPasscodePrompt;
//@synthesize pleaseEnterPasscodePrompt;	
@synthesize failedAttemptPrompt;	
@synthesize tapReauthorizePrompt;
@synthesize m_tryMan;
@synthesize m_passCodeView;
@synthesize lbl_attempts;
@synthesize lbl_title;
@synthesize txt_passcode;
@synthesize btn_reactivate;
@synthesize m_errorPasscodeView;
@synthesize lbl_errorTitle;
@synthesize lbl_errorMsg;

- (id)initWithDelegate:(id<PasscodeViewControllerDelegate>)del
{
    self = [super initWithNibName:@"PasscodeView" bundle:nil];
    if (self)
    {
        m_delegate = del;
        self.m_tryMan = [TryMan tryMan];        
    }
    return self;
}

- (void)viewDidUnload 
{
    self.m_passCodeView = nil;
    self.lbl_title = nil;
    self.txt_passcode = nil;
    self.lbl_attempts = nil;
    self.codeView = nil;
    self.bkgImgView=nil;
    self.enterPasscodePrompt = nil;
//    self.pleaseEnterPasscodePrompt = nil;	
    self.failedAttemptPrompt = nil;	
    self.tapReauthorizePrompt = nil;   
    self.m_tryMan=nil;
    self.btn_reactivate = nil;
   // [self setAction_Done:nil];
    self.btn_Done = nil;
    [self setM_desinBtnView:nil];
    self.lbl_errorTitle=nil;
    self.lbl_errorMsg=nil;
    self.m_errorPasscodeView=nil;
    [super viewDidUnload];

}


- (void)dealloc 
{
    self.codeView = nil;
    self.bkgImgView=nil;
    self.enterPasscodePrompt = nil;
//    self.pleaseEnterPasscodePrompt = nil;	
    self.failedAttemptPrompt = nil;	
    self.tapReauthorizePrompt = nil;	
    self.m_tryMan = nil;
    self.btn_Done = nil;
    self.m_passCodeView = nil;
    self.lbl_title = nil;
    self.txt_passcode = nil;
    self.lbl_attempts = nil;
    self.btn_reactivate=nil;
    [self setM_desinBtnView:nil];
    self.lbl_errorTitle=nil;
    self.lbl_errorMsg=nil;
    self.m_errorPasscodeView=nil;    
    [super dealloc];
}

- (void)viewDidLoad 
{    
    [super viewDidLoad];
	
	startMode = 0;
////	enterPasscodePrompt.textColor = [UIColor colorWithRed:(CGFloat)153/256 green:(CGFloat)51/256 blue:(CGFloat)51/256 alpha:1];
//	[enterPasscodePrompt setFont:[UIFont fontWithName:@"Arial-BoldMT" size:24]];
//	enterPasscodePrompt.backgroundColor = [UIColor clearColor];
//	
////	pleaseEnterPasscodePrompt.textColor = [UIColor blackColor];
////	[pleaseEnterPasscodePrompt setFont:[UIFont fontWithName:@"Arial" size:14]];
////	pleaseEnterPasscodePrompt.backgroundColor = [UIColor clearColor];
//	
////	failedAttemptPrompt.textColor = [UIColor blackColor];
//	[failedAttemptPrompt setFont:[UIFont fontWithName:@"Arial" size:16]];
//	failedAttemptPrompt.backgroundColor = [UIColor clearColor];	
//	[failedAttemptPrompt setHidden:YES];
//	
////	tapReauthorizePrompt	.textColor = [UIColor blackColor];
//	[tapReauthorizePrompt	 setFont:[UIFont fontWithName:@"Arial" size:12]];
//	tapReauthorizePrompt	.backgroundColor = [UIColor clearColor];
//	
//    CGRect passcodeFrame = CGRectMake(0.0, 0.0, kMCPasscodeViewWidth, kMCPasscodeViewHeight);
//	self.codeView = [[[MCPasscodeView alloc] initWithFrame:passcodeFrame] autorelease];
//	codeView.passcodeDelegate = self;
//    [codeView setPromptText:@""];
	
		
//    UIBarButtonItem *deauthButton = [[[UIBarButtonItem alloc] initWithTitle:@"Reactivate" 
//                                                                      style:UIBarButtonItemStylePlain 
//                                                                     target:self 
//                                                                     action:@selector(reauthorize:)] autorelease];
//    
//    self.navigationItem.leftBarButtonItem = deauthButton;
    
    
//    UIBarButtonItem *doneButton = [[[UIBarButtonItem alloc] initWithTitle:@"Done" 
//                                                                      style:UIBarButtonItemStylePlain 
//                                                                     target:self 
//                                                                     action:@selector(action_Done)] autorelease];
//    
//    self.navigationItem.rightBarButtonItem = doneButton;
    

    
    
    self.lbl_attempts.text = @"";
    self.m_passCodeView.backgroundColor = [UIColor clearColor];
    [self.txt_passcode becomeFirstResponder];
    
    CGRect r=self.m_passCodeView.frame;
    r.origin.y=r.origin.y+55;
    self.m_passCodeView.frame=r;    
    [self.view addSubview:self.m_passCodeView];
    
    [self.view addSubview:self.m_desinBtnView];
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    
    if (screenBounds.size.height == 568) {
        // code for 4-inch screen
        self.m_desinBtnView.frame = CGRectMake(0, 288, 320, 44);
        
    } else {
        // code for 3.5-inch screen
        self.m_desinBtnView.frame = CGRectMake(0, 203, 320, 44);
        
    }
        
         [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange:) name:UITextFieldTextDidChangeNotification object:nil];
    
	//[self.view addSubview:codeView];
    
    if ([self.m_tryMan usedTries] > 0)
    {
        lbl_title.alpha = 0;
       // [failedAttemptPrompt setHidden:NO];
        self.lbl_attempts.text=[NSString stringWithFormat:@"%d attempts remaining", [self.m_tryMan hasTries]];
        //self.m_passCodeView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
        self.lbl_errorTitle.text=@"Enter Passcode";
        self.lbl_errorMsg.text=@"";
        self.m_errorPasscodeView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
        self.m_errorPasscodeView.frame = CGRectMake(0, 42, 320, 65);
        [self.view addSubview:self.m_errorPasscodeView];

    }
    
}

- (void)informDelegate
{
    [m_delegate passcodeFinished:YES];
}

-(void)textDidChange:(NSNotification *)notification{
    
    if ([self.txt_passcode.text length] > 12) {
        self.txt_passcode.text = [self.txt_passcode.text substringToIndex:12];
    }
    else{
        
        str_enteredCode = [self.txt_passcode.text retain];
    }
    
}
- (IBAction)action_Done:(id)sender{
    /*
    if ([[AuthorizationMan get].passCode isEqualToString:str_enteredCode]) {
       // [Utilities getAppDel].isSynchingCompleted = TRUE;
        [self performSelector:@selector(action_Valid) withObject:nil afterDelay:0.1];
    }
    else{
        [self performSelector:@selector(action_invalid) withObject:nil afterDelay:0.1];
    }
     */
}

-(void)action_Valid{
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"_isEnteredPasscode"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    self.lbl_attempts.text = @"";
  //  [self performSelector:@selector(informDelegate) withObject:nil afterDelay:.1];
    [self.m_errorPasscodeView removeFromSuperview];
    [m_delegate passcodeFinished:YES];
    [self.m_tryMan reset];
}

-(void)action_invalid{
    
    self.lbl_title.text = @"Wrong passcode";
    lbl_title.alpha = 0;
    [self.m_tryMan tryUsed];
    self.lbl_attempts.text=[NSString stringWithFormat:@"%d attempts remaining", [self.m_tryMan hasTries]];
    //self.m_passCodeView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
    self.lbl_errorTitle.text=@"Wrong Passcode";
    self.lbl_errorMsg.text=@"try again";
    self.m_errorPasscodeView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
    self.m_errorPasscodeView.frame = CGRectMake(0, 42, 320, 65);
    [self.view addSubview:self.m_errorPasscodeView];

    self.txt_passcode.text = @"";
    
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    
    if ([self.m_tryMan hasTries] <= 0)
    {
        
        [m_delegate deauthorize];
        [[Utilities getAppDel] hideMessage];
    }

}

- (void)passcodeView:(MCPasscodeView*)pcv didEnterValidPassocde:(NSString*)passcode
{
    NSAssert(m_delegate, @"delegate doesn't exist");
    
    // This should dismiss the PC dialog.
    [self performSelector:@selector(informDelegate) withObject:nil afterDelay:1];
    [self.m_tryMan reset];
}

- (void)passcodeView:(MCPasscodeView*)pcv didEnterInvalidPassocde:(NSString*)passcode;
{
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);

    enterPasscodePrompt.text = @"Wrong passcode";
    
    [failedAttemptPrompt setHidden:NO];
    [self.m_tryMan tryUsed];
    failedAttemptPrompt.text=[NSString stringWithFormat:@"%d attempts remaining", [self.m_tryMan hasTries]];
    self.bkgImgView.image=[UIImage imageNamed:@"error_overlay.png"];
//    pleaseEnterPasscodePrompt.text = [NSString stringWithFormat:@"%d Failed Attempts", [self.m_tryMan tryUsed]];
//    pleaseEnterPasscodePrompt.backgroundColor = [UIColor clearColor];
//    pleaseEnterPasscodePrompt.textColor = [UIColor redColor];

    
        
    if ([self.m_tryMan hasTries] <= 0)
    {
        [m_delegate deauthorize];
    }
}

- (BOOL)passcodeView:(MCPasscodeView*)pcv isPasscodeValid:(NSString*)passcode
{
    //return [[AuthorizationMan get].passCode isEqualToString:passcode];
    return NO;
}

- (IBAction)reauthorize:(id)sender 
{
	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Reactivate device" 
                                                    message:@"Are you sure you want to reactivate this device?" 
                                                   delegate:self 
                                          cancelButtonTitle:@"No" 
                                          otherButtonTitles:@"Yes", nil] autorelease];
	[alert show];
}

#pragma mark -
#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alert clickedButtonAtIndex:(NSInteger)buttonIndex
{	
	if (buttonIndex != 0)
	{
        
        [m_delegate deauthorize];
        [[Utilities getAppDel] hideMessage];
        
	}	
}


@end
