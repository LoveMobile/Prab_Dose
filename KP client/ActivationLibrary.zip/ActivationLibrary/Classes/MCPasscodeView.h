//
//  MCPasscodeView.h
//  MobileCare
//
//  Created by Sean Gilligan on 12/21/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MCPasscodeView;

#define kMCPasscodeViewWidth	320
#define kMCPasscodeViewHeight	240
#define kMCDigitFieldWidth		60.0
#define kMCDigitFieldHeight		60.0


@protocol MCPasscodeViewDelegate
//- (BOOL) didEnterPasscode:(UIView*)passcodeView passcode:(NSString*)passcodeString;
- (void)passcodeView:(MCPasscodeView*)pcv didEnterValidPassocde:(NSString*)passcode;
- (void)passcodeView:(MCPasscodeView*)pcv didEnterInvalidPassocde:(NSString*)passcode;
- (BOOL)passcodeView:(MCPasscodeView*)pcv isPasscodeValid:(NSString*)passcode;
@end

@interface MCPasscodeView : UIView <UITextFieldDelegate>
{
	id<MCPasscodeViewDelegate>	passcodeDelegate;
	UITextField				*code1;
	UITextField				*code2;
	UITextField				*code3;
	UITextField				*code4;	
	UITextField				*hiddenField;

//	UILabel					*prompt;
//	NSString				*passcodeLabel;

	UILabel* m_lbPrompt;
	
    
    BOOL					resetting;
}

- (void)setPromptText:(NSString*)szText;

//@property (nonatomic, retain) NSString* passcodeLabel;
@property (nonatomic, retain) UILabel* m_lbPrompt;
@property (assign) id passcodeDelegate;


- (void) makeActive;

@end
