//
//  PrivacyPracticesViewController.h
//  MobileCare
//
//  Created by Abhinav Sehgal.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.

#import <UIKit/UIKit.h>
#import "MCWebViewController.h"
#import "PhoneLinkHandler.h"

@interface PrivacyPracticesViewController : MCWebViewController {
    
}

@property (strong, nonatomic) IBOutlet UIWebView *m_webView;
@property (nonatomic, assign) BOOL isloadCompleted;
@property (nonatomic, assign) BOOL isBackClicked;
@property (nonatomic, strong) PhoneLinkHandler *phoneHandler;

@end
