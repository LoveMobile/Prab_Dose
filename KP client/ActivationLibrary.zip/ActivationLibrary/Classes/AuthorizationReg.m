//
//  AuthorizationReg.m
//  MobileCare
//
//  Created by Paul on 5/18/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "AuthorizationReg.h"
#import "NetworkMan.h"
#import "JSON.h"
#import "Utilities.h"
#import "Constants.h"

@implementation AuthorizationReg

- (void)startCheck
{
    NSAssert(self.delegate, @"delegate should be set");

    NSDictionary* di = [Utilities getDeviceParamsDict];
    
    self.m_fetcher = [[[FetcherJson alloc] initWithMethod:@"registerMobileDevice" andParams:di] autorelease];
    self.m_fetcher.delegate = self;
    [self.m_fetcher fetch];
}

@end