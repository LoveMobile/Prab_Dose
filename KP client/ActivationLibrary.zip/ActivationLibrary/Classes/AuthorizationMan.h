//
//  AuthorizationMan.h
//  MobileCare
//
//  Created by Paul on 5/3/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "KeychainItemWrapper.h"
#import "SFHFKeychainUtils.h"

#define UD_KEY_KC_CHECK @"kc_check"
#define APP_KC_KEY @"mykpmeds"
#define MRN_KC_KEY @"mrn"
#define TOKEN_KC_KEY @"token"
#define PASSCODE_KC_KEY @"passcode"
#define USERNAME_KC_KEY @"userName"
#define PASSWORD_KC_KEY @"password"
#define USERID_KC_KEY @"userId"
#define LOGINNAME_KC_KEY @"loginName"
#define UD_PREVIOUS_USER_CHECK @"pre_user_check"
#define UD_OFFLINE_MODE_LOCKED @"offline_locked"
#define UD_APP_CLEAR_DATA_FLAG @"app_clear_data_flag"
#define UD_WARNING_ACCEPTED @"warning_accepted"


// TODO : Make state machine.

@interface AuthorizationMan : NSObject 
{
}

//@property (nonatomic, retain) NSString* mrn;
//@property (nonatomic, retain) NSString* kpToken;
//@property (nonatomic, retain) NSString* passCode;
@property (nonatomic, retain) NSString* userName;
@property (nonatomic, retain) NSString* password;
@property (nonatomic, retain) NSString* userId;
@property (nonatomic, strong) NSString* loginName;

+ (AuthorizationMan*)get;

- (BOOL)isAuthorized;
- (void)reset; // clears the token, mrn, and entry code from the keychain.
//- (BOOL)passcodeRequired;
- (void)deauthorize;
- (void)saveValuesToKC;
//- (void)resetPasscode;
//- (void)assignPC:(NSString*)szPC;
//- (void)assignToken:(NSString*)szToken;
- (void)getValuesFromKC;
- (void)saveValuesToKC;
//- (BOOL)isSetPasscodeRequired;
- (void)saveUsernamePassword:(NSString *)username;
- (BOOL)isPreviousUserExisted;
- (BOOL)isOfflineModeLocked;
- (BOOL)hasWarningAccepted;
- (BOOL)shouldAppClearData;
- (void)resetAppClearDataFlag;
- (void)getLoginNameFromKC;
- (void)saveLoginNameToKC;
- (void)resetDevice;

@end
