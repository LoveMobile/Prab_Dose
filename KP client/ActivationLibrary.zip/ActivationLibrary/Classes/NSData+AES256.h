//
//  NSData+AES256.h
//  MobileCare
//
//  Created by GK on 1/6/14.
//  Copyright 2014 Kaiser Permanente. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSData (AES256)

- (NSData *)AES256EncryptWithKey:(NSString *)key;
- (NSData *)AES256DecryptWithKey:(NSString *)key;

@end
