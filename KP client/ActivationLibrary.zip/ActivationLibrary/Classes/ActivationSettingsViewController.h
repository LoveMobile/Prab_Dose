//
//  ActivationSettingsViewController.h
//  MobileCare
//
//  Created by Sean Gilligan on 10/12/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//  Refurb Appstem/Kaiser
//

#import <UIKit/UIKit.h>
#import "SetPasscodeViewController.h"


@interface ActivationSettingsViewController : UIViewController <UITableViewDataSource, 
                                                        UIAlertViewDelegate, 
                                                        UITableViewDelegate,
                                                        SetPasscodeViewControllerDelegate>
{
	IBOutlet UITableView		*tableView;
	//IBOutlet UITableViewCell	*cellSwitchPasscodeLock;
    IBOutlet UITableViewCell	*cellPassCodeChange;
	IBOutlet UITableViewCell	*cellPushNotificationsDisclosure;
	IBOutlet UITableViewCell	*cellDeauthorizePhone;
	//IBOutlet UISwitch			*switchPasscodeLock;
    //IBOutlet UIButton			*changePasscode;
	IBOutlet UILabel			*marketingVersionLabel;
}
@property (nonatomic, retain) UIButton *deactivateButton;
@property (nonatomic, retain) SetPasscodeViewController *setPcVC;

- (IBAction)passcodeLockSwitchChanged:(UISwitch *)sender;
- (IBAction)changePassCode:(id)sender;
- (void)deauthorizePhone:(id)sender;
- (void) passcodeLockEnableChanged:(NSNotification *)notification;

@end
