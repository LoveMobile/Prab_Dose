//
//  LocationMan.h
//  MobileCare
//
//  Created by Zhanquan He on 5/18/11.
//  Copyright 2011 kaiser Permanente. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

typedef enum {
    INITIALIZING,
    NOTALLOWED,
    UPDATING,
    STOPPED,
} LOCATION_MAN_STATE;

@class LocationMan;

@protocol LocationManDelegate <NSObject>

- (void) locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error;
- (void) locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation;

@end

@interface LocationMan : NSObject <CLLocationManagerDelegate>
{
	CLLocationManager *m_locationManager;
    LOCATION_MAN_STATE m_state;
    id<LocationManDelegate> m_delegate;
}

@property (nonatomic, retain) CLLocationManager *locationManager;
@property (assign) LOCATION_MAN_STATE state; 
@property (assign) id<LocationManDelegate> delegate; 

+ (LocationMan*)get;
- (void) firstStart;
- (void) startUpdateLocation;
- (void) stopUpdateLocation;
- (CLLocation *) getCurrentLocation;
- (CLLocationCoordinate2D) getCurrentCoord;
- (BOOL) isAppLocationServiceAllowed;

@end

