//
//  LocationMan.m
//  MobileCare
//
//  Created by Zhanquan He on 5/18/11.
//  Copyright 2011 Kaiser Permanente. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>
#import "LocationMan.h"
#import "Constants.h"

static LocationMan *mLM=nil;

@implementation LocationMan

@synthesize locationManager = m_locationManager;
@synthesize state=m_state;
@synthesize delegate=m_delegate;

+ (LocationMan*)get
{
    if (nil == mLM)
    {
        mLM = [[LocationMan alloc] init];
    }
    return mLM;
}

- (id)init
{
    if ((self = [super init]))
    {
        self.locationManager = [[[CLLocationManager alloc] init] autorelease];
        self.locationManager.purpose=@"Turn on Location Services to help you find the nearby facilities.";
    }
    return self;
}

- (void) firstStart {
    [self.locationManager setDesiredAccuracy:kCLLocationAccuracyNearestTenMeters];
    [self.locationManager setDistanceFilter:10.0f];
    [self.locationManager setDelegate:self];
    [self.locationManager startUpdatingLocation];
    self.state=INITIALIZING;
    LOG("The current state of LocationMan is INITIALIZING.");
}

- (void) startUpdateLocation {
    if ([self isAppLocationServiceAllowed]) {
        [self.locationManager startUpdatingLocation];
        self.state=UPDATING;
        LOG("The current state of LocationMan is UPDATING.");
    }
}

- (void) stopUpdateLocation {
    if (self.state==UPDATING) {
        [self.locationManager stopUpdatingLocation];
        self.state=STOPPED;
        LOG("The current state of LocationMan is STOPPED.");
    }
}

- (void) locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
	LOG("Location manager error: %@", error);
    if ([error code]==kCLErrorDenied) {
        if (self.state==INITIALIZING) {
            [manager stopUpdatingLocation];
        }
        self.state=NOTALLOWED;
        LOG("The current state of LocationMan is NOT ALLOWED.");
    }
    
    if (self.delegate!=nil) {
        [self.delegate locationManager:manager didFailWithError:error];
    }  
}

- (void) locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if (self.state==INITIALIZING) {
        [manager stopUpdatingLocation];
        self.state=STOPPED;
        LOG("The current state of LocationMan is STOPPED.");
    }
    if (self.delegate!=nil) {
        [self.delegate locationManager:manager didUpdateToLocation:newLocation fromLocation:oldLocation];
    }
}

// This may return nil if the current location is never cached.
- (CLLocation *) getCurrentLocation 
{
    return [self.locationManager location];
}

- (CLLocationCoordinate2D) getCurrentCoord
{
    return [[self getCurrentLocation] coordinate];
}

- (BOOL) isAppLocationServiceAllowed {
    return (self.state!=NOTALLOWED?YES:NO);
}

- (void)dealloc
{
    self.locationManager = nil;
    [super dealloc];
}


@end
