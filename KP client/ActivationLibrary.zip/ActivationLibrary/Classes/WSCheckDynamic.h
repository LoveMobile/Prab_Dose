//
//  WSCheckDynamic.h
//  MobileCare
//
//  Created by Paul on 5/26/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WSCheck.h"

@interface WSCheckDynamic : WSCheck 
{
    NSString* m_szMethod;
    NSDictionary* m_dParams;
}

@property (nonatomic, retain) NSString* method;
@property (nonatomic, retain) NSDictionary* params;

- (id)initWithMethod:(NSString*)method andParams:(NSDictionary *)dParams;

@end
