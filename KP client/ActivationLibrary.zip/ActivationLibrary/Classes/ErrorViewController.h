//
//  ErrorViewController.h
//  ActivationLibrary
//
//
//

#import <UIKit/UIKit.h>

@interface ErrorViewController : UIViewController
{
   IBOutlet UILabel *lbl_error_title;
   IBOutlet UILabel *lbl_error;

}

@property (nonatomic, retain) IBOutlet UILabel *lbl_error_title;
@property (nonatomic, retain) IBOutlet UILabel *lbl_error;
@property (nonatomic, retain) NSString *errorMsg;
@property (nonatomic, retain) NSString *errorTitle;

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil withTitle:(NSString*)title andMessage:(NSString *)errMsg;

@end
