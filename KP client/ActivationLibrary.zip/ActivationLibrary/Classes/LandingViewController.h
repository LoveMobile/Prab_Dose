//
//  LandingViewController.h
//  MobileCare
//
//  Created by Abhinav Sehgal.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LandingViewCell.h"

@interface LandingViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    
  //  IBOutlet UIButton *btn_terms;
    UITableView *m_tableView;
    NSMutableArray *arr_data;
}

//@property(nonatomic, retain) IBOutlet UIButton *btn_terms;
@property(nonatomic, retain) NSMutableArray *arr_data;
@property(nonatomic, retain) IBOutlet UITableView *m_tableView;

//- (IBAction)action_termscond:(id)sender;

@end
