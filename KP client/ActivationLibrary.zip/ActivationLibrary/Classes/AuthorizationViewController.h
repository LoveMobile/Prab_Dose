//
//  AuthorizationViewController.h
//  MobileCareProto
//
//  Created by Sean Gilligan on 9/27/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//
//  Re-write Paul Yago
//

#import <UIKit/UIKit.h>
//#import "MCWebServices.h"
#import "FetcherJson.h"
#import "TryMan.h"
#import "TTGSignOnManager.h"

typedef enum
{
    SIGNIN,
    REGISTER,
    ACTIVATE,
} REQUEST_TYPE;

@protocol AuthorizationViewControllerDelegate
- (void)signOnComplete:(BOOL)valid;
-(void)AuthDone:(BOOL)valid;
-(double)getLastMemberMedsSyncTime;
@end


@interface AuthorizationViewController : UIViewController <UIWebViewDelegate,UIAlertViewDelegate,UITextFieldDelegate, FetcherDelegate> 
{	
	BOOL firstPageLoaded;
    BOOL isIphone5;
	
    NSString* m_curHostName;
	UIWebView* m_webView;
	UIView* m_backgroundView;
    UIBarButtonItem* m_bbiCancel;
    IBOutlet UIImageView *img_footer;
    
	id<AuthorizationViewControllerDelegate> m_delegate;
    UIButton *btn_accept;
    UIButton *btn_decline; 
    UIView *m_BottomContainerView;
    
    IBOutlet UIButton *onBtn;
    IBOutlet UIButton *offBtn;
    IBOutlet UIImageView *changeImage;
    

    // Sign ON View
    
    UIView *m_signOnView;
    
    UITextField *txt_userName;
    
    UITextField *txt_password;
    UIButton *btn_signOn;
    UILabel *lbl_invalidUID;
    UIButton *btn_forgotPwd;
    
    UIButton *btn_createAccount;
    UIView *m_signOnSubView;
    // Authorization Complete View
    
    UIView *m_authCompleteView;
    
    UIButton *btn_continue;
    
    // Error View
    
    UIView *m_errorView;
    UILabel *lbl_error_title;
    
    UILabel *lbl_error;
    
    FetcherJson* m_fetcherJson;
}
@property (retain, nonatomic) IBOutlet UIImageView *m_imgView;
@property (retain, nonatomic) IBOutlet UIImageView *m_confirmImgView;
@property (retain, nonatomic) IBOutlet UILabel *lbl_extraText;
@property (retain, nonatomic) IBOutlet UILabel *lbl_preventiveCare;
@property (nonatomic, retain) NSString* m_curHostName;
@property (nonatomic, retain) IBOutlet UIWebView* m_webView;
//@property (nonatomic, retain) IBOutlet UIView* m_backgroundView;
@property (nonatomic, retain) NSString* requestURL;
@property (nonatomic, retain) UIBarButtonItem* m_bbiCancel;
@property (assign) id<AuthorizationViewControllerDelegate> delegate;
@property (nonatomic, retain) FetcherJson* m_fetcherJson;
@property (nonatomic, retain) TryMan* m_tryMan;

@property (nonatomic, retain) IBOutlet UIButton *btn_accept;
@property (nonatomic, retain) IBOutlet UIButton *btn_decline; 
@property (nonatomic, retain) IBOutlet UIView *m_BottomContainerView;
@property (nonatomic, retain) IBOutlet UIView *m_signOnView;
@property (nonatomic, retain) IBOutlet UITextField *txt_userName;
@property (nonatomic, retain) IBOutlet UITextField *txt_password;
@property (nonatomic, retain) IBOutlet UIButton *btn_signOn;
@property (nonatomic, retain) IBOutlet UILabel *lbl_invalidUID;
@property (nonatomic, retain) IBOutlet UIButton *btn_forgotPwd;
@property (nonatomic, retain) IBOutlet UIView *m_authCompleteView;
@property (nonatomic, retain) IBOutlet UIButton *btn_continue;
@property (nonatomic, retain) IBOutlet UIView *m_errorView;
@property (nonatomic, retain) IBOutlet UILabel *lbl_error_title;
@property (nonatomic, retain) IBOutlet UILabel *lbl_error;
@property (nonatomic, retain) IBOutlet UIImageView *img_footer;
@property (nonatomic, retain) IBOutlet UIView *m_signOnSubView;
@property (nonatomic, retain) IBOutlet UIButton *btn_createAccount;
@property (strong, nonatomic) IBOutlet UILabel *l1PreventiveCare;
@property (strong, nonatomic) IBOutlet UIView *rememberView;
@property (strong, nonatomic) IBOutlet UIImageView *changeImageView;

@property (strong, nonatomic) IBOutlet UIView *termView;
@property (assign) REQUEST_TYPE requestType;
@property (strong, nonatomic) NSDictionary *signInResponse;

@property (strong, nonatomic) TTGSignOnManager *signOnManager;
@property (strong, nonatomic) NSString *userName;

- (IBAction)action_decline:(id)sender;
- (IBAction)action_accept:(id)sender;


- (id)initWithDelegate:(id<AuthorizationViewControllerDelegate>)del;
- (void)touchCancel:(id)sender;
- (void)loadWebView;

// sign On Actions
- (void)signOnCompleteAndValid;
- (IBAction)action_createAccount:(id)sender;
- (IBAction)action_forgotPWD:(id)sender;
- (IBAction)action_signOn:(id)sender;
//- (void)signOn:(NSString*)userId :(NSString*)password;
- (IBAction)action_continue:(id)sender;

// error View Actions

-(void)action_showError;
-(IBAction)userNameEditingChanged;
-(IBAction)termsAndConditionsBtnClicked;
-(IBAction)privacyStatementBtnClicked;

@end
