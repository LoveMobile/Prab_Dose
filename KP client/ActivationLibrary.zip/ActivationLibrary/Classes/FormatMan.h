//
//  FormatMan.h
//  MobileCare
//
//  Created by Paul on 4/21/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FormatMan : NSObject 
{
    NSDateFormatter* m_dateFormatter;
    NSDateFormatter* m_shortDateFormatter;
    NSDateFormatter* m_timeFormatter;
    NSDateFormatter* m_date_MMM_dd_yyyy_Formatter;
    NSNumberFormatter* m_numberFormatter;
}

+ (FormatMan*)get;

@property (nonatomic, retain) NSDateFormatter* dateFormatter;
@property (nonatomic, retain) NSDateFormatter* shortDateFormatter;
@property (nonatomic, retain) NSDateFormatter* timeFormatter;
@property (nonatomic, retain) NSDateFormatter* date_MMM_dd_yyyy_Formatter;
@property (nonatomic, retain) NSNumberFormatter* numberFormatter;

+ (NSString*)getDate:(NSDate*)dt;
+ (NSString*)getShortDate:(NSDate*)dt;
+ (NSString*)getTime:(NSDate*)dt;
+ (NSString*)getDateAsMMMddyyyy:(NSDate*)dt;
+ (NSDate*)getDateFromString:(NSString*)dt;
+ (double) getCurrentTimeInSeconds;

@end
