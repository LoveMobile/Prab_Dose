//
//  WebServiceMan.m
//  MobileCare
//
//  Created by Paul on 5/3/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "WebServiceMan.h"
#import "WSCheckDynamic.h"
#import "Utilities.h"
#import "MessageMan.h"
#import "Constants.h"

static WebServiceMan* m_wsm = nil;

@implementation WebServiceMan

@synthesize m_urlConfig;
@synthesize configurationType = m_nConfigType;
@synthesize wsBaseUrl, webBaseUrl;
@synthesize appId;

+ (WebServiceMan*)get
{
    if (nil == m_wsm)
    {
        m_wsm = [[WebServiceMan alloc] init];
    }
    return m_wsm;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        // Get WCT from user defaults
        // Set config type based on user defaults.
        // If DNE then specifiy WCT_UNSPECIFIED.
        
//        WS_CONFIG_TYPES nCT = [[NSUserDefaults standardUserDefaults] integerForKey:UD_KEY_CONFIG_TYPE]; 
//        [self setConfigType:nCT];
        
        // not use NSUserDefaults, just use info plist value to init
        WS_CONFIG_TYPES envType = [[Utilities getAppDel] getAppEnvironment];
        LOG("initializing environment for WebserviceMan based infoplist and the AppEnv type id is %i", envType);
        
        [self setConfigType:envType];
        self.wsBaseUrl=self.m_urlConfig.wsBaseURL;
        self.webBaseUrl=self.m_urlConfig.webBaseURL;
        self.appId=@"MD-5";
    }
    
    return self;
}

- (void)setConfigType:(WS_CONFIG_TYPES)wct
{
    m_nConfigType = wct;
    
    NSString* key = @"";
    
    switch (wct) 
    {
        case WCT_DEV:
            key = @"DEV";
            break;
            
        case WCT_QA:
            key = @"QA";
            break;
            
        case WCT_PRODUCTION:
            key = @"LIVE";
            break; 
            
        case WCT_PP:
            key = @"PP";
            break; 
            
        case WCT_LOCAL:
            key = @"LOCAL";
            break;             
        
        case WCT_UNSPECIFIED:
            key = @"LIVE"; // default to LIVE
            break;

        default:
            break;
    }
    
    self.m_urlConfig = [[[MCUrlConfig alloc] initWithKey:key] autorelease];

    // Save the user default
//    [[NSUserDefaults standardUserDefaults] setInteger:m_nConfigType forKey:UD_KEY_CONFIG_TYPE];
}


- (void)postResult:(SERVER_STATUS_RESULT)nState sender:(id)sender
{
    // Assuming that this is called by deauthorization.
    WSCheckDynamic* ws = ((WSCheckDynamic*)sender);
    
    // Certain types of failures well cause action (lockout, deauth, etc)
    // Certain errors can be ignored silently.
    switch (nState)
    {
        case WSC_FORCED_UP:
        case WSC_DEAUTH:
            // Tell HSM that there's a failure.
            // TODO : show merlin with appopriate status.
            [[Utilities getAppDel] showMerlin];
            break;
        case WSC_NOT_KP:
        case WSC_NET_FAIL:
        case WSC_WS_FAIL:
//            [MessageMan showMessage:@"Deauthorization command was not sent to server due to a network problem. Please deauthorize your device from your web page."];
            LOG("Failure in network call to %@ : %d", ws.method, nState);
            break;
        case WSC_GOOD:
        default:
            break;
    }
    
    // release this ws-check
    // TODO : Use property instead
    [ws release];
}

- (void)deauthorizeDevice
{
    WSCheckDynamic* wsDeauth = [[[WSCheckDynamic alloc] initWithMethod:@"deAuthorize" andParams:nil] autorelease];
    wsDeauth.delegate = self;
    [wsDeauth startCheck];
}

- (void)dealloc
{
    self.m_urlConfig = nil;
    self.webBaseUrl=nil;
    self.wsBaseUrl=nil;
    self.appId=nil;
    [super dealloc];
}


@end
