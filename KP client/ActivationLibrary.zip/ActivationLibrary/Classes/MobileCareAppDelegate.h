//
//  MobileCareAppDelegate.h
//  MobileCare
//
//  Created by Sean Gilligan on 8/16/10.
//  Copyright Fingerpaint Labs 2010. All rights reserved.
// 
//  Refactored : pyago/Appstem - 5/5/11

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "VCGeneralDialog.h"
#import "VCActivityIndicator.h"
#import "VCInitiator.h"
#import "TouchCapturingWindow.h"
#import "WebServiceMan.h"
// Abhinav Sehgal - Landing View
#import "LandingViewController.h"
#import "MessageVC.h"

int int_showPrivacyNavBar;
int int_showTermsNavbar;
int int_tabBarWhiteCsreen;
int int_decline;
int isRefreshPullView;
BOOL is_profile;
int int_choose;
int int_showMessage;
int int_deactivate;

int int_refresh;
id rootclassappts;
int intPrivacy;

extern NSString * const MCPasscodeLockEnableChangedNotification;
extern NSString * const MCReloadDataNotification;

typedef enum
{
    TBM_NOT_SET,
    TBM_FAC_ONLY,
    TBM_FULL,
} TAB_BAR_MODE;

@protocol MobileCareAppDelegateDelegate <NSObject>
- (void)merlinClosed;
@end

@interface MobileCareAppDelegate : NSObject <UIApplicationDelegate, 
                                                UITabBarControllerDelegate, 
                                                UIAlertViewDelegate, 
                                                VCMerlinDelegate,FetcherDelegate>
{
    UITabBarController* tabBarController;
	NSData* apnsDeviceToken;
	BOOL warnBeforeEmail;
	UIColor	*navBarColor;
	float progressUpdate;	
	NSString *emailDisclaimerType;
	NSString *apptContentURLString;
    VCActivityIndicator* m_ai;
    VCInitiator* m_initiator;
    BOOL m_bObserving;
    // AppClient must implement - start
    VCGeneralDialog* m_vcMerlin;
    // AppClient must implement - end
	UIView* m_messageView;
    UIButton* m_btAuthorize;
    UILabel* m_lbMessage;

    NSMutableArray* m_maCurrentVCs;
    TAB_BAR_MODE m_nTabBarMode;
    
//    MCBadges* m_aBadges;    
    UIImageView* splashView;
    
    id<MobileCareAppDelegateDelegate> m_delegate;
   // BOOL isSynchingCompleted;
    
    UIView *m_datePickerReference;
    UIView *m_pickerReference;
    
    BOOL isApptBooking;
    
}

@property(assign) BOOL isApptBooking; 

// Abhinav Sehgal - Landing View
@property (nonatomic, retain) UIView *m_datePickerReference;
@property (nonatomic, retain) UIView *m_pickerReference;
@property(assign) TAB_BAR_MODE m_nTabBarMode;
@property (assign) BOOL warnBeforeEmail;
@property (assign) BOOL changePasscodeActive;
@property (nonatomic, retain) NSData* apnsDeviceToken;
//@property (nonatomic, retain) NSDictionary *launcOptionsStored;
@property (nonatomic, retain) IBOutlet TouchCapturingWindow *window;
@property (nonatomic, retain) IBOutlet UITabBarController *tabBarController;
@property (nonatomic, retain) UIColor  *navBarColor;
@property (nonatomic, retain) NSURL *webDirBaseURL;
@property (nonatomic, assign) float progressUpdate;
@property (nonatomic, retain) NSString *emailDisclaimerType;
@property (nonatomic, retain) NSString *apptContentURLString;
@property (nonatomic, retain) VCGeneralDialog* m_vcMerlin;
@property (nonatomic, retain) VCActivityIndicator* m_ai;
@property (nonatomic, retain) MessageVC* m_msgVC;
@property (nonatomic, retain) VCInitiator *m_initiator;
@property (nonatomic, retain) IBOutlet UIView* messageView;
@property (nonatomic, retain) IBOutlet UIButton* btAuthorize;
@property (nonatomic, retain) IBOutlet UILabel* lbMessage;
@property (readonly) BOOL facOnly;
//@property (nonatomic, retain) MCBadges* m_badges;
@property (nonatomic, retain) UIImageView* splashView;
@property (nonatomic, retain) NSMutableArray* m_maCurrentVCs;
@property (nonatomic, assign) NSInteger launchTabIndex; 
@property (nonatomic, retain) NSDictionary *notificationInfo;
@property (assign) id<MobileCareAppDelegateDelegate> delegate;
@property (nonatomic, retain) NSMutableArray *alerts;
//@property (assign) BOOL isSynchingCompleted;

- (NSString*)appVersion;
//- (void)clearBadges;
- (void)registerDefaultsFromSettingsBundle;
//- (void)setBadges:(MCBadges*)badges;
- (void)handlePushNotification:(NSDictionary*)userInfo;
- (void)showMerlin;
- (void)showMerlinWithState:(WIZARD_STATE)eWizardState;
- (void)showAi:(NSString*)szText;
- (void)showInitiator:(NSString*)szText;
- (void)showAi;
- (void)showInitiator;
- (void)showAiWithoutBackground;
- (void)hideAi;
- (void)hideInitiator;
- (void)setFacOnlyMode;
- (void)setFullMode;
- (void)setFullModeWithCheck;
//- (void)setTabBarState;
- (void)showMessage:(NSString*)szMessage withButtonText:(NSString*)btText target:(id)t andSelector:(SEL)sel;
- (void)showMessage:(NSString*)szMessage withButtonText:(NSString*)btText;
- (void)showMessage:(NSString*)szMessage;
- (void)hideMessage;
- (IBAction)authoizeButtonPressed:(id)sender;
- (NSString*)getBundleVersion;
- (int)getAppEnvironment;
- (NSString*)getAppEnvironmentAsString;
- (void)popAllTabsToRoot;
-(NSString *)getAppDisplayName;
-(NSString *)getGoogleAccountID;
-(void)myAlertView;


//-(void)action_terminateApptBooking;
@end