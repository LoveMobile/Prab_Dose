//
//  LandingViewController.m
//  MobileCare
//
//  Created by Abhinav Sehgal.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
// 

#import "LandingViewController.h"
#import "MobileCareAppDelegate.h"
#import "Utilities.h"
#import "TutorialViewController.h"
//#import "CoreDataMan.h"

@implementation LandingViewController

//@synthesize btn_terms;
@synthesize arr_data;
@synthesize m_tableView;

int myTabHeight = 0;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
}

/* US 800 remove Remove settings icon from nav bar
-(void)action_setting{
    
    // Google Analyser
    [Utilities postGATrackEventName:@"Setting View Clicked" withActionName:@"tracking Setting View" andlabel:@""];
       
    self.tabBarController.view.frame =  CGRectMake(0, 20, 320, 460);
    [self.tabBarController.tabBar setHidden:NO];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"_fromLandingView"];
    [[[self.tabBarController viewControllers] objectAtIndex:7] popToRootViewControllerAnimated:NO];
    [Utilities getAppDel].tabBarController.selectedIndex = 7;
    
    [Utilities action_TransitionFromRight];
    
}
 */

//- (IBAction)action_termscond:(id)sender {
//    
//    // Google Analyser
//    [Utilities postGATrackEventName:@"Terms & condtion View Clicked" withActionName:@"tracking Terms & condtion View" andlabel:@""];
//        
//    self.tabBarController.view.frame =  CGRectMake(0, 20, 320, 460);
//    [self.tabBarController.tabBar setHidden:NO];
//    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"_fromLandingView"];
//    if ([Utilities getAppDel].facOnly)
//    {  
//        [[[self.tabBarController viewControllers] objectAtIndex:6] popToRootViewControllerAnimated:NO];
//        [Utilities getAppDel].tabBarController.selectedIndex = 6;
//        
//    }
//    else{
//        [[[self.tabBarController viewControllers] objectAtIndex:10] popToRootViewControllerAnimated:NO];
//        [Utilities getAppDel].tabBarController.selectedIndex = 10;
//    }
//    
//    [Utilities action_TransitionFromRight];
//}

-(void)viewWillAppear:(BOOL)animated{
    
    // Google Analyser
    [Utilities postGATrackPageName:@"LandingViewLaunched"];
    
    [self.tabBarController.tabBar setHidden:YES];
    
    if (myTabHeight == 0) {
        self.tabBarController.view.frame =  CGRectMake(0, 0, 320, 530);
        self.m_tableView.frame = CGRectMake(0, 20, 320, 430);
//        if ([Utilities getAppDel].facOnly)
//        { 
//            self.btn_terms.frame = CGRectMake(79, 290, 165, 37);
//        }
//        else{
//            self.btn_terms.frame = CGRectMake(79, 395, 165, 37);
//        }
        myTabHeight++;
    }
    else{
        self.tabBarController.view.frame =  CGRectMake(0, 20, 320, 530);
        self.m_tableView.frame = CGRectMake(0, 0, 320, 430);
//        if ([Utilities getAppDel].facOnly)
//        { 
//            self.btn_terms.frame = CGRectMake(79, 270, 165, 37);
//        }
//        else{
//            self.btn_terms.frame = CGRectMake(79, 375, 165, 37);
//        }
        
    }
    
  //  [self.btn_terms setTitleColor:[UIColor colorWithRed: (CGFloat)0/256
               //                                   green: (CGFloat)109/256
               //                                    blue: (CGFloat)157/256
              //                                    alpha:1] forState:UIControlStateNormal];
    
    UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]];
	self.view.backgroundColor = background;
	[background release];
    
    [[Utilities getAppDel] hideMessage];
    
    
    // Left Navigation button
    if ([Utilities getAppDel].facOnly)
    {  
        
    }
    else{
        /* US 800 remove Remove settings icon from nav bar
        UIImage* image3 = [UIImage imageNamed:@"Button_Header_Settings.png"];
        UIButton *someButton = [UIButton buttonWithType:UIButtonTypeCustom];
        someButton.frame = CGRectMake(0, 0, 40, 35);
        [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
        [someButton addTarget:self action:@selector(action_setting)
             forControlEvents:UIControlEventTouchUpInside];
        
        UIBarButtonItem *m_barSomeButton = [[[UIBarButtonItem alloc] initWithCustomView:someButton] autorelease];
        self.navigationItem.leftBarButtonItem = m_barSomeButton;
         */
        
    }
    
    self.arr_data = [[NSUserDefaults standardUserDefaults] objectForKey:@"TabBarIconDetails"];
    //logo-white.png
    
    UIImageView *titleView = [[UIImageView alloc] init];
    titleView.frame = CGRectMake(0, 7, 200, 30);
    titleView.image = [UIImage imageNamed:@"logo-white.png"];
    [self.navigationItem setTitleView:titleView];
    [titleView release];
    
    [self.m_tableView reloadData];
    
}


#pragma mark - Table View Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{ 
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{    
    return [self.arr_data count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* TableIdentifier = @"LandingViewCell";
	
	LandingViewCell *cell = (LandingViewCell*)[tableView dequeueReusableCellWithIdentifier:TableIdentifier];
    if (cell == nil) 
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"LandingViewCell" owner:self options:nil] lastObject];
        
	}
    
    cell.m_lbl.text = [[self.arr_data objectAtIndex:indexPath.row] valueForKey:@"title"];
    cell.m_lbl.backgroundColor = [UIColor clearColor];
    cell.m_lbl.textColor = [UIColor colorWithRed: (CGFloat)0/256 
                                           green: (CGFloat)129/256
                                            blue: (CGFloat)174/256
                                           alpha:1];
    cell.m_lbl.highlightedTextColor = [UIColor whiteColor];
    cell.m_lbl.font = [UIFont boldSystemFontOfSize:16];
    
    cell.m_image.image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[[self.arr_data objectAtIndex:indexPath.row] valueForKey:@"imageNameBlue"] ofType:@""]];
    cell.m_image.highlightedImage = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[[self.arr_data objectAtIndex:indexPath.row] valueForKey:@"imageNameWhite"] ofType:@""]];
    
//    if (indexPath.row == 0) {
//        cell.backgroundView = [[[UIImageView alloc ]initWithImage:[UIImage imageNamed:@"Home_LandingPage_Top_MenuButton@2x.png"]] autorelease];
//    }
//    else if (indexPath.row == [self.arr_data count]-1){
//        cell.backgroundView = [[[UIImageView alloc ]initWithImage:[UIImage imageNamed:@"Home_LandingPage_Bottom_MenuButton@2x.png"]] autorelease];
//    }
//    else{
        cell.backgroundView = [[[UIImageView alloc ]initWithImage:[UIImage imageNamed:@"Home_LandingPage_Middle_MenuButton@2x.png"]] autorelease];
//    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 42;
}

- (void) tableView: (UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *) indexPath
{
    [tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:NO];
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (screenBounds.size.height == 568) {
        self.tabBarController.view.frame =  CGRectMake(0, 0, 320, 568);
        
    } else {
        self.tabBarController.view.frame =  CGRectMake(0, 20, 320, 460);

        // code for 3.5-inch screen
    }
    [self.tabBarController.tabBar setHidden:NO];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"_fromLandingView"];
    //    if ([Utilities getAppDel].facOnly)
    //    {   
    //        if (indexPath.row == 0) {
    //            [[[self.tabBarController viewControllers] objectAtIndex:1] popToRootViewControllerAnimated:NO];
    //            [Utilities getAppDel].tabBarController.selectedIndex = 1 ;
    //            
    //        }
    //        if (indexPath.row == 1) {
    //            [[[self.tabBarController viewControllers] objectAtIndex:2] popToRootViewControllerAnimated:NO];
    //            [Utilities getAppDel].tabBarController.selectedIndex = 2 ;
    //        }
    //        if (indexPath.row == 2) {
    //            [[[self.tabBarController viewControllers] objectAtIndex:5] popToRootViewControllerAnimated:NO];
    //            [Utilities getAppDel].tabBarController.selectedIndex = 5 ;
    //        }
    //        if (indexPath.row == 3) {
    //            [[[self.tabBarController viewControllers] objectAtIndex:3] popToRootViewControllerAnimated:NO];
    //            [Utilities getAppDel].tabBarController.selectedIndex = 3 ;
    //        }
    //        if (indexPath.row == 4) {
    //            [[[self.tabBarController viewControllers] objectAtIndex:4] popToRootViewControllerAnimated:NO];
    //            [Utilities getAppDel].tabBarController.selectedIndex = 4 ;
    //        }
    //    }
    //    else{
    if (indexPath.row == 0) {
        [[[self.tabBarController viewControllers] objectAtIndex:1] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 1 ;
        
    }
    if (indexPath.row == 1) {
        [[[self.tabBarController viewControllers] objectAtIndex:2] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 2 ;
    }
    if (indexPath.row == 2) {
        [[[self.tabBarController viewControllers] objectAtIndex:3] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 3 ;
    }
    
    if (indexPath.row == 3) {
//        [[[self.tabBarController viewControllers] objectAtIndex:3] popToRootViewControllerAnimated:NO];
        if (screenBounds.size.height == 568) {
            self.tabBarController.view.frame =  CGRectMake(0, 20, 320, 568);
            
        } else {
            self.tabBarController.view.frame =  CGRectMake(0, 20, 320, 460);
            
            // code for 3.5-inch screen
        }

        TutorialViewController *obj = [[TutorialViewController alloc] initWithMode:YES];//[[TutorialViewController alloc]initWithNibName:@"TutorialViewController" bundle:nil];
        obj.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentModalViewController:obj animated:YES];
        isTutorialNeeded=NO;
        /*
        [self.navigationController pushViewController:obj animated:YES];
        [[[self.tabBarController viewControllers] objectAtIndex:4] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 4;
         */
    }

    /*
    if (indexPath.row == 2) {
        [[[self.tabBarController viewControllers] objectAtIndex:4] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 4 ;
    }
    if (indexPath.row == 3) {
        [[[self.tabBarController viewControllers] objectAtIndex:5] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 5 ;
    }
    if (indexPath.row == 4) {
        [[[self.tabBarController viewControllers] objectAtIndex:3] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 3 ;
    }
    if (indexPath.row == 5) {
        [[[self.tabBarController viewControllers] objectAtIndex:6] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 6 ;
    }
    if (indexPath.row == 6) {
        [[[self.tabBarController viewControllers] objectAtIndex:7]
         popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 7 ;
    }    
    if (indexPath.row == 7) {
        [[[self.tabBarController viewControllers] objectAtIndex:8] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 8 ;
    }
    if (indexPath.row == 8) {
        [[[self.tabBarController viewControllers] objectAtIndex:9]
         popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 9 ;
    }
     */

    
    //}
    
    
    [Utilities action_TransitionFromRight];
}




-(void)delay:(NSIndexPath *)indexPath{
    
    
    
}

- (void)viewDidUnload
{
    self.arr_data = nil;
    self.m_tableView = nil;
    //self.btn_terms = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    
    self.arr_data = nil;
    self.m_tableView = nil;
    //self.btn_terms = nil;
    [super dealloc];
}

@end
