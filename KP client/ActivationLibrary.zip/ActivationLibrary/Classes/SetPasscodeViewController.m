//
//  PhoneAuthorizeView.m
//  MobileCare
//
//  Created by Sean Gilligan on 10/11/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//
//  Refactor PCY ... 5/6/11
//

#import "SetPasscodeViewController.h"
#import "MobileCareAppDelegate.h"
#import "AuthorizationMan.h"
#import "Utilities.h"
#import "GANTracker.h"
#define kHiddenTextField     12
static const double kSlideViewDelay = 0.5f;

@interface SetPasscodeViewController (Private)
- (void) saveAndDismiss;
- (void) slidePasscodeView:(MCPasscodeView*)position;
@end

@implementation SetPasscodeViewController

@synthesize btn_cancelNew;
@synthesize btn_doneNew;
@synthesize btn_skipNew;
@synthesize m_desinBtnView;
@synthesize changePasscode, activateEnterPasscode, bkgImgView, lbMessage, weakPIN;
@synthesize progressView;
@synthesize m_passCodeCustomView;
@synthesize txt_passCode;
@synthesize lbl_dynamicNewReenter;
@synthesize lbl_static2;
@synthesize lbl_strength;
@synthesize lbl_text2;
@synthesize lbl_text1;
@synthesize lbl_Title;
@synthesize lbl_noMatch;
@synthesize m_rePassCodeCustomView;
@synthesize txt_rePasscode;
@synthesize lbl_errorDescription;
@synthesize m_errorPasscodeView;
@synthesize lbl_errorTitle;
@synthesize lbl_errorMsg;

- (id)initWithDelegate:(id<SetPasscodeViewControllerDelegate>)del
{
    self = [super initWithNibName:@"SetPasscodeViewController" bundle:nil];
    if (self)
    {//Passcode cannot have more than three consecutive number vala
        delegate = del; // no retain.
        self.weakPIN=NO;
        self.changePasscode=NO;
        self.activateEnterPasscode=NO;
        
    }
    return  self;
}


- (void)informDelegate
{
    [delegate setPasscodeFinished:YES];    
}

- (void)passcodeView:(MCPasscodeView*)pcv didEnterValidPassocde:(NSString*)passcode
{    
    //    if (pcv == codeView1)
    //    {
    //		enteredCode1 = passcode;
    //		[enteredCode1 retain];
    //
    //		[self performSelector:@selector(slidePasscodeView:) 
    //                   withObject:codeView2 
    //                   afterDelay:kSlideViewDelay];
    //    }
    //    else if (pcv == codeView2)
    //    {
    //        //[[AuthorizationMan get] resetPasscode];
    //        [[AuthorizationMan get] assignPC:passcode];
    //        [self performSelector:@selector(informDelegate) withObject:nil afterDelay:1];
    //    }
}

- (void)passcodeView:(MCPasscodeView*)pcv didEnterInvalidPassocde:(NSString*)passcode;
{
    //    if (pcv==codeView1) {
    //        self.weakPIN=YES;
    //    }
    //    [self performSelector:@selector(slidePasscodeView:) withObject:codeView1 afterDelay:kSlideViewDelay];
    
}

- (BOOL)passcodeView:(MCPasscodeView*)pcv isPasscodeValid:(NSString*)passcode
{
    //    if (pcv == codeView1)
    //    {
    //        if (([passcode isEqualToString:@"0000"]) ||
    //            ([passcode isEqualToString:@"1111"]) || 
    //            ([passcode isEqualToString:@"2222"]) ||
    //            ([passcode isEqualToString:@"3333"]) ||
    //            ([passcode isEqualToString:@"4444"]) ||
    //            ([passcode isEqualToString:@"5555"]) ||
    //            ([passcode isEqualToString:@"6666"]) ||
    //            ([passcode isEqualToString:@"7777"]) ||
    //            ([passcode isEqualToString:@"8888"]) ||
    //            ([passcode isEqualToString:@"9999"]) ||
    //            ([passcode isEqualToString:@"1234"]) ||
    //            ([passcode isEqualToString:@"0123"]))
    //            
    //        {
    //            return NO;
    //        }
    //        return YES;
    //    }
    //    else // assume if (pcv == codeView2)
    //    {
    //        return [enteredCode1 isEqualToString:passcode];
    //    }
    return NO;
}

- (void) slidePasscodeView:(MCPasscodeView *)position
{
    CGRect rect = scrollView.frame;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
	NSInteger posPixels = 0;
	if (position == codeView2)
	{
		posPixels = -320;
		[codeView2 makeActive];
        [codeView1 setPromptText:@"Create passcode"];
        self.lbMessage.text=@"";
        self.bkgImgView.image=[UIImage imageNamed:@"bkgd_kp_blue.png"];        
	}
	else
	{
		[codeView1 makeActive];
        if (self.weakPIN) {
            [codeView1 setPromptText:@"Passcode is weak"];
            self.weakPIN=NO;
        } else {
            [codeView1 setPromptText:@"Passcodes don't match"];
        }
        self.lbMessage.text=@"Try again";
        self.bkgImgView.image=[UIImage imageNamed:@"error_overlay.png"];          
	}
    
    [scrollView setFrame:CGRectMake(posPixels, rect.origin.y, rect.size.width, rect.size.height)];
    [UIView commitAnimations];
    
}

-(void)action_createProgress{
    
    PDColoredProgressView *m_progressView = [[PDColoredProgressView alloc] initWithProgressViewStyle: UIProgressViewStyleDefault];
    self.progressView = m_progressView;
    [m_progressView release];
    m_progressView = nil;
    CGRect frame = self.progressView.frame;
    frame.size.width = 268;
    frame.origin.x = 26;
    frame.origin.y = 110;
    self.progressView.frame = frame;
    [self.progressView setProgress:0];
    [self.progressView setTintColor: [UIColor redColor]];
    [self.m_passCodeCustomView addSubview:self.progressView];
    //[progressView release];
    
}

- (void)viewDidLoad 
{
    [super viewDidLoad];
    
    // m_passCodeCustomView.frame = CGRectMake(0, 0, 320, 220);

    
    [self action_SetPassCodeView];
    
    //security enhancement
    //add cancel only when user is trying to change the PIN, not the first time
    
    
//    UIBarButtonItem *cancelButton = [[[UIBarButtonItem alloc] initWithTitle:@"Cancel"
//                                                                      style:UIBarButtonItemStylePlain 
//                                                                     target:self 
//                                                                     action:@selector(touchCancel:)] autorelease];
//    
//    self.navigationItem.leftBarButtonItem = cancelButton;
    
    
    self.lbl_static2.frame = CGRectMake(0, 120, 320, 32);
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (screenBounds.size.height == 568) {
        // code for 4-inch screen
        self.m_desinBtnView.frame = CGRectMake(0, 240, 320, 44);
        
    } else {
        // code for 3.5-inch screen
        self.m_desinBtnView.frame = CGRectMake(0, 150, 320, 44);
        
    }
    
    [self.m_passCodeCustomView addSubview:self.m_desinBtnView];
    [self.btn_doneNew addTarget:self action:@selector(action_Done) forControlEvents:UIControlEventTouchUpInside];
    [self.btn_cancelNew addTarget:self action:@selector(touchCancel) forControlEvents:UIControlEventTouchUpInside];
    [self.btn_skipNew addTarget:self action:@selector(touchSkip) forControlEvents:UIControlEventTouchUpInside];
    self.btn_doneNew.alpha = 0;
    self.btn_skipNew.alpha = 1;
    
    lbl_errorDescription.alpha = 0;
}

- (void) viewDidDisappear:(BOOL)animated 
{
    [super viewDidDisappear:animated];
    if (self.activateEnterPasscode) {
        [[Utilities getAppDel] showMerlin];
        self.activateEnterPasscode=NO;
    }
}

-(void)action_SetPassCodeView{
    CGRect r=self.m_passCodeCustomView.frame;
    r.origin.y=r.origin.y+50;
    self.m_passCodeCustomView.frame=r;
    [self.view addSubview:self.m_passCodeCustomView];
    int_reEnter = 0;
    int_error = 0;
    [self.txt_passCode becomeFirstResponder];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange:) name:UITextFieldTextDidChangeNotification object:nil];
    // m_codeStatus.progressTintColor = [UIColor redColor];
    // UIImage *progressBarImg= [someImage stretchableImageWithLeftCapWidth:5.0 topCapHeight:0.0];
    
    if (changePasscode) {
        self.lbl_static2.hidden=YES;
    }    
    [self performSelector:@selector(action_createProgress) withObject:nil afterDelay:0.1];
    
    
}

-(BOOL)isValidCodeEntered:(NSString *)text{
    
    BOOL isVAlid = FALSE;
    
    NSMutableArray *characters = [[NSMutableArray alloc] initWithCapacity:[text length]];
    for (int i=0; i < [text length]; i++) {
        NSString *ichar  = [NSString stringWithFormat:@"%c", [text characterAtIndex:i]];
        [characters addObject:ichar];
    }
    NSString *str;
    if ([characters count]  == 0) {
        isVAlid = FALSE;
    }
    else{
        
        str = [characters objectAtIndex:0];
        
        for (int i = 1; i< [characters count] ; i++) {
            
            if ([str isEqualToString:[characters objectAtIndex:i]]) {
                
                isVAlid = FALSE;
            }
            else{
                
                isVAlid = TRUE;
                break;
            }
            
        }
    }
    if (isVAlid) {
        for (int k = 1; k < [characters count]; k ++) {
            
            int intVal = [str intValue]+1;
            str = [NSString stringWithFormat:@"%d",intVal];
            if (intVal == [[characters objectAtIndex:k] intValue]) {
                isVAlid = FALSE;
                
            }
            else{
                isVAlid = TRUE;
                break;
            }
        }
        
        [characters release];
        if (!isVAlid) {
            return NO;
        }
        else{
            return YES;
        }
        
        
    } 
    else{
        [characters release];
        return NO;
    }
    
}


-(void)action_Done{
    
    if (int_reEnter == 0) {
        
        if ([self isValidCodeEntered:str_enteredCode]) {
            
            self.navigationItem.rightBarButtonItem = nil;
            
            [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextFieldTextDidChangeNotification object:nil];
            
            int_reEnter = 1;
            [m_passCodeCustomView removeFromSuperview];
            [self.m_errorPasscodeView removeFromSuperview];
            
            CGRect r=self.m_rePassCodeCustomView.frame;
            r.origin.y=r.origin.y+30;
            self.m_rePassCodeCustomView.frame=r;
            
            [self.view addSubview:m_rePassCodeCustomView];
            
            self.lbl_text2.frame = CGRectMake(0, 133, 320, 32);
            CGRect screenBounds = [[UIScreen mainScreen] bounds];
            
            if (screenBounds.size.height == 568) {
                // code for 4-inch screen
                self.m_desinBtnView.frame = CGRectMake(0, 260, 320, 44);
                
            } else {
                // code for 3.5-inch screen
                self.m_desinBtnView.frame = CGRectMake(0, 170, 320, 44);
                
            }
            [self.m_rePassCodeCustomView addSubview:self.m_desinBtnView];
            [self.btn_doneNew addTarget:self action:@selector(action_Done) forControlEvents:UIControlEventTouchUpInside];
            [self.btn_cancelNew addTarget:self action:@selector(touchCancel) forControlEvents:UIControlEventTouchUpInside];
            self.btn_doneNew.alpha = 0;
            self.btn_skipNew.alpha = 1;
            
            
            [txt_rePasscode becomeFirstResponder];
            lbl_noMatch.text = @"";
            lbl_text1.alpha = 1;
            lbl_text2.alpha = 1;
            if (changePasscode) {
                self.lbl_text2.hidden=YES;
            }            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChangeRePassCode:) name:UITextFieldTextDidChangeNotification object:nil];
        }
        
        else{
            self.lbl_dynamicNewReenter.alpha = 0;
            self.lbl_errorDescription.alpha = 1;
            int_reEnter = 0;
            txt_passCode.text = @"";
            str_enteredCode = @"";
            lbl_strength.text = @"Passcode strength meter";
            self.lbl_errorTitle.text=@"Weak Passcode";
            self.lbl_errorMsg.text=@"Try again";
            self.m_errorPasscodeView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
            [self.view addSubview:self.m_errorPasscodeView];
            //m_passCodeCustomView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
            self.navigationItem.rightBarButtonItem = nil;
        }
        
    }
    else if (int_reEnter == 1) {
        
        if (int_error == 2) {
            str_reEnteredCode = txt_rePasscode.text;
            if ([str_enteredCode isEqualToString:str_reEnteredCode]) {
                int_reEnter = 0;
                // lbl_noMatch.text = @"";
               // [Utilities getAppDel].isSynchingCompleted = FALSE;
                [[AuthorizationMan get] assignPC:str_enteredCode];
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"_isEnteredPasscode"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                [self performSelector:@selector(informDelegate) withObject:nil afterDelay:1];
            }
            else{
                int_error = 0;
            }
        }
        
        if (int_error == 1) {
            //                [m_rePassCodeCustomView removeFromSuperview];
            //                 [self action_SetPassCodeView];
            
            m_rePassCodeCustomView.backgroundColor = [UIColor clearColor];
            str_enteredCode = [txt_rePasscode.text retain];
            
            if ([self isValidCodeEntered:str_enteredCode]){
                
                [self.m_errorPasscodeView removeFromSuperview];
                lbl_text1.alpha = 1;
                lbl_text2.alpha = 1;
                lbl_Title.alpha = 1;
                lbl_noMatch.text = @"";
                txt_rePasscode.text = @"";
                lbl_Title.text = @"Re-enter passcode";
                self.txt_rePasscode.frame = CGRectMake(26, 81, 268, 31);
                int_error = 2;
            }
            else{
                str_enteredCode = @"";
                str_reEnteredCode = @"";
                lbl_text1.alpha = 0;
                lbl_text2.alpha = 0;

                self.lbl_errorTitle.text=@"Weak Passcode";
                self.lbl_errorMsg.text=@"Try again";
                self.m_errorPasscodeView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
                [self.view addSubview:self.m_errorPasscodeView];
                                
                //lbl_Title.text = @"Weak Passcode";
                //m_rePassCodeCustomView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
                //lbl_noMatch.text = @"Try again";
                txt_rePasscode.text = @"";
                txt_passCode.text = @"";
                int_error = 1;
                
            }
            
        }
        if(int_error == 0){
            if ([str_enteredCode isEqualToString:str_reEnteredCode]) {
                int_reEnter = 0;
                // lbl_noMatch.text = @"";
                //[Utilities getAppDel].isSynchingCompleted = FALSE;
                [self.m_errorPasscodeView removeFromSuperview];
                [[AuthorizationMan get] assignPC:str_enteredCode];
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"_isEnteredPasscode"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                [self performSelector:@selector(informDelegate) withObject:nil afterDelay:1];
            }
            else{
                str_enteredCode = @"";
                str_reEnteredCode = @"";
                
                lbl_text1.alpha = 0;
                lbl_text2.alpha = 0;    
                lbl_Title.alpha = 0;
                
                self.m_errorPasscodeView.frame = CGRectMake(0, 42, 320, 65);
                self.lbl_errorTitle.text=@"Passcodes don't match";
                self.lbl_errorMsg.text=@"Try again";

                self.txt_rePasscode.frame = CGRectMake(26, 109, 268, 31);
                self.m_errorPasscodeView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
                [self.view addSubview:self.m_errorPasscodeView];                
                
                //lbl_Title.text = @"Passcodes don't match";
                //m_rePassCodeCustomView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"error_overlay.png"]];
                //lbl_noMatch.text = @"Try again";
                txt_rePasscode.text = @"";
                txt_passCode.text = @"";
                int_error = 1;
            }
        }
    }
    
}
-(void)textDidChangeRePassCode:(NSNotification *)notification{
    
    if ([self.txt_rePasscode.text length] < 4 ) {
       // self.navigationItem.rightBarButtonItem = nil;
        self.btn_doneNew.alpha = 0;
        self.btn_skipNew.alpha = 1;
        
//        for (UIView *view in self.m_rePassCodeCustomView.subviews) {
//            if ([view isEqual:self.m_desinBtnView]) {
//                [self.m_desinBtnView removeFromSuperview];
//            }
//        }
//
//        for (UILabel *lbl in self.m_rePassCodeCustomView.subviews) {
//            if ([lbl isEqual:self.lbl_static2]) {
//                [self.lbl_static2 removeFromSuperview];
//            }
//            
//        }
//        self.lbl_static2.frame = CGRectMake(0, 169, 320, 32);
//        [self.m_rePassCodeCustomView addSubview:self.lbl_static2];
        
    }
    
    if ([self.txt_rePasscode.text length] == 4) {
        
        self.btn_doneNew.alpha = 1;
        self.btn_skipNew.alpha = 0;
//        UIBarButtonItem *doneButton = [[[UIBarButtonItem alloc] initWithTitle:@"Done" 
//                                                                        style:UIBarButtonItemStylePlain 
//                                                                       target:self 
//                                                                       action:@selector(action_Done)] autorelease];
//        
//        self.navigationItem.rightBarButtonItem = doneButton;
        
        
//        for (UILabel *lbl in self.m_rePassCodeCustomView.subviews) {
//            if ([lbl isEqual:self.lbl_static2]) {
//                [self.lbl_static2 removeFromSuperview];
//            }
//            
//        }
//        self.lbl_static2.frame = CGRectMake(0, 133, 320, 32);
//        [self.m_rePassCodeCustomView addSubview:self.lbl_static2];
//        
//        for (UIView *view in self.m_rePassCodeCustomView.subviews) {
//            if ([view isEqual:self.m_desinBtnView]) {
//                [self.m_desinBtnView removeFromSuperview];
//            }
//        }
//        self.m_desinBtnView.frame = CGRectMake(0, 157, 320, 44);
//        [self.m_rePassCodeCustomView addSubview:self.m_desinBtnView];
//        [self.btn_doneNew addTarget:self action:@selector(action_Done) forControlEvents:UIControlEventTouchUpInside];
        
        
    }
    
    
    
    if ([self.txt_rePasscode.text length] >12) {
        self.txt_rePasscode.text = [self.txt_rePasscode.text substringToIndex:12];
    }
    else{
        
        str_reEnteredCode = [self.txt_rePasscode.text retain];
    }
}

-(void)textDidChange:(NSNotification *)notification{
    
    if ([self.txt_passCode.text length] < 4 ) {
        
        self.btn_doneNew.alpha = 0;
        self.btn_skipNew.alpha = 1;
        
        //self.navigationItem.rightBarButtonItem = nil;
        
//        for (UIView *view in self.m_passCodeCustomView.subviews) {
//            if ([view isEqual:self.m_desinBtnView]) {
//                [self.m_desinBtnView removeFromSuperview];
//            }
//        }
//        
//        for (UILabel *lbl in self.view.subviews) {
//            if ([lbl isEqual:self.lbl_static2]) {
//                [self.lbl_static2 removeFromSuperview];
//            }
//            
//        }
//        self.lbl_static2.frame = CGRectMake(0, 169, 320, 32);
//        [self.m_passCodeCustomView addSubview:self.lbl_static2];
        
        
    }
    
    if ([self.txt_passCode.text length] == 4) {
        self.btn_doneNew.alpha = 1;
        self.btn_skipNew.alpha = 0;
//        self.m_desinBtnView.frame = CGRectMake(0, 157, 320, 44);
//        for (UILabel *lbl in self.view.subviews) {
//            if ([lbl isEqual:self.lbl_static2]) {
//                [self.lbl_static2 removeFromSuperview];
//            }
//            
//        }
//        self.lbl_static2.frame = CGRectMake(0, 133, 320, 32);
//        [self.m_passCodeCustomView addSubview:self.lbl_static2];
//        
//        
//        for (UIView *view in self.m_passCodeCustomView.subviews) {
//            if ([view isEqual:self.m_desinBtnView]) {
//                [self.m_desinBtnView removeFromSuperview];
//            }
//        }
//        [self.m_passCodeCustomView addSubview:self.m_desinBtnView];
//        [self.btn_doneNew addTarget:self action:@selector(action_Done) forControlEvents:UIControlEventTouchUpInside];
        
//        UIBarButtonItem *doneButton = [[[UIBarButtonItem alloc] initWithTitle:@"Done" 
//                                                                        style:UIBarButtonItemStylePlain 
//                                                                       target:self 
//                                                                       action:@selector(action_Done)] autorelease];
//        
//        self.navigationItem.rightBarButtonItem = doneButton;
        
    }
    
    if ([self.txt_passCode.text length] >12) {
        self.txt_passCode.text = [self.txt_passCode.text substringToIndex:12];
    }
    else{
        
        str_enteredCode = [self.txt_passCode.text retain];
    }
    
    [self validatestrengthMeter:str_enteredCode];
    
}

-(void)validatestrengthMeter:(NSString *)codeVal{
    
    
    if ([self isValidCodeEntered:codeVal]) {
        if ([str_enteredCode length] < 5 ) {
            self.lbl_strength.text = @"Weak passcode";
            
            [self.progressView setTintColor: [UIColor redColor]];
        }
        else if ([str_enteredCode length] >= 5 && [str_enteredCode length] < 9) {
            
            self.lbl_strength.text = @"Medium passcode";
            [self.progressView setTintColor: [UIColor yellowColor]];
        }
        else if ([str_enteredCode length] > 8 ){
            self.lbl_strength.text = @"Strong passcode";
            [self.progressView setTintColor: [UIColor greenColor]];
        }
        else{
            
        }
        
        // For progess bar (status code strength)
        for (int i = 0; i< 13; i++) {
            if ([str_enteredCode length] == i) {
                
                [self.progressView setProgress:i*0.083];
            }
        }
        
    }
    else{
        self.lbl_strength.text = @"Weak passcode";
        
        [self.progressView setTintColor: [UIColor redColor]];
        [self.progressView setProgress:0.083];
    }
    if ([codeVal length] == 0)
    {
        [self.progressView setProgress:0.00];
        self.lbl_strength.text = @"Passcode strength meter";
    }
    
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    
    if (textField == self.txt_passCode || textField == self.txt_rePasscode) {
        
        self.navigationItem.rightBarButtonItem = nil;
        return YES;
    }
    else
        return NO;
    
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    
    return YES;
}



- (IBAction)startOver:(id)sender 
{
    //	[self performSelector:@selector(slidePasscodeView:) withObject:codeView1 afterDelay:kSlideViewDelay];	
    //    [codeView1 setPromptText:@"Enter a PIN"];
}

- (void)touchCancel 
{
    //[[AuthorizationMan get] resetPasscode];
	//[delegate setPasscodeFinished:YES];
    
    // cancel button works differently for change PIN and the initial screens
    if (changePasscode) {
        [delegate setPasscodeFinished:YES]; 
    } else {
        [delegate setPasscodeFinished:NO]; 
    }
    
    //	[self informDelegate];
}

- (void)touchSkip 
{
    [[AuthorizationMan get] assignPC:@"0"];
    [delegate setPasscodeFinished:YES]; 
}

- (IBAction)touchContinue:(id)sender 
{
}

- (void)viewDidUnload 
{
    self.m_passCodeCustomView = nil;
    self.txt_passCode = nil;
    self.lbl_dynamicNewReenter = nil;
    self.lbl_strength = nil;
    self.lbl_static2 = nil;
    self.progressView = nil;
    self.m_rePassCodeCustomView = nil;
    self.txt_rePasscode = nil;
    self.lbl_noMatch = nil;
    self.lbl_Title = nil;
    self.lbl_text1 = nil;
    self.lbl_text2 = nil;
    self.lbMessage=nil;
    self.bkgImgView=nil;
    
    self.lbl_errorDescription = nil;
    self.m_desinBtnView = nil;
    self.btn_doneNew = nil;
    self.btn_cancelNew = nil;
    self.btn_skipNew = nil;
    self.lbl_errorTitle=nil;
    self.lbl_errorMsg=nil;
    self.m_errorPasscodeView=nil;
    [super viewDidUnload];
}

- (void)dealloc 
{
    self.lbMessage=nil;
    self.bkgImgView=nil;
    self.m_passCodeCustomView = nil;  
    self.txt_passCode = nil;
    self.lbl_dynamicNewReenter = nil; 
    self.lbl_strength = nil;
    self.lbl_static2 = nil;
    self.progressView = nil;   
    self.m_rePassCodeCustomView = nil;
    self.txt_rePasscode  = nil;
    self.lbl_noMatch  = nil;
    self.lbl_Title = nil ;
    self.lbl_text1  = nil;
    self.lbl_text2  = nil;
    
    self.lbl_errorDescription = nil;
    self.m_desinBtnView = nil;
    self.btn_doneNew = nil;
    self.btn_cancelNew = nil;
    self.btn_skipNew = nil;
    self.lbl_errorTitle=nil;
    self.lbl_errorMsg=nil;
    self.m_errorPasscodeView=nil;    
    [super dealloc];
}

@end
