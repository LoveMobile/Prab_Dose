//
//  WSCheckDynamic.m
//  MobileCare
//
//  Created by Paul on 5/26/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "WSCheckDynamic.h"

@implementation WSCheckDynamic

@synthesize method = m_szMethod;
@synthesize params = m_dParams;

- (id)initWithMethod:(NSString*)method andParams:(NSDictionary*)dParams
{
    self = [super init];
    if (self)
    {
        self.method = method;
        self.params = dParams;
    }
    return self;
}

- (void)startCheck
{
    NSAssert(self.delegate, @"delegate should be set");
    
    self.m_fetcher = [[[FetcherJson alloc] initWithMethod:m_szMethod andParams:m_dParams] autorelease];
    self.m_fetcher.delegate = self;
    [self.m_fetcher fetch];
}

- (void)dealloc
{
    self.method = nil;
    self.params = nil;
    [super dealloc];
}


@end
