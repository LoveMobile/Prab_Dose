//
//  Utilities.h
//  MobileCare
//
//  Created by Paul on 4/21/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MobileCareAppDelegate.h"
#import <QuartzCore/QuartzCore.h>
//#import "NSData+Base64.h"

@interface Utilities : NSObject 
{
}

//+ (NSString*)applicationDocumentsDirectory;
+ (NSString*)getDocsPath;
+ (NSString*)getCachesPath;
+ (MobileCareAppDelegate*)getAppDel;
+ (void)showVc:(UIViewController*)vcModal AsModalTo:(UIViewController*)vcBase;
+ (NSString*)getTokenAsString:(NSData*)deviceToken;
+ (NSString*) getTestMrn;
+ (int)secondOfTheDay:(NSDate*)time;
//+ (NSString*)formatDisplayName:(Member*) member;
+ (NSString*)getStringFromJson:(id)jsonField;
+ (NSNumber*)getNumberFromJson:(id)jsonField;
+ (BOOL)isVersionSwipeable;
+ (NSString*)getEmailWarningMessage;
+ (NSDictionary*)getDeviceParamsDict;
+ (BOOL)validateUrl:(NSString*)url;
+ (NSString *)getPureURL:(NSURL*)url;
+(NSString *) formatIdentificationNumber:(NSString *)string;
+(BOOL) isValidPhoneNumber:(NSString *)string1;
+(void)action_TransitionFromRight;
+(void)action_TransitionFromLeft;

+ (NSString *)base64Encode:(NSString *)plainText;
+ (NSString *)base64Decode:(NSString *)base64String;

+(void)saveCookieName:(NSString *)CookieName Value:(NSString *)CookieValue  Domain:(NSString *)CookieDomain  Path:(NSString *)CookiePath  andExpires:(NSDate *)CookieExpires;
+(NSString *)encodeURLString:(NSString *) sourceString;

+(void)postGATrackEventName:(NSString *)name withActionName:(NSString *)action andlabel:(NSString *)label;
+(void)postGATrackPageName:(NSString *)pageName;
+(BOOL)isiPhone5;
+(NSString *)hashed_string:(NSString *)input;
+(NSData *)sha1:(NSData *)data;
+(void)signOff;
+ (NSDictionary *) readTutorialJsonFile;
+(void) doesAlertViewExist;
+(BOOL) AppBecomeActiveActions;
+(void) AppLaunchActions;
+(BOOL)isIOS7AndAbove;
+ (NSString *)hashString:(NSString *)input;
+ (NSString *)deviceIdentifier;
@end
