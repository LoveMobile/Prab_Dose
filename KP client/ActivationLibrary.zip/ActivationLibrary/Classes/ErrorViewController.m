//
//  ErrorViewController.m
//  ActivationLibrary
//
//

#import "ErrorViewController.h"
#import "Utilities.h"

@interface ErrorViewController ()

@end

@implementation ErrorViewController

@synthesize lbl_error,lbl_error_title, errorMsg, errorTitle;

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil withTitle:(NSString*)title andMessage:(NSString *)errMsg
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.errorMsg=errMsg;
        self.errorTitle=title;
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
	UITouch *touch1 = [touches anyObject];
    
    if (touch1.view == self.lbl_error)
	{
        NSURL *url = [NSURL URLWithString:@"http://www.kp.org"];
        [[UIApplication sharedApplication] openURL:url];
        
    }
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIImage* image3 = [UIImage imageNamed:@"icon_bkgd_back-arow.png"];
    CGRect frameimg = CGRectMake(0, 0, 40, 30);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(pop)
         forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *m_barSomeButton = [[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem = m_barSomeButton;
    
    self.lbl_error.text = self.errorMsg;
    self.lbl_error_title.text = self.errorTitle;
    
    
}

- (void)pop
{
    [[Utilities getAppDel] hideAi];
    
    [self dismissModalViewControllerAnimated:NO];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
