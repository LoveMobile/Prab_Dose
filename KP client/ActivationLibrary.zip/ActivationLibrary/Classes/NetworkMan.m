//
//  NetworkMan.m
//  MobileCare
//
//  Created by Paul on 4/20/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "NetworkMan.h"
#import <Foundation/Foundation.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import "MobileCareAppDelegate.h"
#import "Utilities.h"
#import "AuthorizationMan.h"
#import "WebServiceMan.h"
#import "Constants.h"
#import "UIDevice+IdentifierAddition.h"

@implementation NetworkMan

// TODO : determine if needs to be thread-safe
+ (UInt32)getNetworkType
{
    UInt32 ret = 0;
    
    SCNetworkReachabilityRef reachability = SCNetworkReachabilityCreateWithName(NULL, "www.apple.com");
    SCNetworkReachabilityFlags flags;
    BOOL success = SCNetworkReachabilityGetFlags(reachability, &flags);
    
    if (success && (flags & kSCNetworkFlagsReachable) && !(flags & kSCNetworkFlagsConnectionRequired) && !(flags & kSCNetworkReachabilityFlagsIsWWAN))
    {
        // Google Analyser
        [Utilities postGATrackEventName:@"network type is WIFI" withActionName:@"tracking logged in Users via WIFI" andlabel:@""];
        
        LOG("network check ... network type is WIFI");
        ret = 2;	// reachable via WIFI
    }
    else if (success && (flags & kSCNetworkFlagsReachable) && !(flags & kSCNetworkFlagsConnectionRequired) && (flags & kSCNetworkReachabilityFlagsIsWWAN))
    {
        // Google Analyser
        [Utilities postGATrackEventName:@"network type is EDGE / 3G" withActionName:@"tracking logged in Users via EDGE / 3G" andlabel:@""];
        LOG("network check ... network type is EDGE / 3G");
        ret = 1;	 // reachable via EDGE / 3G
    }
    else
    {
        // Google Analyser
        [Utilities postGATrackEventName:@"no network available" withActionName:@"tracking user having No Network" andlabel:@""];
        LOG("network check ... no network available");
        ret = 0;
    }
    
    CFRelease(reachability);
    
    return ret;
}

+ (NSURLConnection*)processURL:(NSURL*)url postedKeys:(NSString*)szKeys andDelegate:(id)del
{
	NSMutableURLRequest* request = [[[NSMutableURLRequest alloc] init] autorelease];
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
	[request setTimeoutInterval:NETWORK_INIT_CONNECT_TIMEOUT];
	[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	[request setValue:[NSString stringWithFormat:@"%i", [szKeys length]] forHTTPHeaderField:@"Content-Length"];
    
    // adding ssosession to headers
    if (ssoSessionIdStr!=nil) {
        LOG("Sending ssosession id as header value: %@", ssoSessionIdStr);
        [request setValue:ssoSessionIdStr forHTTPHeaderField:@"ssoSessionId"];
    }

	NSData* postData = [szKeys dataUsingEncoding:NSUTF8StringEncoding];
	[request setHTTPBody:postData];
	
	LOG("request:%@?%@", request.URL, szKeys);
    
	return [[[NSURLConnection alloc] initWithRequest:request delegate:del] autorelease];
}

+ (NSURLConnection*)processURL:(NSURL*)url andDelegate:(id)del
{
	return [self processURL:url postedKeys:@"" andDelegate:del];
}

+ (NSURLConnection*)getResultFromUrl:(NSURL*)url withMethod:(NSString *)method withParams:(NSDictionary*)parms andDelegate:(id)del
{
    NSString* szParams = @"";
    
    WebServiceMan* wsm= [WebServiceMan get];
    
    NSMutableDictionary* ma = [NSMutableDictionary dictionary];
    
    // Abhinav Sehgal - Version number added to webservice
    [ma setValue:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"] forKey:@"appVersion"];
    [ma setValue:wsm.appId forKey:@"appId"];
    LOG("The App ID is: %@", wsm.appId);
    // Not currently sending the udid with every network call.
    // [ma setValue:[[UIDevice currentDevice] uniqueIdentifier] forKey:@"udid"];
    [ma setValue:[[UIDevice currentDevice] model] forKey:@"useragentType"];
    [ma setValue:@"iOS" forKey:@"os"];
    [ma setValue:[[UIDevice currentDevice] systemVersion] forKey:@"osVersion"];
    //[ma setValue:[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier] forKey:@"deviceId"];
    if ([Utilities isIOS7AndAbove]) {
        NSString *myDevice = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        
        LOG("iOS7 and Above Device ID: %@", myDevice);
        [ma setValue:myDevice forKey:@"deviceId"];
        
    }
    else
    {
        UIDevice *myDevice = [UIDevice currentDevice];
        
        LOG("Device ID: %@", [myDevice uniqueGlobalDeviceIdentifier]);
        [ma setValue:[myDevice uniqueGlobalDeviceIdentifier] forKey:@"deviceId"];
        
    }
    
    if (parms)
    {
        [ma addEntriesFromDictionary:parms];
    }
    
    NSMutableArray *parts = [NSMutableArray array];
    for (id key in ma)
    {
        NSString *part = [NSString stringWithFormat: @"%@=%@", key, [ma objectForKey:key]];
        [parts addObject: part];
    }
    NSString *extraParmsString = [parts componentsJoinedByString: @"&"];
    
    szParams = [NSString stringWithFormat:@"%@&%@", szParams, extraParmsString];
    if ((![method isEqualToString:@"register"]) && (![method isEqualToString:@"activateMemberDevice"]) && (![method isEqualToString:@"performSignon"])) {
        szParams = [szParams stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }
    
	return [self processURL:url postedKeys:szParams andDelegate:del];
}


+ (NSURL*)makeURLWithMethod:(NSString*)method
{
    WebServiceMan* wsm = [WebServiceMan get];

    NSString* urlString = [NSString stringWithFormat:@"%@/%@", 
                           wsm.wsBaseUrl, 
                           method];
        
    urlString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    return [NSURL URLWithString:urlString];
}

@end
