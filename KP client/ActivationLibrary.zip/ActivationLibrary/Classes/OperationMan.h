//
//  OperationMan.h
//  Iface1
//
//  Created by Paul on 4/20/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OperationMan : NSObject 
{
	NSOperationQueue* queue;
}

@property (nonatomic, retain) NSOperationQueue* queue;

+ (OperationMan*)get;
- (NSOperation*)executeOnTarget:(id)target selector:(SEL)pSelector param:(id)pParam;
- (NSOperation*)invoke:(NSInvocation*)inv;

@end
