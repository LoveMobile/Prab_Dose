//
//  Fetcher.m
//  MobileCare
//
//  Created by Paul on 4/20/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "Fetcher.h"
#import "JSON.h"
#import "OperationMan.h"
#import "MessageMan.h"
#import "Constants.h"

@implementation Fetcher

@synthesize m_msdData;
@synthesize m_nState;
@synthesize m_timer;
@synthesize m_nsUrlConnection;
@synthesize delegate = m_delegate;


- (id)initWithMethod:(NSString*)szMethod andParams:(NSDictionary*)dParams
{
	if ((self = [super init]))
	{
		self.m_msdData = [NSMutableData dataWithLength:0];
		self.m_timer = nil;
		m_nState = FS_IDLE;
        self.delegate = nil; // no retain.
	}
	
	return self;
}

- (void)dealloc
{
    self.m_nsUrlConnection = nil;
    [self.m_timer invalidate];
    self.m_timer = nil;
	self.m_msdData = nil;
    self.delegate = nil; // no release.
    
	[super dealloc];
}

#pragma mark -
#pragma mark Core

- (void)fetch
{
	[self clear];
    
	self.m_timer = [NSTimer scheduledTimerWithTimeInterval:TIME_OUT_SEC 
                                                    target:self 
                                                  selector:@selector(timeout) 
                                                  userInfo:nil 
                                                   repeats:NO];
 	self.m_nState = FS_FETCHING;
}

// Called internally whenever the delegate is informed
// This asssumes that the fetcher only makes one and only one call to the delegate
// This will not change the state of the fetcher. 
- (void)cleanup
{
	self.m_msdData = [NSMutableData dataWithLength:0];
	
    [m_timer invalidate];
	self.m_timer = nil;
    
    if (self.m_nsUrlConnection)
    {
        // This will cause a release of the Url's delegate (which it retains rather than using a weak reference).
        [self.m_nsUrlConnection cancel];
        self.m_nsUrlConnection = nil;
    }
    
    self.delegate = nil;
}

- (void)timeout
{
    LOG("timeout of %d for url:%@", TIME_OUT_SEC, m_nsUrlConnection);

	[m_timer invalidate];
	self.m_timer = nil;
	[m_nsUrlConnection cancel];
    
    if (self.delegate)
    {
        [self.delegate fetcher:self didFailWithError:FF_TIMEOUT];    
	}
    
    [self cleanup];
    
    self.m_nState = FS_FAILED;
}

- (void)cancel
{
	[m_timer invalidate];
	self.m_timer = nil;
	[m_nsUrlConnection cancel];

    [self.delegate fetcher:self didFailWithError:FF_CANCELED];    
	self.m_nState = FS_FAILED;

    [self cleanup];
}

// Internal call used by ctor.
- (void)clear
{
	self.m_msdData = [NSMutableData dataWithLength:0];
	[m_timer invalidate];
	self.m_timer = nil;
	self.m_nsUrlConnection = nil;
    
	// zz Don't change the property (self.) in case an observer is already listening.
	m_nState = FS_IDLE;
}

- (void) stop
{
    self.delegate=nil;
    [m_nsUrlConnection cancel];
    self.m_nsUrlConnection=nil;
    [self.m_timer invalidate];
    self.m_timer = nil;
	self.m_msdData = nil;    
}

- (void)extract
{
    NSAssert(NO, @"shouldn't call base class extract. Subclass not implemented.");
}

#pragma mark -
#pragma mark URL Connection Delegate

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    LOG("url:%@ error:%@", connection, [error localizedDescription]);

    [self.delegate fetcher:self didFailWithError:FF_FAILED]; 
	self.m_nState = FS_FAILED;

    [self cleanup];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)dataIn
{
    // Reset the timer.
	[m_timer setFireDate:[NSDate dateWithTimeIntervalSinceNow:TIME_OUT_SEC]];
	[m_msdData appendData:dataIn];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	[m_timer invalidate];
	self.m_timer = nil;
	self.m_nsUrlConnection = nil;
    
	[[OperationMan get] executeOnTarget:self selector:@selector(extract) param:nil];    
}

#pragma mark -
#pragma mark NSURLConnection Delegate Methods
- (void)connection:(NSURLConnection*)connection didReceiveResponse:(NSURLResponse*)response {
    NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
    int responseStatusCode = [httpResponse statusCode];
    
    LOG("Fetcher : HTTP status code is %i", responseStatusCode);
    
    if (responseStatusCode != 200) {
        [self.delegate fetcher:self didFailWithError:FF_FAILED]; 
        self.m_nState = FS_FAILED;
        
        [self cleanup];

    }
}


@end
