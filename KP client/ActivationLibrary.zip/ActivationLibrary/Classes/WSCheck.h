//
//  WSCheck.h
//  MobileCare
//
//  Created by Paul on 5/17/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FetcherJson.h"

typedef enum
{
    WSC_GOOD,
    WSC_DEAUTH,
    WSC_NOT_KP,
    WSC_FORCED_UP,
    WSC_AUTHENT_FAIL,
    WSC_NOT_NCAL,
    WSC_AUTHENT_LOCKOUT,
    WSC_AUTHORIZE_FAIL,
    WSC_USERID_CHANGED,
    WSC_NET_FAIL,
    WSC_WS_FAIL,
    // Abhinav Sehgal - System Maintenance Check
    WSC_SYS_MNTNC, // generic handler for ws errors.
} SERVER_STATUS_RESULT;

// TODO : improve the interface of this delegate
@protocol WSCheckDelegate <NSObject>
- (void)postResult:(SERVER_STATUS_RESULT)nState sender:(id)sender;
@end

@interface WSCheck : NSObject <FetcherDelegate> 
{
    SERVER_STATUS_RESULT m_nResult;
    FetcherJson* m_fetcher;
    id<WSCheckDelegate> delegate;
}

@property (nonatomic, retain) FetcherJson* m_fetcher;
@property (assign) id<WSCheckDelegate> delegate;

+ (SERVER_STATUS_RESULT)getStatusResultFromCode:(int)code;
- (void)startCheck;

@end
