//
//  AuthorizationMan.m
//  MobileCare
//
//  Created by Paul on 5/3/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "AuthorizationMan.h"
#import "WebServiceMan.h"
#import "NetworkMan.h"
#import "Utilities.h"
#import "MobileCareAppDelegate.h"
//#import "CoreDataMan.h"
#import "JSON.h"
//#import "ContainerMan.h"
#import "TryMan.h"
#import "Constants.h"
#import "Utilities.h"
#import "NSData+AES256.h"

static AuthorizationMan* m_am = nil;

@implementation AuthorizationMan

//@synthesize mrn;
//@synthesize kpToken;
//@synthesize passCode;
@synthesize userName;
@synthesize userId;
@synthesize loginName;

+ (AuthorizationMan*)get
{
    if (nil == m_am)
    {
        m_am = [[AuthorizationMan alloc] init];
    }
    return m_am;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        [self getValuesFromKC];
    }
    return self;
}

- (void)getValuesFromKC
{
    NSError *error=nil;
    
    if (![self isPreviousUserExisted]) {
        [self reset];
        return;
    }
    
    /*
    self.passCode = [SFHFKeychainUtils getPasswordForUsername:PASSCODE_KC_KEY andServiceName:APP_KC_KEY error:&error];
    self.passCode = [transformer decryptString:self.passCode];
    
    LOG("decryped values from keychain (passcode): %@", self.passCode);
     */
    
    self.userName = [SFHFKeychainUtils getPasswordForUsername:USERNAME_KC_KEY andServiceName:APP_KC_KEY error:&error];
    self.userName = [self decrypt:self.userName];
    LOG("decryped values from keychain (username): %@ ",self.userName);
    
    self.password = [SFHFKeychainUtils getPasswordForUsername:PASSWORD_KC_KEY andServiceName:APP_KC_KEY error:&error];
    self.password = [self decrypt:self.password];
    LOG("decryped values from keychain (password): %@ ",self.password);
    
    self.userId = [SFHFKeychainUtils getPasswordForUsername:USERID_KC_KEY andServiceName:APP_KC_KEY error:&error];
    self.userId = [self decrypt:self.userId];
    LOG("decryped values from keychain (userId): %@ ",self.userId);

}

- (void)saveValuesToKC
{
    NSError *error=nil;
    if ([self.userName length]== 0)
    {
        [self reset];
    }
    
    LOG("values before encryption (username): %@", self.userName);
    
    /*
    NSString *encryptedPasscode=[transformer encryptString:self.passCode];
    LOG("values after encryption (passcode): %@", encryptedPasscode);
    
    // Use a separete keychain item for passcode. (why?)
    if (nil!= encryptedPasscode) {
        [SFHFKeychainUtils storeUsername:PASSCODE_KC_KEY andPassword:encryptedPasscode forServiceName:APP_KC_KEY updateExisting:YES error:&error];
    }	
     */
    
    NSString *encryptedUserName=[self encrypt:self.userName];
    LOG("values after encryption (username): %@ ", encryptedUserName);
    
    if (nil!=encryptedUserName) {
        [SFHFKeychainUtils deleteItemForUsername:USERNAME_KC_KEY andServiceName:APP_KC_KEY error:&error];
        [SFHFKeychainUtils storeUsername:USERNAME_KC_KEY andPassword:encryptedUserName forServiceName:APP_KC_KEY updateExisting:YES error:&error];
    }

    LOG("values before hashing (password): %@", self.password);
    NSString* hashedPassword=[Utilities hashString:self.password];
    LOG("values after hashing (password): %@", hashedPassword);
    
    // only keep the hashedPassword in memory!
    self.password=hashedPassword;
    
    NSString *encryptedPassword=[self encrypt:self.password];
    LOG("values after encryption (password): %@", encryptedPassword);
    
    if (nil!=encryptedPassword) {
        [SFHFKeychainUtils deleteItemForUsername:PASSWORD_KC_KEY andServiceName:APP_KC_KEY error:&error];
        [SFHFKeychainUtils storeUsername:PASSWORD_KC_KEY andPassword:encryptedPassword forServiceName:APP_KC_KEY updateExisting:YES error:&error];
    }
    
    LOG("values before encryption (userId): %@", self.userId);
    NSString *encryptedUserId=[self encrypt:self.userId];
    LOG("values after encryption (userId): %@ ", encryptedUserId);

    if (nil!=encryptedUserId) {
        [SFHFKeychainUtils deleteItemForUsername:USERID_KC_KEY andServiceName:APP_KC_KEY error:&error];
        [SFHFKeychainUtils storeUsername:USERID_KC_KEY andPassword:encryptedUserId forServiceName:APP_KC_KEY updateExisting:YES error:&error];
    }
}

- (BOOL) isPreviousUserExisted {
    BOOL result=NO;
    NSString *preUserFlag=[[NSUserDefaults standardUserDefaults] stringForKey:UD_PREVIOUS_USER_CHECK];
    if ((preUserFlag!=nil) && [[preUserFlag uppercaseString] isEqualToString:@"YES"]) {
        result=YES;
    }
    
    return result;
}

- (BOOL) isOfflineModeLocked {
    BOOL result=NO;
    NSString *offlineLockFlag=[[NSUserDefaults standardUserDefaults] stringForKey:UD_OFFLINE_MODE_LOCKED];
    if ((offlineLockFlag!=nil) && [[offlineLockFlag uppercaseString] isEqualToString:@"YES"]) {
        result=YES;
    }
    
    return result;
}

- (BOOL)hasWarningAccepted {
    BOOL result=NO;
    NSString *warningAccepted=[[NSUserDefaults standardUserDefaults] stringForKey:UD_WARNING_ACCEPTED];
    if ((warningAccepted!=nil) && [[warningAccepted uppercaseString] isEqualToString:@"YES"]) {
        result=YES;
    }
    
    return result;
}

- (BOOL) shouldAppClearData {
    BOOL result=NO;
    NSString *appClearDataFlag=[[NSUserDefaults standardUserDefaults] stringForKey:UD_APP_CLEAR_DATA_FLAG];
    if ((appClearDataFlag!=nil) && [[appClearDataFlag uppercaseString] isEqualToString:@"YES"]) {
        result=YES;
    }
    
    return result;
}

- (void)resetAppClearDataFlag {
    [[NSUserDefaults standardUserDefaults] setValue:@"NO" forKey:UD_APP_CLEAR_DATA_FLAG];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)reset
{
//    self.mrn = @"0";
//    self.kpToken = @"0";
//    self.passCode = @"0";
    self.userName = @"0";
    self.password = @"0";
    self.userId = @"0";
    [self saveValuesToKC];
}

- (void)deauthorize
{	        
	[[WebServiceMan get] deauthorizeDevice];
        
    // Reset after ws call to deauth.
    [self reset];
    
    self.loginName=@"0";
    [self saveLoginNameToKC];
        
//    [[ContainerMan get] resetRefreshDate];
    
//    [[CoreDataMan get] resetCoreData];

    //[[Utilities getAppDel] clearBadges];

    [[TryMan tryMan] reset];    
    
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie * cookie in [storage cookies]) {
        [storage deleteCookie:cookie];
    }
    
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"LastSyncTime"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"SYNCTIME_UPDATE_NOTIFICATION" object:nil];
}


- (void)resetDevice
{
    [self reset];
    
    self.loginName=@"0";
    [self saveLoginNameToKC];
    
    [[TryMan tryMan] reset];
    
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie * cookie in [storage cookies]) {
        [storage deleteCookie:cookie];
    }
    
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"LastSyncTime"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"SYNCTIME_UPDATE_NOTIFICATION" object:nil];
    
    // remove all the signon flag
    
    [[NSUserDefaults standardUserDefaults] setValue:nil forKey:UD_APP_CLEAR_DATA_FLAG];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:nil forKey:UD_PREVIOUS_USER_CHECK];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:nil forKey:UD_OFFLINE_MODE_LOCKED];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:nil forKey:UD_WARNING_ACCEPTED];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"flagSignOn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}



- (BOOL)isAuthorized
{
    if (NO == [[NSUserDefaults standardUserDefaults] boolForKey:UD_KEY_KC_CHECK])
    {
        [self reset];
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:UD_KEY_KC_CHECK];
    }
    LOG("values for detecting authorization (username - password - userid): %@, %@, %@", self.userName, self.password, self.userId);
    
    /*
    BOOL _bool = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOnAsBG"];
    if (_bool == TRUE) {
        return (([self.passCode length] >= 1) || ([self.userId length]>1));  
    }
    else{
        return (([self.passCode length] >= 4) || ([self.userId length]>1));    // this make the passcode become optional
    }*/
    
    return (([self.userName length]>1) && ([self.password length]>1) && ([self.userId length]>1));
    
}

/*
- (BOOL)isSetPasscodeRequired
{
    return ([self.passCode isEqualToString:@"-1"]);
}

- (BOOL)passcodeRequired
{
  
    return ([self.passCode length]>=4);
}

- (void)resetPasscode
{
    self.passCode = @"0";
    [self saveValuesToKC];        
}

- (void)assignPC:(NSString*)szPC
{
    self.passCode = szPC;
    [self saveValuesToKC];
}

- (void)assignToken:(NSString*)szToken
{
    self.kpToken = szToken;
    [self saveValuesToKC]; 
}*/

- (void)saveUsernamePassword:(NSString *)username{
    
    self.userName = username;
    [self saveValuesToKC]; 
    
    
}

- (void)getLoginNameFromKC
{
    NSError *error=nil;
    
    self.loginName=[SFHFKeychainUtils getPasswordForUsername:LOGINNAME_KC_KEY andServiceName:APP_KC_KEY error:&error];
    
    LOG("initial values from keychain (login name): %@", self.loginName);
    
    if (self.loginName==nil) {
        self.loginName=@"0";
        [self saveLoginNameToKC];
        return;
    }
    
    self.loginName=[self decrypt:self.loginName];
    
    LOG("decryped values from keychain (login name): %@", self.loginName);
}

- (void)saveLoginNameToKC
{
    NSError *error=nil;
    if ([self.loginName length] == 0)
    {
        self.loginName=@"0";
    }
    
    LOG("values before encryption (login name): %@", self.loginName);
    
    NSString *encryptedLoginName=[self encrypt:self.loginName];
    
    LOG("values after encryption (login name): %@", encryptedLoginName);
    
    if (nil!=encryptedLoginName) {
        [SFHFKeychainUtils deleteItemForUsername:LOGINNAME_KC_KEY andServiceName:APP_KC_KEY error:&error];
        [SFHFKeychainUtils storeUsername:LOGINNAME_KC_KEY andPassword:encryptedLoginName forServiceName:APP_KC_KEY updateExisting:YES error:&error];
    }
}


- (NSString *)encrypt:(NSString *)iString {
	NSString *aReturnString = nil;
    
	NSData *anInputStringData = [iString dataUsingEncoding:NSISOLatin1StringEncoding];
	NSData *anEncryptedInputStringData = [anInputStringData AES256EncryptWithKey:[self keyString]];
	aReturnString = [[NSString alloc] initWithData:anEncryptedInputStringData encoding:NSISOLatin1StringEncoding];
    
	return aReturnString;
}


- (NSString *)decrypt:(NSString *)iEncryptedString {
	NSString *aReturnString = nil;
    
	NSData *anInputStringData = [iEncryptedString dataUsingEncoding:NSISOLatin1StringEncoding];
	NSData *aDecryptedInputStringData = [anInputStringData AES256DecryptWithKey:[self keyString]];
	aReturnString = [[NSString alloc] initWithData:aDecryptedInputStringData encoding:NSISOLatin1StringEncoding];
    
	return aReturnString;
}


- (NSString *)keyString {
	NSString *key = [Utilities hashString:[@"s9*d!0j#6x" stringByAppendingString:[Utilities deviceIdentifier]]];
	LOG("Hashed Key: %@", key);
    
	return key;
}


@end
