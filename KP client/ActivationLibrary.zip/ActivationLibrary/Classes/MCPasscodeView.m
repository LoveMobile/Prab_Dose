//
//  MCPasscodeView.m
//  MobileCare
//
//  Created by Sean Gilligan on 12/21/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//

#import <AudioToolbox/AudioServices.h>

#import "MCPasscodeView.h"
#import "MobileCareAppDelegate.h"
#import "AuthorizationMan.h"

#define kHiddenTextField     12

static const double kPasscodeRetryDelay = 0.5f;

@interface MCPasscodeView (Private)
- (UITextField*) createDigitField:(CGRect)digitFrame tag:(NSInteger)tag;
- (int) codeVal;
- (BOOL) codeEntered;
- (BOOL) validDigit:(NSString *)digitString;
- (void) resetEntry;
@end


@implementation MCPasscodeView

@synthesize	passcodeDelegate;
@synthesize m_lbPrompt;

#pragma mark Main

- (void)baseInit
{
	resetting = NO;
    self.backgroundColor = [UIColor clearColor];
	self.autoresizingMask = UIViewAutoresizingNone;
	hiddenField = [[UITextField alloc] initWithFrame:CGRectZero];
    hiddenField.hidden = NO;
    hiddenField.tag = kHiddenTextField;
    hiddenField.delegate = self;
    hiddenField.keyboardType = UIKeyboardTypeNumberPad;
    [self addSubview:hiddenField];
    [hiddenField becomeFirstResponder];
    [hiddenField release];
	
	code1 = [self createDigitField:CGRectMake(25.0, 60.0, kMCDigitFieldWidth, kMCDigitFieldHeight) tag:1];
	[self addSubview:code1];

	code2 = [self createDigitField:CGRectMake(95.0, 60.0, kMCDigitFieldWidth, kMCDigitFieldHeight) tag:2];
	[self addSubview:code2];

	code3 = [self createDigitField:CGRectMake(165.0, 60.0, kMCDigitFieldWidth, kMCDigitFieldHeight) tag:3];
	[self addSubview:code3];

	code4 = [self createDigitField:CGRectMake(235.0, 60.0, kMCDigitFieldWidth, kMCDigitFieldHeight) tag:4];
	[self addSubview:code4];
	
	self.m_lbPrompt = [[[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, kMCPasscodeViewWidth, 60.0)] autorelease];
	self.m_lbPrompt.textAlignment = UITextAlignmentCenter;
	self.m_lbPrompt.backgroundColor = [UIColor clearColor];
    self.m_lbPrompt.textColor=[UIColor whiteColor];
    self.m_lbPrompt.font=[UIFont systemFontOfSize:28];
	[self addSubview:self.m_lbPrompt];
	
}

- (void)dealloc 
{
    self.m_lbPrompt = nil;
//    self.passcodeLabel = nil;
    // delegate is never retained.
    [super dealloc];
}

- (void)viewDidUnload 
{
    self.m_lbPrompt = nil;
//   self.passcodeLabel = nil;
}

- (void)setPromptText:(NSString*)szText
{   
    self.m_lbPrompt.text = szText;
}

//- (void) setPasscodeLabel:(NSString *) label
//{
//	self.passcodeLabel = label;
//	prompt.text = label;
//}

//- (NSString *) passcodeLabel
//{
//	return passcodeLabel;
//}

- (void) makeActive
{
    [hiddenField becomeFirstResponder];
	[self resetEntry];
}

- (UITextField*) createDigitField:(CGRect)digitFrame tag:(NSInteger)tag
{
    UITextField *digitField = [[[UITextField alloc] initWithFrame:digitFrame] autorelease];
	digitField.borderStyle = UITextBorderStyleBezel;
	digitField.textColor = [UIColor blackColor];
	digitField.textAlignment = UITextAlignmentCenter;
	digitField.font = [UIFont systemFontOfSize:41];
	digitField.tag = tag;
	digitField.keyboardType = UIKeyboardTypeNumberPad;
	digitField.delegate = self;
	digitField.secureTextEntry = YES;
	digitField.backgroundColor = [UIColor whiteColor];
	digitField.enabled = NO;
    digitField.keyboardType = UIKeyboardTypeNumberPad;
	digitField.delegate = self;
	digitField.text = @"";
    return digitField;
}


- (id)initWithFrame:(CGRect)frame
{
    if ((self = [super initWithFrame:frame]))
	{
        [self baseInit];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if ((self = [super initWithCoder:aDecoder]))
	{
        [self baseInit];        
    }
    return self;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	if (resetting)
	{	// Don't accept input while we're waiting for a reset (performSelector)
		return NO;
	}
    NSString *code = textField.text;
    code = [code stringByReplacingCharactersInRange:range withString:string];
	
	NSInteger digit = code.length;
    if (string.length == 0)
	{
        digit++;
    }

	UITextField *digitField = nil;
	switch (digit)
	{
		case 1:
			digitField = code1;
			break;
		case 2:
			digitField = code2;
			break;
		case 3:
			digitField = code3;
			break;
		case 4:
			digitField = code4;
			break;
		default:
			break;
	}
	
	if ( (digitField != nil) && ([string isEqual:@""] || [self validDigit:string]))
	{
		digitField.text = string;
		if (digit == 4)
		{
            return [self codeEntered];
		}
		return YES;
	}
	return NO;
}
	
- (BOOL) codeEntered
{
    int code = [self codeVal];
    	
    NSString *enteredCode = [NSString stringWithFormat:@"%04d", code];
    
    if ([self.passcodeDelegate passcodeView:self isPasscodeValid:enteredCode])
    {
        [self.passcodeDelegate passcodeView:self didEnterValidPassocde:enteredCode];
        return YES;
    }
    else
    {
        [self.passcodeDelegate passcodeView:self didEnterInvalidPassocde:enteredCode];
        [self performSelector:@selector(resetEntry) withObject:nil afterDelay:kPasscodeRetryDelay];
        resetting = YES;    
        return NO;
    }    
}

- (void) resetEntry
{
	resetting = NO;
	code1.text = @"";
	code2.text = @"";
	code3.text = @"";
	code4.text = @"";
	hiddenField.text = @"";
}


- (int) codeVal
{
	int code = -1;
	
	if ( ([code1.text length] == 1) && ([code2.text length] == 1) &&
		([code3.text length] == 1) && ([code4.text length] == 1) )
	{
		unichar c1 = [code1.text characterAtIndex:0];
		unichar c2 = [code2.text characterAtIndex:0];
		unichar c3 = [code3.text characterAtIndex:0];
		unichar c4 = [code4.text characterAtIndex:0];
		code = (c1 - '0') * 1000 + (c2 - '0') * 100 + (c3 - '0') * 10 + c4 - '0';
	}
	return code;
}

- (BOOL) validDigit:(NSString *)digitString
{
	unichar theChar = [digitString characterAtIndex:0];
	if (theChar >= '0' && theChar <= '9')
	{
		return YES;
	}
	else
	{
		return NO;
	}
}


@end
