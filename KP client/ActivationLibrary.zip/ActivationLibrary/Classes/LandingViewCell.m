//
//  LandingViewCell.m
//  MobileCare
//
//  Created by Abhinav Sehgal.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LandingViewCell.h"

@implementation LandingViewCell
@synthesize m_image;
@synthesize m_lbl;

- (void)dealloc {
    self.m_image = nil;
    self.m_lbl = nil;
    [super dealloc];
}

@end
