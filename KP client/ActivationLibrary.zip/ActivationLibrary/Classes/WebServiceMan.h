//
//  WebServiceMan.h
//  MobileCare
//
//  Created by Paul on 5/3/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MCUrlConfig.h"
#import "WSCheck.h"

#define UD_KEY_CONFIG_TYPE @"UD_KEY_CONFIG_TYPE"

typedef enum 
{
    WCT_UNSPECIFIED = 0,
    WCT_QA = 1,
    WCT_PRODUCTION = 2,  
    WCT_PP = 3,
    WCT_LOCAL = 4,
    WCT_DEV = 5,
} WS_CONFIG_TYPES;


@interface WebServiceMan : NSObject<WSCheckDelegate>
{
    MCUrlConfig* m_urlConfig;
    WS_CONFIG_TYPES m_nConfigType;
}

@property (nonatomic, retain) MCUrlConfig* m_urlConfig;
@property (readonly) WS_CONFIG_TYPES configurationType;
@property (nonatomic, retain) NSString* wsBaseUrl;
@property (nonatomic, retain) NSString* webBaseUrl;
@property (nonatomic, retain) NSString* appId;

+ (WebServiceMan*)get;
- (void)setConfigType:(WS_CONFIG_TYPES)wct;
- (void)deauthorizeDevice;

@end
