//
//  FormatMan.m
//  MobileCare
//
//  Created by Paul on 4/21/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "FormatMan.h"

static FormatMan* mFM = nil;

@implementation FormatMan

@synthesize dateFormatter = m_dateFormatter;
@synthesize shortDateFormatter = m_shortDateFormatter;
@synthesize timeFormatter = m_timeFormatter;
@synthesize date_MMM_dd_yyyy_Formatter = m_date_MMM_dd_yyyy_Formatter;
@synthesize numberFormatter;

+ (FormatMan*)get
{
    if (nil == mFM)
    {
        mFM = [[FormatMan alloc] init];
    }
    return mFM;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        self.dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
        [self.dateFormatter setDateFormat:@"EEEE, MMMM d"];
        self.shortDateFormatter = [[[NSDateFormatter alloc] init] autorelease];
        [self.shortDateFormatter setDateFormat:@"EEEE, MMM d"];        
        self.timeFormatter = [[[NSDateFormatter alloc] init] autorelease];
        [self.timeFormatter setDateFormat:@"h:mm a"];
        
        self.date_MMM_dd_yyyy_Formatter = [[[NSDateFormatter alloc] init] autorelease];
        [self.date_MMM_dd_yyyy_Formatter setDateFormat:@"MMMM dd, yyyy"];
        
        self.numberFormatter = [[[NSNumberFormatter alloc] init] autorelease];
        [self.numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    }
    return self;
}

+ (NSString*)getDate:(NSDate*)dt
{    
    NSString* szRet = @"";
        
    if ([dt isKindOfClass:[NSDate class]])
    {
        szRet = [[FormatMan get].dateFormatter stringFromDate:dt];
    }
    return szRet;
}

+ (NSString*)getShortDate:(NSDate*)dt
{    
    NSString* szRet = @"";
    
    if ([dt isKindOfClass:[NSDate class]])
    {
        szRet = [[FormatMan get].shortDateFormatter stringFromDate:dt];
    }
    return szRet;
}

+ (NSString*)getTime:(NSDate*)dt
{
    NSString* szRet = @"";
    if ([dt isKindOfClass:[NSDate class]])
    {
        szRet = [[FormatMan get].timeFormatter stringFromDate:dt];    
    }
    return szRet;
}

+ (NSString*)getDateAsMMMddyyyy:(NSDate*)dt
{
    NSString* szRet = @"";
    if (dt != nil && [dt isKindOfClass:[NSDate class]])
    {
        szRet = [[FormatMan get].date_MMM_dd_yyyy_Formatter stringFromDate:dt];    
    }
    return szRet;
}

+ (NSDate*)getDateFromString:(NSString*)dt 
{
    if ([dt isKindOfClass:[NSString class]])
    {
        signed long long dtAsLong = [dt longLongValue];
        NSTimeInterval interval = dtAsLong/1000;
        //convert to PST
        return [NSDate dateWithTimeIntervalSince1970:interval];
    } 
    
    // Return an akward date.
    return [NSDate dateWithTimeIntervalSince1970:0];
}

+ (double) getCurrentTimeInSeconds {
    return [[NSDate date] timeIntervalSince1970];
    
}


@end
