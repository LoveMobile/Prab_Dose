//
//  AuthorizationViewController.m
//  MobileCareProto
//
//  Created by Sean Gilligan on 9/27/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//

#import "AuthorizationViewController.h"
#import "WebServiceMan.h"
#import "AuthorizationMan.h"
#import "Utilities.h"
#import "SBJsonParser.h"
#import "Constants.h"
#import "MessageMan.h"
#import <QuartzCore/QuartzCore.h>
#import "Utilities.h"
#import "PrivacyPracticesViewController.h"
#import "NetworkMan.h"
#import "TermsAndConditionsViewController.h"
#import "ErrorViewController.h"
#import "SignInHelpViewController.h"
#import "TTGUser.h"
#import "IdleTimerMan.h"

int isAccept;

@implementation AuthorizationViewController

@synthesize m_curHostName;
@synthesize m_webView;
//@synthesize m_backgroundView;
@synthesize requestURL;
@synthesize m_bbiCancel;
@synthesize delegate = m_delegate;
@synthesize m_fetcherJson;

@synthesize btn_accept;
@synthesize btn_decline;
@synthesize m_BottomContainerView;
@synthesize m_signOnView;
@synthesize txt_userName;
@synthesize txt_password;
@synthesize btn_signOn;
@synthesize lbl_invalidUID;
@synthesize btn_forgotPwd;
@synthesize m_authCompleteView;
@synthesize btn_continue;
@synthesize m_errorView;
@synthesize lbl_error_title;
@synthesize lbl_error;
@synthesize img_footer;
@synthesize m_signOnSubView;
@synthesize btn_createAccount;
@synthesize lbl_extraText;
@synthesize lbl_preventiveCare;
@synthesize m_confirmImgView;
@synthesize m_tryMan;
@synthesize requestType;
@synthesize signOnManager;
@synthesize userName;

- (id)initWithDelegate:(id<AuthorizationViewControllerDelegate>)del
{
    self = [super initWithNibName:@"AuthorizationViewController" bundle:nil];
    if (self)
    {
        self.delegate = del;
        self.requestURL=@"";
        self.m_tryMan=[TryMan tryMan];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    isAccept = 0;
    [[Utilities getAppDel] hideMessage];
    self.lbl_invalidUID.layer.cornerRadius = 4;
    self.lbl_invalidUID.layer.borderColor = [UIColor grayColor].CGColor;
    self.lbl_invalidUID.clipsToBounds = YES;

    [self.btn_continue setBackgroundImage:[[UIImage imageNamed:@"bkgd_button_lightgray.png"]
                                    stretchableImageWithLeftCapWidth:10.0f
                                    topCapHeight:0.0f]
                          forState:UIControlStateNormal];
    self.btn_continue.layer.cornerRadius = 8;
    self.btn_continue.layer.borderColor = [UIColor grayColor].CGColor;
    self.btn_continue.clipsToBounds = YES;
    [self.btn_continue setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [self.btn_accept setBackgroundImage:[[UIImage imageNamed:@"bar_button_orange.png"]
                                   stretchableImageWithLeftCapWidth:10.0f
                                   topCapHeight:0.0f]
                         forState:UIControlStateNormal];
    self.btn_accept.layer.cornerRadius = 8;
    self.btn_accept.layer.borderWidth = 1;
    //btn_accept.layer.borderColor = [UIColor grayColor].CGColor;
    self.btn_accept.clipsToBounds = YES;
    
    self.navigationController.navigationBar.alpha = 1;
    self.navigationController.navigationBarHidden = FALSE;
    self.navigationItem.title = @"Sign In";

    
    [self.btn_decline setBackgroundImage:[[UIImage imageNamed:@"bar_button_dkgrey.png"]
                                    stretchableImageWithLeftCapWidth:10.0f
                                    topCapHeight:0.0f]
                          forState:UIControlStateNormal];
    self.btn_decline.layer.cornerRadius = 8;
    self.btn_decline.layer.borderWidth = 1;
    //btn_decline.layer.borderColor = [UIColor grayColor].CGColor;
    self.btn_decline.clipsToBounds = YES;
    
    // CGRect frame_BottomContainerView = self.m_BottomContainerView.frame;
    //frame_BottomContainerView.origin.y = 375;
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (screenBounds.size.height == 568) {
        isIphone5=YES;
        self.m_authCompleteView.frame = CGRectMake(0, 0, 320, 550);

        // code for 4-inch screen
//        self.m_BottomContainerView.frame = CGRectMake(0, 505, 320, 46);
//        self.m_authCompleteView.frame = CGRectMake(0, 0, 320, 550);
//        self.m_imgView.image = [UIImage imageNamed:@"Background_Welcome-568h@2x.png"];
//        self.m_confirmImgView.image=[UIImage imageNamed:@"Background_Welcome-568h@2x.png"];
    } else {
        isIphone5=NO;
        // code for 3.5-inch screen
        self.m_authCompleteView.frame = CGRectMake(0, 0, 320, 460);

//        self.m_BottomContainerView.frame = CGRectMake(0, 417, 320, 46);
//        self.m_authCompleteView.frame = CGRectMake(0, 0, 320, 460);
//        self.m_imgView.image = [UIImage imageNamed:@"Background_Welcome.png"];
//        self.m_confirmImgView.image = [UIImage imageNamed:@"Background_Welcome.png"];
    }
    
    
    
    //self.m_BottomContainerView.frame = frame_BottomContainerView;
    [self.view addSubview:self.m_BottomContainerView];
    self.btn_accept.hidden = TRUE;
    self.btn_decline.hidden = TRUE;
    self.m_BottomContainerView.hidden = TRUE;
    
	firstPageLoaded = NO;
    
    //	self.m_bbiCancel = [[[UIBarButtonItem alloc] 
    //                                        initWithBarButtonSystemItem:UIBarButtonSystemItemCancel 
    //                                        target:self 
    //                                        action:@selector(touchCancel:)] autorelease];
    //    
    //	self.navigationItem.rightBarButtonItem = m_bbiCancel;
    
//    UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]];
//	self.view.backgroundColor = background;
//    [background release];
    
    
    /*
    // ABHI CHECK Passcode or Sign On view
    BOOL _bool = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOnAsBG"];
    if (_bool == TRUE) {
     
        AuthorizationMan* am = [AuthorizationMan get];
        if ([am isAuthorized])
        {
            self.txt_userName.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"userNAme"];
            self.view.frame = CGRectMake(0, 0, 320, 416);
            self.m_BottomContainerView.hidden = FALSE;
            self.btn_accept.hidden = FALSE;
            self.btn_decline.hidden = FALSE;
            
            [self action_accept:nil]; 
        }
        else{
            [self loadWebView];
            
        }
    }
    else{
        [self loadWebView];
    }
     */
    
    //self.navigationController.navigationBarHidden = YES;
    [self action_accept:nil];
    
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated]; 

    int_SwitchBtn = [[NSUserDefaults standardUserDefaults]integerForKey:@"int_SwitchBtn"];
    AuthorizationMan* am = [AuthorizationMan get];
    
    if (int_SwitchBtn == 1) {
        
        self.txt_password.text = @"";
        //NSString* lastSuccessLoginName = [[NSUserDefaults standardUserDefaults] stringForKey:UD_KEY_LASTLOGIN_NAME];
        
        [am getLoginNameFromKC];
        NSString* lastSuccessLoginName =am.userName;
        NSString* lastLoginUserName=am.loginName;
        LOG("The user's last successful login user name is: %@", lastSuccessLoginName);
        if (int_fromLaunch==1) {
            int_fromLaunch=0;
            if (lastSuccessLoginName!=nil && (![lastSuccessLoginName isEqualToString:@"0"])) {
                self.txt_userName.text = lastSuccessLoginName;
                am.loginName=lastSuccessLoginName;
            } else {
                self.txt_userName.text = @"";
                am.loginName=@"0";
            }
            [am saveLoginNameToKC];
        } else {
            if (lastLoginUserName!=nil && (![lastLoginUserName isEqualToString:@"0"])) {
                self.txt_userName.text = lastLoginUserName;
            } else {
                self.txt_userName.text = @"";
            }
        }
        self.changeImageView.image = [UIImage imageNamed:@"Toggle_SaveCredentials_On"];
        
    }
    else
    {
        
        self.txt_userName.text = @"";
        am.loginName=@"0";
        [am saveLoginNameToKC];
        
        self.txt_password.text = @"";
        
        self.changeImageView.image = [UIImage imageNamed:@"Toggle_SaveCredentials_Off.png"];
        
    }
    
    [self setOriginalFrame];
}

- (IBAction)onBtnClick
{
    int_SwitchBtn = 1;
    [[NSUserDefaults standardUserDefaults]setInteger:int_SwitchBtn forKey:@"int_SwitchBtn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    self.changeImageView.image = [UIImage imageNamed:@"Toggle_SaveCredentials_On.png"];
    
}


- (IBAction)offBtnClick
{
    int_SwitchBtn = 2;
    [[NSUserDefaults standardUserDefaults]setInteger:int_SwitchBtn forKey:@"int_SwitchBtn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    self.changeImageView.image = [UIImage imageNamed:@"Toggle_SaveCredentials_Off.png"];
    
}



-(void)setOriginalFrame{
    
    self.l1PreventiveCare.alpha = 1;

    self.lbl_extraText.alpha = 1;
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (screenBounds.size.height == 568) {
        isIphone5=YES;

        self.lbl_invalidUID.frame = CGRectMake(30,110,260,15);
        self.view.frame = CGRectMake(0, 0, 320, 568);
        
        CGRect frame = self.l1PreventiveCare.frame;
        frame.origin.y = 30;
        self.l1PreventiveCare.frame = frame;
        
        frame = self.lbl_extraText.frame;
        frame.origin.y = 65;
        self.lbl_extraText.frame = frame;
        
        frame = self.m_signOnSubView.frame;
        frame.origin.y = 134;
        self.m_signOnSubView.frame = frame;
        
        frame = self.rememberView.frame;
        frame.origin.y = 105;
        self.rememberView.frame = frame;
        
        frame = self.btn_signOn.frame;
        frame.origin.y = 169;
        self.btn_signOn.frame = frame;
        
        frame = self.btn_forgotPwd.frame;
        frame.origin.y = 221;
        self.btn_forgotPwd.frame = frame;
        
        frame = self.termView.frame;
        frame.origin.y = 266;
        self.termView.frame = frame;
        
    }else {
        self.lbl_invalidUID.frame = CGRectMake(30,90,260,15);

        float version = [[[UIDevice currentDevice] systemVersion] floatValue];
        if (version>=7.0) {
            self.view.frame = CGRectMake(0, 0, 320, 460);
            self.m_signOnView.frame=CGRectMake(0, 0, 320, 500);
        }
        
        CGRect frame = self.l1PreventiveCare.frame;
        frame.origin.y = 20;
        self.l1PreventiveCare.frame = frame;
        
        frame = self.lbl_extraText.frame;
        frame.origin.y = 50;
        self.lbl_extraText.frame = frame;
        
        frame = self.m_signOnSubView.frame;
        frame.origin.y = 110;
        self.m_signOnSubView.frame = frame;
        
        frame = self.rememberView.frame;
        frame.origin.y = 95;
        self.rememberView.frame = frame;
        
        frame = self.btn_signOn.frame;
        frame.origin.y = 159;
        self.btn_signOn.frame = frame;
        
        frame = self.btn_forgotPwd.frame;
        frame.origin.y = 211;
        self.btn_forgotPwd.frame = frame;
        
        frame = self.termView.frame;
        frame.origin.y = 241;
        self.termView.frame = frame;

        
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
//    self.btn_accept.hidden = TRUE;
//    self.btn_decline.hidden = TRUE;
//    self.m_BottomContainerView.hidden = TRUE;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    self.btn_decline = nil;
    self.btn_accept = nil;
    self.img_footer = nil;
    self.m_BottomContainerView = nil;
    self.m_signOnView = nil;
    self.txt_userName = nil;
    self.txt_password = nil;
    self.btn_signOn = nil;
    self.lbl_invalidUID = nil;
    self.btn_forgotPwd = nil;
    self.m_authCompleteView = nil;
    self.btn_continue = nil;
    self.m_errorView = nil;
    self.lbl_error_title = nil;
    self.lbl_error = nil;
    self.m_curHostName = nil;
    self.m_webView.delegate = nil;
    self.m_webView = nil;
    //self.m_backgroundView = nil;
    self.requestURL=nil;
    self.m_bbiCancel = nil;
    self.navigationItem.rightBarButtonItem = nil;
    
    self.m_signOnSubView = nil;
    self.btn_createAccount = nil;
    self.lbl_extraText=nil;
    self.lbl_preventiveCare=nil;
    self.m_imgView=nil;
    self.m_confirmImgView=nil;
    self.m_tryMan=nil;
    
    if (self.m_fetcherJson)
    {
        if (self.m_fetcherJson.delegate)
        {
            // Hide AI assuming a fetch hasn't returned yet.
            // And remove any references to self.
            [[Utilities getAppDel] hideAi];            
            self.m_fetcherJson.delegate = nil;
        }
        
        [self.m_fetcherJson stop];
        self.m_fetcherJson = nil;
    }
    
}

- (void)dealloc
{
    self.m_curHostName = nil;
    //self.m_backgroundView = nil;
    self.requestURL=nil;
    self.m_bbiCancel = nil;
    
    self.m_webView.delegate = nil;
    self.m_webView = nil;
    
    self.navigationItem.rightBarButtonItem = nil;
    self.btn_decline = nil;
    self.btn_accept = nil;
    self.img_footer = nil;
    self.m_BottomContainerView = nil;
    self.m_signOnView = nil;
    self.txt_userName = nil;
    self.txt_password = nil;
    self.btn_signOn = nil;
    self.lbl_invalidUID = nil;
    self.btn_forgotPwd = nil;
    self.m_authCompleteView = nil;
    self.btn_continue = nil;
    self.m_errorView = nil;
    self.lbl_error_title = nil;
    self.lbl_error = nil;    
    self.m_signOnSubView = nil;
    self.btn_createAccount = nil;
    self.lbl_extraText=nil;
    self.lbl_preventiveCare=nil;
    self.m_confirmImgView=nil;
    self.m_imgView=nil;
    self.m_tryMan=nil;
    
    if (self.m_fetcherJson)
    {
        if (self.m_fetcherJson.delegate)
        {
            // Hide AI assuming a fetch hasn't returned yet.
            // And remove any references to self.
            [[Utilities getAppDel] hideAi];            
//            self.m_fetcherJson.delegate = nil;
        }
        
        [self.m_fetcherJson stop];
    }

    [super dealloc];
}

#pragma mark -
#pragma mark Accept/Decline

- (IBAction)action_decline:(id)sender {
    
    int_decline = 1;
    /*
    [self dismissModalViewControllerAnimated:NO];
    [self.delegate setState:NORCAL_QUESTION];
     */
    [self.delegate signOnComplete:NO];
}

- (IBAction)action_accept:(id)sender {
    
    // Google Analyser
    [Utilities postGATrackPageName:@"SignOnView"];
    
    isAccept = 1;
    int_decline = 0;
    self.btn_accept.hidden = TRUE;
    self.btn_decline.hidden = TRUE;
    self.m_BottomContainerView.hidden = TRUE;
    
    NSInteger myCustomHeight = 44;
    txt_userName.frame = CGRectMake(30, 4, 260, myCustomHeight);
    txt_password.frame = CGRectMake(30, 40, 260, myCustomHeight);
    
    if (isIphone5) {
        m_signOnView.frame = CGRectMake(0, 0, 320, 550);
        
    } else {
        m_signOnView.frame = CGRectMake(0, 0, 320, 460);
    }
        
    [self.view addSubview:m_signOnView];
    self.lbl_invalidUID.hidden = TRUE;
    
}

#pragma mark -
#pragma mark Sign On

- (IBAction)action_forgotPWD:(id)sender {
    /*
    NSURL *url = [NSURL URLWithString:@"https://m.kp.org/mt/healthy.kaiserpermanente.org/health/care/consumer/dis/forgotpassword?un_jtt"];
    [[UIApplication sharedApplication] openURL:url];
     */
    SignInHelpViewController* vc = [[[SignInHelpViewController alloc] init] autorelease];
    /*
	UINavigationController* nc = [[[UINavigationController alloc] initWithRootViewController:vc] autorelease];
	nc.navigationBar.tintColor = [Utilities getAppDel].navBarColor;
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    if (version>=7.0) {
        nc.navigationBar.translucent=NO;
        nc.navigationBar.barTintColor=[Utilities getAppDel].navBarColor;
        [[UINavigationBar appearance] setTitleTextAttributes:
         [NSDictionary dictionaryWithObjectsAndKeys:
          [UIColor whiteColor], UITextAttributeTextColor,
          [UIFont fontWithName:@"Helvetica Neue" size:18.0], UITextAttributeFont,nil]];
    }*/
    //nc.modalTransitionStyle = UIModalTransitionStyleCoverVertical; //UIModalTransitionStyleCrossDissolve;
    //[self presentModalViewController:nc animated:YES];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)showAlert:(NSString  *)message{
    
    UIAlertView *alertView= [[UIAlertView alloc] initWithTitle:nil message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alertView show];
    [alertView release];
    alertView = nil;
}

- (IBAction)action_signOn:(id)sender {
    
    [self.txt_password resignFirstResponder];
    [self.txt_userName resignFirstResponder];
    
    /*
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.30];
    self.view.frame = CGRectMake(0, 0, 320, 568);
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.50];
    
    CGFloat yourDesiredWidth = 260.0;
    CGFloat yourDesiredHeight = 0.0;
    CGAffineTransform scalingTransform;
    scalingTransform = CGAffineTransformMakeScale(yourDesiredWidth/self.lbl_preventiveCare.bounds.size.width, yourDesiredHeight/self.lbl_preventiveCare.bounds.size.height);
    self.lbl_preventiveCare.transform = scalingTransform;
    self.lbl_preventiveCare.frame = CGRectMake(20, 0, 260, 44);
    self.lbl_extraText.alpha = 0;
    self.navigationController.navigationBar.alpha = 1;
    self.navigationController.navigationBarHidden = FALSE;
    [self setOriginalFrame];
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.30];
    [UIView commitAnimations];
     */

        if ([self.txt_userName.text isEqualToString:@""] || [self.txt_userName.text isEqualToString:nil]) {
            
            [self showAlert:@"Please enter username"];
        }
        else if ([self.txt_password.text isEqualToString:@""] || [self.txt_password.text isEqualToString:nil]) {
            
            [self showAlert:@"Please enter password"];
        }
        else if ([self.txt_userName.text length]!=0 && [self.txt_password.text length] !=0) {

            if ([NetworkMan getNetworkType]!=0) {
                [self onlineSignOn:self.txt_userName.text :self.txt_password.text];
            } else {
                [self offlineSignOn:self.txt_userName.text :self.txt_password.text];
            }
        }
        
            
}


- (void) onlineSignOn:(NSString *)username :(NSString *)password
{
    self.userName=username;
    self.signOnManager = [[TTGSignOnManager alloc] initWithUsername:self.userName password:password region:@"MRN" apiKey:@"kppcmobil83852016904723181794" appID:@"MD-5" appName:@"MyMed" andAppVersion:@"3.0.2"];

    [signOnManager performSignOnWithSuccess:^(TTGUser *user) {
        
        [self performSelectorOnMainThread:@selector(processData:) withObject:user waitUntilDone:NO];
        
    } andError:^(TTGStatus *status) {
        
        [self performSelectorOnMainThread:@selector(processError:) withObject:status waitUntilDone:NO];
        
    }];
    
    // AI is dismissed in the delegate.
    [[Utilities getAppDel] showAi];
}

#pragma mark - Data processing methods

- (void)processData:(TTGUser *)data
{
    [[Utilities getAppDel] hideAi];
    
    LOG("Data Received: \n %@", data);
    
    TTGUser *user = (TTGUser *)data;
    
    ssoSessionIdStr = user.ssosession;
    LOG("ssosession is: %@", ssoSessionIdStr);
    
    
    NSString* guidString = user.guid;
    LOG("guid is: %@", guidString);
    
    [self doRegister:self.userName :guidString];
}

- (void)processError:(TTGStatus *)error
{
    [[Utilities getAppDel] hideAi];
    
    LOG("Error Received: \n %@", error.statusMessage);
    
    TTGStatus *status = (TTGStatus *)error;
    
    int nRes = [status.statusCode intValue];
    
    SERVER_STATUS_RESULT nSSR = [WSCheck getStatusResultFromCode:nRes];
    
    if (WSC_SYS_MNTNC == nSSR)
    {
        LOG("maintenance");
        NSString *errorMsg=@"KP Preventive Care is currently undergoing routine maintenance.  Please try again later.";
        NSString *title=@"Maintenance";
        [self displayErrorWithTitle:title andMessage:errorMsg];
    }
    else if (WSC_AUTHORIZE_FAIL == nSSR)
    {
        LOG("Authorization failed");
        /*
         self.lbl_error.text = @"Authorization failed. Please go to kp.org to activate your account.";
         self.lbl_error_title.text = @"Authorization failed";
         [self action_showError];
         */
        NSString *errorMsg=@"Authorization failed. Please go to kp.org to activate your account.";
        NSString *title=@"Authorization failed";
        [self displayErrorWithTitle:title andMessage:errorMsg];
    }
    else if (WSC_AUTHENT_LOCKOUT == nSSR)
    {
        LOG("Lock out");
        /*
         self.lbl_error.text = @"There is a problem with your account. Please go to kp.org for details.";
         self.lbl_error_title.text = @"Locked out";
         [self action_showError];
         */
        NSString *errorMsg=@"This device has been locked for your protection. Login to kp.org to reactivate your account.";
        NSString *title=@"Security Alert";
        [self displayErrorWithTitle:title andMessage:errorMsg];
        
    }
    else if (WSC_NOT_NCAL == nSSR)
    {
        LOG("Not NCAL");
        /*
         self.lbl_error.text = @"This app is available only to Kaiser Permanente members in Northern California at this time.";
         self.lbl_error_title.text = @"Not NCAL Member";
         [self action_showError];
         */
        NSString *errorMsg=@"This app is available only to Kaiser Permanente members in Northern California at this time.";
        NSString *title=@"Not NCAL Member";
        [self displayErrorWithTitle:title andMessage:errorMsg];
        
    }
    else if (WSC_AUTHENT_FAIL == nSSR)
    {
        LOG("Authentication fail");
        
        [self.txt_password setText:@""];
        //[self.txt_userName setText:@""];
        
        self.lbl_invalidUID.hidden = FALSE;
        //[self setOriginalFrame];
        
        //[self.m_signOnSubView setFrame:CGRectMake(0, 201, 320, 251)];
        
        //also add offline try logic here
        [self.m_tryMan addTry];
        if ([self.m_tryMan hasTries]<=0) {
            [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:UD_OFFLINE_MODE_LOCKED];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        
    }
    else if (WSC_NET_FAIL == nSSR)
    {
        LOG("Network connection fail");
        [self offlineSignOn:self.txt_userName.text :self.txt_password.text];
    }
    else //web service error
    {
        LOG("General Error");
        /*
         self.lbl_error.text = @"We're sorry, we're unable to connect to retrieve your data at this time. Please try again later.";
         self.lbl_error_title.text = @"Error";
         [self action_showError];
         */
        NSString *errorMsg=@"We're sorry, we're unable to connect to retrieve your data at this time. Please try again later.";
        NSString *title=@"Error";
        [self displayErrorWithTitle:title andMessage:errorMsg];
        
    }
    
}


- (void) doRegister:(NSString *)userId :(NSString *)guidStr
{
    NSMutableDictionary* dParams = [NSMutableDictionary dictionary];
    
    [dParams setValue:[Utilities encodeURLString:userId] forKey:@"username"];
    [dParams setValue:[Utilities encodeURLString:guidStr] forKey:@"guid"];
    
    self.m_fetcherJson = [[[FetcherJson alloc] initWithMethod:@"register" andParams:dParams] autorelease];
    self.m_fetcherJson.delegate = self;
    self.requestType=REGISTER;
    self.signInResponse=nil;
    [self.m_fetcherJson fetch];
    
    // AI is dismissed in the delegate.
    [[Utilities getAppDel] showAi];
}

/*
- (void) signOn:(NSString *)userId :(NSString *)password
{
    NSMutableDictionary* dParams = [NSMutableDictionary dictionary];
    
    [dParams setValue:[Utilities encodeURLString:userId] forKey:@"username"];
    [dParams setValue:[Utilities encodeURLString:password] forKey:@"password"];
    
    self.m_fetcherJson = [[[FetcherJson alloc] initWithMethod:@"performSignon" andParams:dParams] autorelease];
    self.m_fetcherJson.delegate = self;
    self.requestType=SIGNIN;
    self.signInResponse=nil;
    [self.m_fetcherJson fetch];
    
    // AI is dismissed in the delegate.
    [[Utilities getAppDel] showAi];
}
 */

- (IBAction)action_createAccount:(id)sender {
    NSURL *url = [NSURL URLWithString:@"https://www.kp.org"];
    [[UIApplication sharedApplication] openURL:url];
}

#pragma mark -
#pragma mark Fetcher Delegate Methods

- (BOOL)fetcher:(Fetcher*)fetcher didSucceedWithValue:(id)value
{
    [[Utilities getAppDel] hideAi];
    
    if (![value isKindOfClass:[NSDictionary class]])
    {
        // This indicates an error in web services.
        // TODO : decice how to route this.d
        LOG("error in web service %@", value);
        [MessageMan showMessage:[NSString stringWithFormat:@"%@ is having trouble with signon. Please try again later.", [[Utilities getAppDel] getAppDisplayName]] withTitle:@"Signon"];        
        return NO;
    }
    
    if (value != nil) { 
        NSDictionary* dResponse = [value objectForKey:@"response"];
        
        LOG("statusCode:%@ - message:%@", [dResponse objectForKey:@"statusCode"], [dResponse objectForKey:@"message"]); 
         LOG("%@",[dResponse objectForKey:@"mrn"]);
        [self.lbl_error setFont:[UIFont fontWithName:@"Helvetica" size:16]];
        
        int nRes = [[dResponse objectForKey:@"statusCode"] intValue];
        
        SERVER_STATUS_RESULT nSSR = [WSCheck getStatusResultFromCode:nRes];
        
        shouldClearData=NO;
        
        if (WSC_GOOD == nSSR) 
        {
            if (self.requestType==REGISTER) {
                self.signInResponse=dResponse;
                LOG("The sign in response is: %@", dResponse);
                
                //am.userId = [Utilities getStringFromJson:[self.signInResponse objectForKey:@"userId"]];
                
                BOOL isDeviceSwtched = [[dResponse objectForKey:@"switchDeviceFlag"] boolValue];
                
                if ([self isDifferentUser]) {
                    LOG("The user is being switched!");
                    NSString *title=@"Another KP member is already using this device";
                    NSString *message=@"If you continue, their alerts will be suspended.";
                    UIAlertView *alertView= [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Use this device?", nil];
                    alertView.tag = 1002;
                    [[Utilities getAppDel].alerts addObject:alertView];
                    [alertView show];
                    [alertView release];
                } else if (isDeviceSwtched) {
                    LOG("The device is being switched!");
                    NSString *title=@"Using more than one device?";
                    NSString *message=@"Changes you make here will not show up on other devices until you use them to log in.";
                    UIAlertView *alertView= [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Use this device", nil];
                    alertView.tag = 1000;
                    [[Utilities getAppDel].alerts addObject:alertView];
                    [alertView show];
                    [alertView release];
                } else {
                    [self completeOnlineSignOn:self.signInResponse];
                }
            } else if (self.requestType==ACTIVATE) {
                LOG("The device has been switched!");
                [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:UD_APP_CLEAR_DATA_FLAG];
                [[NSUserDefaults standardUserDefaults] synchronize];
                shouldClearData=YES;
                
                [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:UD_PREVIOUS_USER_CHECK];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
                [self completeOnlineSignOn:self.signInResponse];
            }
        }
        /*
        else if (WSC_SYS_MNTNC == nSSR)
        {
            LOG("maintenance");
            NSString *errorMsg=@"KP Preventive Care is currently undergoing routine maintenance.  Please try again later.";
            NSString *title=@"Maintenance";
            [self displayErrorWithTitle:title andMessage:errorMsg];
        }
        else if (WSC_AUTHORIZE_FAIL == nSSR)
        {
            LOG("Authorization failed");
             self.lbl_error.text = @"Authorization failed. Please go to kp.org to activate your account.";
             self.lbl_error_title.text = @"Authorization failed";
             [self action_showError];
            NSString *errorMsg=@"Authorization failed. Please go to kp.org to activate your account.";
            NSString *title=@"Authorization failed";
            [self displayErrorWithTitle:title andMessage:errorMsg];
        }
        else if (WSC_AUTHENT_LOCKOUT == nSSR)
        {
            LOG("Lock out");
             self.lbl_error.text = @"There is a problem with your account. Please go to kp.org for details.";
             self.lbl_error_title.text = @"Locked out";
             [self action_showError];
            NSString *errorMsg=@"This device has been locked for your protection. Login to kp.org to reactivate your account.";
            NSString *title=@"Security Alert";
            [self displayErrorWithTitle:title andMessage:errorMsg];
            
        }
        else if (WSC_NOT_NCAL == nSSR)
        {
            LOG("Not NCAL");
             self.lbl_error.text = @"This app is available only to Kaiser Permanente members in Northern California at this time.";
             self.lbl_error_title.text = @"Not NCAL Member";
             [self action_showError];
            NSString *errorMsg=@"This app is available only to Kaiser Permanente members in Northern California at this time.";
            NSString *title=@"Not NCAL Member";
            [self displayErrorWithTitle:title andMessage:errorMsg];
            
        }
        else if (WSC_AUTHENT_FAIL == nSSR)
        {
            LOG("Authentication fail");
            
            [self.txt_password setText:@""];
            //[self.txt_userName setText:@""];
            
            self.lbl_invalidUID.hidden = FALSE;
            [self setOriginalFrame];
            
            //[self.m_signOnSubView setFrame:CGRectMake(0, 201, 320, 251)];
            
            //also add offline try logic here
            [self.m_tryMan addTry];
            if ([self.m_tryMan hasTries]<=0) {
                [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:UD_OFFLINE_MODE_LOCKED];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }
            
        }
        */
        else if (WSC_NET_FAIL == nSSR)
        {
            LOG("Network connection fail");
            [self offlineSignOn:self.txt_userName.text :self.txt_password.text];
        }
        else //web service error
        {
            LOG("General Webservice Error!");
            
            if (self.requestType==REGISTER) {
                LOG("still perform offline signOn if it is from register!");
                [self offlineSignOn:self.txt_userName.text :self.txt_password.text];
            } else {
                NSString *errorMsg=@"We're sorry, we're unable to connect to retrieve your data at this time. Please try again later.";
                NSString *title=@"Error";
                [self displayErrorWithTitle:title andMessage:errorMsg];
            }
            
        }
    } 
    
    return YES;
}

- (BOOL)fetcher:(Fetcher*)fetcher didFailWithError:(FETCHER_FAILURE)value
{
    [[Utilities getAppDel] hideAi];
    if (self.requestType==REGISTER) {
        LOG("still perform offline signOn if it is from register!");
        [self offlineSignOn:self.txt_userName.text :self.txt_password.text];
    } else if (self.requestType==ACTIVATE){
        NSString *errorMsg=@"We're sorry, we're unable to connect to retrieve your data at this time. Please try again later.";
        NSString *title=@"Error";
        [self displayErrorWithTitle:title andMessage:errorMsg];
    }
    
    return YES;
}

-(void)action_showError
{
    
    
    [m_webView removeFromSuperview];
    [self.m_signOnView removeFromSuperview];
    
    //self.navigationItem.titleView= nil;
    //self.navigationItem.title =  title;
    
    self.navigationItem.rightBarButtonItem = nil;
    self.navigationItem.title = @"";
    
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Back"
                                                                   style:UIBarButtonItemStylePlain
                                                                  target:self
                                                                  action:@selector(action_welcomeScreen)] ;
    
    self.navigationItem.leftBarButtonItem = doneButton;
    [self.view addSubview:self.m_errorView];
    if ([Utilities isiPhone5]) {
        self.view.frame = CGRectMake(0, 40, 320, 510);
        self.m_errorView.frame = CGRectMake(0, 40, 320, 510);
        
    } else {
        self.view.frame = CGRectMake(0, 40, 320, 460);
        self.m_errorView.frame = CGRectMake(0, 40, 320, 460);
    }
    
    
}

-(void)action_welcomeScreen{
    
   // [m_errorView removeFromSuperview];
    [[Utilities getAppDel] hideMessage];
//    [[AuthorizationMan get] deauthorize];
//    [[Utilities getAppDel] showMerlinWithState:DEAUTHORIZED];
//    [[Utilities getAppDel] hideMessage];
    
    [[Utilities getAppDel] showMerlin];
    
}


#pragma mark -
#pragma mark Continue

- (IBAction)action_continue:(id)sender {
    //surya Bug Fix DE78 start
    //[self.m_authCompleteView removeFromSuperview];
    //[[Utilities getAppDel] hideAi];
       
    [[AuthorizationMan get] saveUsernamePassword:self.txt_userName.text];
    [self signOnCompleteAndValid]; 
    
    //surya Bug Fix DE78 end 
      
}
#pragma mark -
#pragma mark Touch Events

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    /*
	UITouch *touch1 = [touches anyObject];
    
    if (touch1.view == self.lbl_error) 
	{
        NSURL *url = [NSURL URLWithString:@"http://www.kp.org"];
        [[UIApplication sharedApplication] openURL:url];
        
    }
    
    if (touch1.view == self.m_signOnView || touch1.view == self.m_signOnSubView || touch1.view == self.lbl_preventiveCare || touch1.view ==self.lbl_extraText || touch1.view == self.m_imgView) {
        self.view.frame = CGRectMake(0, 0, 320, 568);

        [self.txt_password resignFirstResponder];
        [self.txt_userName resignFirstResponder];
    }
    [self.txt_password resignFirstResponder];
    [self.txt_userName resignFirstResponder];
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationBeginsFromCurrentState:YES];
        [UIView setAnimationDuration:0.30];
        self.view.frame = CGRectMake(0, 0, 320, 568);
        [UIView commitAnimations];
    
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationBeginsFromCurrentState:YES];
        [UIView setAnimationDuration:0.50];
    
        CGFloat yourDesiredWidth = 260.0;
        CGFloat yourDesiredHeight = 0.0;
        CGAffineTransform scalingTransform;
        scalingTransform = CGAffineTransformMakeScale(yourDesiredWidth/self.lbl_preventiveCare.bounds.size.width, yourDesiredHeight/self.lbl_preventiveCare.bounds.size.height);
        self.lbl_preventiveCare.transform = scalingTransform;
        self.lbl_preventiveCare.frame = CGRectMake(20, 0, 260, 44);
        self.lbl_extraText.alpha = 0;
        self.navigationController.navigationBar.alpha = 1;
        self.navigationController.navigationBarHidden = FALSE;
        [self setOriginalFrame];
        [UIView commitAnimations];
    
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationBeginsFromCurrentState:YES];
        [UIView setAnimationDuration:0.30];
        [UIView commitAnimations];
     */
    
	UITouch *touch1 = [touches anyObject];
    if (touch1.view == self.lbl_error)
	{
        NSURL *url = [NSURL URLWithString:@"https://www.kp.org"];
        [[UIApplication sharedApplication] openURL:url];
    }
    
    if (touch1.view == self.m_signOnView || touch1.view == self.m_signOnSubView || touch1.view == self.lbl_preventiveCare || touch1.view ==self.lbl_extraText || touch1.view == self.m_imgView) {
        [self.txt_password resignFirstResponder];
        [self.txt_userName resignFirstResponder];
    }

}

-(IBAction)userNameEditingChanged {
    AuthorizationMan* am = [AuthorizationMan get];
    am.loginName=self.txt_userName.text;
    [am saveLoginNameToKC];
    LOG("The current lastLoginUserName is: %@", am.loginName);
}


#pragma mark -
#pragma mark Text Field Delegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField

{
    if (textField == txt_userName) {
        [txt_password becomeFirstResponder];
    }
    else if(textField == txt_password){
        [textField resignFirstResponder];
        [self action_signOn:nil];
    }
        return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.50];
    
    [self setEditingFrame];
    
    [UIView commitAnimations];
    
    [self delay];
    
}

-(void)setEditingFrame{
    
    self.l1PreventiveCare.alpha = 1;
    self.lbl_extraText.alpha = 0;
    self.navigationController.navigationBar.alpha = 1;
    self.view.frame = CGRectMake(0, 0, 320, 460);
    
    CGFloat yourDesiredWidth = 260;
    CGFloat yourDesiredHeight = 0.0;
    CGAffineTransform scalingTransform;
    scalingTransform = CGAffineTransformMakeScale(yourDesiredWidth/self.lbl_preventiveCare.bounds.size.width, yourDesiredHeight/self.lbl_preventiveCare.bounds.size.height);
    self.lbl_preventiveCare.transform = scalingTransform;

    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (screenBounds.size.height == 568) {
        isIphone5=YES;
        //self.m_imgView.image = [UIImage imageNamed:@"Background_Welcome-568h@2x.png"];

        self.lbl_invalidUID.frame = CGRectMake(30,-37,260,15);
        CGRect frame = self.m_signOnSubView.frame;
        frame.origin.y = 70;
        self.m_signOnSubView.frame = frame;
        
    }else {
        self.lbl_invalidUID.frame = CGRectMake(30,-37,260,15);
        //self.m_imgView.image = [UIImage imageNamed:@"Background_Welcome.png"];

        CGRect frame = self.l1PreventiveCare.frame;
        frame.origin.y = 15;
        
        self.l1PreventiveCare.frame = frame;
        frame = self.m_signOnSubView.frame;
        frame.origin.y = 50;
        self.m_signOnSubView.frame = frame;
        
        frame = self.btn_signOn.frame;
        frame.origin.y = 145;
        self.btn_signOn.frame = frame;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    /*
    self.l1PreventiveCare.alpha = 1;
    self.lbl_extraText.alpha = 0;
    self.navigationController.navigationBar.alpha = 0;
    self.view.frame = CGRectMake(0, 0, 320, 460);
    
    CGFloat yourDesiredWidth = 260;
    CGFloat yourDesiredHeight = 20.0;
    CGAffineTransform scalingTransform;
    scalingTransform = CGAffineTransformMakeScale(yourDesiredWidth/self.lbl_preventiveCare.bounds.size.width, yourDesiredHeight/self.lbl_preventiveCare.bounds.size.height);
    self.lbl_preventiveCare.transform = scalingTransform;
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (screenBounds.size.height == 568) {
        isIphone5=YES;
        //self.m_imgView.image = [UIImage imageNamed:@"Background_Welcome-568h@2x.png"];

        self.lbl_invalidUID.frame = CGRectMake(30,-37,260,15);
        CGRect frame = self.m_signOnSubView.frame;
        frame.origin.y = 70;
        self.m_signOnSubView.frame = frame;
        
    }else {
        self.lbl_invalidUID.frame = CGRectMake(30,-37,260,15);
        //self.m_imgView.image = [UIImage imageNamed:@"Background_Welcome.png"];

        CGRect frame = self.l1PreventiveCare.frame;
        frame.origin.y = 15;
        
        self.l1PreventiveCare.frame = frame;
        frame = self.m_signOnSubView.frame;
        frame.origin.y = 50;
        self.m_signOnSubView.frame = frame;
        
        frame = self.btn_signOn.frame;
        frame.origin.y = 145;
        self.btn_signOn.frame = frame;
    }*/
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.30];
    self.view.frame = CGRectMake(0, 0, 320, 460);
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.50];
    
    CGFloat yourDesiredWidth = 260.0;
    CGFloat yourDesiredHeight = 44.0;
    CGAffineTransform scalingTransform;
    scalingTransform = CGAffineTransformMakeScale(yourDesiredWidth/self.lbl_preventiveCare.bounds.size.width, yourDesiredHeight/self.lbl_preventiveCare.bounds.size.height);
    self.lbl_preventiveCare.transform = scalingTransform;
    self.lbl_preventiveCare.frame = CGRectMake(20, 15, 260, 44);
    self.lbl_extraText.alpha = 1;
    self.navigationController.navigationBar.alpha = 1;
    self.navigationController.navigationBarHidden = FALSE;
    [self setOriginalFrame];
    [UIView commitAnimations];

}


-(IBAction)termsAndConditionsBtnClicked
{
    TermsAndConditionsViewController *obj = [[TermsAndConditionsViewController alloc ]initWithNibName:@"TermsAndConditionsViewController" bundle:nil];
    
    [self.navigationController pushViewController:obj animated:YES];
    /*
    intPrivacy = 2;
    UINavigationController* nc = [[UINavigationController alloc] initWithRootViewController:privacyVC];
    nc.navigationBar.tintColor = [Utilities getAppDel].navBarColor;
    // nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:nc animated:YES];
     */
}

-(IBAction)privacyStatementBtnClicked
{
    //NSLog(@"%@",[self.navigationController viewControllers]);
    PrivacyPracticesViewController *obj = [[PrivacyPracticesViewController alloc ]initWithNibName:@"PrivacyPracticesViewController" bundle:nil];
    
    [self.navigationController pushViewController:obj animated:YES];
    /*
    intPrivacy = 2;
    UINavigationController* nc = [[UINavigationController alloc] initWithRootViewController:privacyVC];
    nc.navigationBar.tintColor = [Utilities getAppDel].navBarColor;
    // nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:nc animated:YES];
     */
}


//- (void)textFieldDidBeginEditing:(UITextField *)textField
//{
//    /*
//    if(textField == self.txt_password)
//	{
//        [UIView beginAnimations:nil context:NULL];
//        [UIView setAnimationBeginsFromCurrentState:YES];
//        [UIView setAnimationDuration:0.25];
//        CGRect rect = [self.m_signOnView frame];
//        rect.origin.y -= 60;
//        [self.m_signOnView setFrame:rect];
//        [UIView commitAnimations];
//	}*/
//    [UIView beginAnimations:nil context:NULL];
//    [UIView setAnimationBeginsFromCurrentState:YES];
//    [UIView setAnimationDuration:0.50];
//    self.navigationController.navigationBar.alpha = 0;
//    //self.m_signOnView.frame = CGRectMake(0, 0, 320, 460);
//    
//    CGFloat yourDesiredWidth = 260;
//    CGFloat yourDesiredHeight = 40.0;
//    CGAffineTransform scalingTransform;
//    scalingTransform = CGAffineTransformMakeScale(yourDesiredWidth/self.lbl_preventiveCare.bounds.size.width, yourDesiredHeight/self.lbl_preventiveCare.bounds.size.height);
//    self.lbl_preventiveCare.transform = scalingTransform;
//    self.lbl_preventiveCare.frame = CGRectMake(30, 45, 260, 40);
//    self.lbl_extraText.alpha = 0;
//    self.lbl_invalidUID.frame = CGRectMake(30,85,260,21);
//    self.m_signOnSubView.frame = CGRectMake(0, 70, 320, 251);
//    [UIView commitAnimations];
//    
//    NSInteger myCustomHeight = 40;
//    txt_userName.frame = CGRectMake(30, 40, 260, myCustomHeight);
//    txt_password.frame = CGRectMake(30, 85, 260, myCustomHeight);
//    [UIView beginAnimations:nil context:NULL];
//    [UIView setAnimationBeginsFromCurrentState:YES];
//    [UIView setAnimationDuration:0.30];
//    self.btn_forgotPwd.frame = CGRectMake(106, 105, 109, 21);
//    self.btn_forgotPwd.enabled=NO;
//    btn_signOn.frame = CGRectMake(30, 130, 260, 44);
//    [UIView commitAnimations];
//    
//    [self performSelector:@selector(delay) withObject:nil afterDelay:.4];
//}

-(void)delay {
    
    self.navigationController.navigationBarHidden = TRUE;
}

#pragma mark - Webview process

- (void)webViewDidStartLoad:(UIWebView*)loadingWebView
{
	if (firstPageLoaded == NO)
	{
		//m_backgroundView.hidden = NO;
	}
}

- (void)touchCancel:(id)sender
{
	[self.delegate signOnComplete:NO];
}

- (void)signOnCompleteAndValid
{
    [self.delegate signOnComplete:YES];
}

- (void) buttonPressed
{
    [self.delegate signOnComplete:NO];
}

// Load the UIWebView using the configured mode
- (void)loadWebView
{
    // [m_webView setBackgroundColor:[UIColor clearColor]];
    // [m_webView setOpaque:NO];
    
    
    UIColor *background = [[[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]] autorelease];
	m_webView.backgroundColor = background;
    //[background release];

    self.m_webView.dataDetectorTypes = UIDataDetectorTypeNone;
    
    WebServiceMan* wsm = [WebServiceMan get];
    
    NSString *urlString = [NSString stringWithFormat:@"%@/%@%@", 
                           wsm.wsBaseUrl, 
                           @"getTermsAndConditions?appId=", wsm.appId];
    
	NSURL *url = [NSURL URLWithString:urlString];
    
	self.m_curHostName = [url host];
	
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    LOG("loadWebView : Loading Request:%@", request);
	
    [m_webView loadRequest:request];
}

- (void)fetchTestAccountInfo:(NSString*)accountId 
{
    NSString* szUrl = [NSString stringWithFormat:@"%@/registerTestAccount?accountId=%@", 
                       [WebServiceMan get].wsBaseUrl, 
                       accountId];		
    
	NSURL *url = [NSURL URLWithString:szUrl];
	NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
	
	NSData *data = [NSURLConnection sendSynchronousRequest:req returningResponse:nil error:nil]; 
	NSString *testAccountJson = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    // Parse the JSON string into an object - assuming json_string is a NSString of JSON data
    SBJsonParser* parser = [[[SBJsonParser alloc] init] autorelease];
    
    // Assume top-level dictionary
    NSDictionary* dRoot = [parser objectWithString:testAccountJson error:nil];
	[testAccountJson release];
    
    if (dRoot != nil) {
        NSDictionary* dResponse = [dRoot objectForKey:@"response"];
        
        LOG("statusCode:%@ - message:%@", [dResponse objectForKey:@"statusCode"], [dResponse objectForKey:@"message"]);
        
        int nRes = [[dResponse objectForKey:@"statusCode"] intValue];
        
        SERVER_STATUS_RESULT nSSR = [WSCheck getStatusResultFromCode:nRes];
        
        if (WSC_GOOD == nSSR)
        {
            AuthorizationMan* am = [AuthorizationMan get];
            
            //am.kpToken = [dResponse objectForKey:@"token"];
            //am.mrn = [Utilities getStringFromJson:[dResponse objectForKey:@"mrn"]];
            
            [self performSelectorOnMainThread:@selector(signOnCompleteAndValid) withObject:nil waitUntilDone:NO];  
        }
        else
        {
            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:nil 
                                                             message:[NSString stringWithFormat:@"%@\nTry again, please.", @"Error in SignOn"] 
                                                            delegate:self 
                                                   cancelButtonTitle:@"OK" 
                                                   otherButtonTitles:nil] autorelease];
            [alert show];
            [self loadWebView];
            
        }
    }
    
}

//surya check and intercept if entering a test userid and pwd for apple approval
- (BOOL) checkTestAccount:(UIWebView*) webView2 
{
    BOOL isLive = YES;
    
    WS_CONFIG_TYPES wct = [WebServiceMan get].configurationType;
    
    switch (wct) 
    {
        case WCT_QA:
            isLive = NO;
            break;
        default:
            isLive = YES;
            break;
    }
    
    NSString* userId = nil;
    
    NSString* pwd = nil;
    
    NSString *ssoResponseFound = nil;
    
    BOOL testUserFound = NO;
    
    if (isLive) {
        ssoResponseFound = [webView2 stringByEvaluatingJavaScriptFromString:@"document.getElementById('userid') ? 'true' : 'false'"];
        
        if ([ssoResponseFound isEqualToString:@"true"]) {
            userId = [webView2 stringByEvaluatingJavaScriptFromString:@"document.getElementById('userid').value"];
            
            pwd = [webView2 stringByEvaluatingJavaScriptFromString:@"document.getElementById('password').value"];
        }
    } else {
        ssoResponseFound = [webView2 stringByEvaluatingJavaScriptFromString:@"document.getElementById('sso_mrn') ? 'true' : 'false'"];
        
        if ([ssoResponseFound isEqualToString:@"true"]) {
            userId = [webView2 stringByEvaluatingJavaScriptFromString:@"document.getElementById('sso_mrn').value"];
        }
        
    }
    
    LOG("SSO userId: %@", userId);
    
    if (ssoResponseFound) {
        if (isLive ) {
            if (userId != nil && [userId caseInsensitiveCompare:@"tpmg.ttg"] == NSOrderedSame 
                && pwd != nil && [pwd isEqualToString:@"M0bil3C@r3"]) {
                testUserFound = YES;
                LOG("SSO LIVE Test Account found");
                
            }
        } else {
            if (userId != nil && [userId caseInsensitiveCompare:@"tpmg.ttg"] == NSOrderedSame) {
                testUserFound = YES;
                LOG("SSO QA Test Account found");
            }
        }
        if (testUserFound == YES) {
            [self fetchTestAccountInfo:userId];
            return NO;
        }
    }
    
    return YES;
}

- (BOOL)webView:(UIWebView *)webView2 shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    LOG("Starting to load request:%@", request);
    
    [[Utilities getAppDel] showAi];
    self.m_bbiCancel.enabled = NO;
    
	NSURL* reqURL = [request URL];
    NSString* scheme = [reqURL scheme];
    NSString *reqURLStr = [reqURL absoluteString];
    self.requestURL = reqURLStr;
    NSString *fullStr=[reqURL absoluteString];
    
	if ([scheme isEqualToString:@"http"] || [scheme isEqualToString:@"https"])
	{
        NSString* hostName = [reqURL host];
        
        if ([scheme isEqualToString:@"http"] && [hostName rangeOfString:@".org"].location == NSNotFound && [hostName rangeOfString:@"localhost"].location == NSNotFound)
		{
			[[UIApplication sharedApplication] openURL:reqURL];
            return NO;
		}
        

        
	} else if ([scheme isEqualToString:@"mailto"]) {
        NSString *recipient=[fullStr substringFromIndex:7];        
        NSString *recipients = [NSString stringWithFormat:@"mailto:%@?subject=%@ Support", recipient,[[Utilities getAppDel] getAppDisplayName]];
        NSString *body = @" ";
        
        NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
        email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
        return NO;
    }
    else if ([fullStr isEqualToString:@"mobilecare:privacy"]){
        
        PrivacyPracticesViewController *privacyVC = [[PrivacyPracticesViewController alloc ]initWithNibName:@"PrivacyPracticesViewController" bundle:nil];
        intPrivacy = 2;
        UINavigationController* nc = [[UINavigationController alloc] initWithRootViewController:privacyVC];
        nc.navigationBar.tintColor = [Utilities getAppDel].navBarColor;
        // nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentModalViewController:nc animated:YES];
        return NO;
    }

    else 
    {
        return NO;
    }
    
	return YES;
}

- (void) webView:(UIWebView *)webView2 didFailLoadWithError:(NSError *)error
{
    LOG("Error in loading webview: %@", error);
    LOG("The request URL is:%@", self.requestURL);
    
    // These conditions do not need to be checked.
    if ((![self.requestURL isEqualToString:@"mobilecare:consent"]) && (![self.requestURL isEqualToString:@"mobilecare:done"]) && ([error code]!=NSURLErrorCancelled))
	{
        [[Utilities getAppDel] hideAi];
        self.m_bbiCancel.enabled = YES;                
        
        UIView *coverView=[[[UIView alloc] initWithFrame:self.view.frame] autorelease];
        coverView.backgroundColor=[UIColor whiteColor];
        UILabel *lbl=[[[UILabel alloc] initWithFrame:CGRectMake(24, 24, 272, 275)] autorelease];
        lbl.text=[NSString stringWithFormat:@"Network connection failed. We are are unable to connect to the %@ server at this time. Please try again later.", [[Utilities getAppDel] getAppDisplayName] ];
        lbl.textAlignment=UITextAlignmentCenter;
        lbl.numberOfLines=0;
        UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame=CGRectMake(171, 334, 125, 37);
        [button setTitle:@"OK" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(buttonPressed) 
         forControlEvents:UIControlEventTouchUpInside];
        
        [coverView addSubview:lbl];
        [coverView addSubview:button];
        
        [self.view addSubview:coverView];
        LOG("We are showing the cover view!");
        
        //        [[Utilities getAppDel] showMessage:@"Network connection failed. We 
        //        are are unable to connect to the MobileCare server at this time. Please try again later." withButtonText:@"OK"];
    }
}


- (void)webViewDidFinishLoad:(UIWebView *)webView2
{
    
    if (isAccept == 0) {
        
        self.m_BottomContainerView.hidden = FALSE;
        self.btn_accept.hidden = FALSE;
        self.btn_decline.hidden = FALSE;
        
    }
    else{
        self.btn_accept.hidden = TRUE;
        self.btn_decline.hidden = TRUE;
                
        self.m_BottomContainerView.hidden = TRUE;
        
    }
	
    
    m_backgroundView.hidden = YES;
	firstPageLoaded = YES;
    
    [[Utilities getAppDel] hideAi];
    self.m_bbiCancel.enabled = YES;                
    
    //#if TARGET_IPHONE_SIMULATOR
    //    NSInteger height = [[webView2 stringByEvaluatingJavaScriptFromString:@"document.body.offsetHeight;"] intValue];
    //    NSString* javascript = [NSString stringWithFormat:@"window.scrollBy(0, 0);", height];   
    //    [webView2 stringByEvaluatingJavaScriptFromString:javascript];
    //#endif
    
}

#pragma mark - offline mode process

- (void) offlineSignOn:(NSString *)userId :(NSString *)password
{
    AuthorizationMan* am=[AuthorizationMan get];
    if (![am isPreviousUserExisted]) {
        LOG("Not activiated yet!");
//        self.lbl_error.text = @"We're sorry, this app cannot be activated while offline. Please connect to network and try again.";
//        self.lbl_error_title.text = @"Error";
        
        NSString *errorMsg=@"We're sorry, this app cannot be activated while offline. Please connect to network and try again.";
        NSString *title=@"Error";
        [self displayErrorWithTitle:title andMessage:errorMsg];
    } else {
        if ([am isOfflineModeLocked]) {
            LOG("is locked offline!");
            /*
            self.lbl_error.text = @"We're sorry, this app is locked and cannot be unlocked while offline. Please connect your device to network to unlock.";
            self.lbl_error_title.text = @"Error";
            
            [self action_showError];
             */
            NSString *errorMsg=@"We're sorry, this app is locked and cannot be unlocked while offline. Please connect to network to unlock.";
            NSString *title=@"Error";
            [self displayErrorWithTitle:title andMessage:errorMsg];
        } else {
            LOG("The existing userName is: %@", am.userName);
            LOG("The existing password is: %@", am.password);
            NSString* hashedPassword=[Utilities hashString:[password stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
            LOG("values after hashing (input password): %@", hashedPassword);
            
            if ([am hasWarningAccepted]) {
                if ([am.userName isEqualToString:[userId stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]] && [am.password isEqualToString:hashedPassword]) {
                    LOG("Offline login success!");
                    
                    //add offline mode alert logic here
                    double lastMedSyncTime=[self.delegate getLastMemberMedsSyncTime];
                    LOG("The last Med sync time is: %f", lastMedSyncTime);
                    double currentTime=[[NSDate date] timeIntervalSince1970];
                    LOG("The current time is: %f", currentTime);
                    
                    double timeintervalFor24hrs=24*60*60.0;
                    double timeDifference=currentTime-lastMedSyncTime;
                    LOG("The time difference is: %f", timeDifference);
                    
                    if (timeDifference>timeintervalFor24hrs) {
                        NSString *title=@"No Internet Connection";
                        NSString *message=@"Your medications may not be up to date. For your safety, please go online to get the latest updates.";
                        UIAlertView *alertView= [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Try Again", nil];
                        alertView.tag = 1001;
                        [[Utilities getAppDel].alerts addObject:alertView];
                        [alertView show];
                        [alertView release];
                    } else {
                        [self completeOfflineSignOn];
                    }
                } else if ([am.userName isEqualToString:[userId stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]]) {
                    LOG("Offline authent fail");
                
                    [self.txt_password setText:@""];
                    //[self.txt_userName setText:@""];

                    self.lbl_invalidUID.hidden = FALSE;
                    [self setOriginalFrame];
                    //[self.m_signOnSubView setFrame:CGRectMake(0, 201, 320, 251)];
                
                    // offline TryMan logic
                    [self.m_tryMan addTry];
                    if ([self.m_tryMan hasTries]<=0) {
                        [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:UD_OFFLINE_MODE_LOCKED];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                    }
                
                } else {
                    NSString *errorMsg=@"We're sorry, this app cannot be activated while offline. Please connect to network and try again.";
                    NSString *title=@"Error";
                    [self displayErrorWithTitle:title andMessage:errorMsg];
                }
            } else {
                NSString *errorMsg=@"We're sorry, this app cannot be activated while offline. Please connect to network and try again.";
                NSString *title=@"Error";
                [self displayErrorWithTitle:title andMessage:errorMsg];
            }
            
        }
    }
}

- (void)displayErrorWithTitle:(NSString *)title andMessage:(NSString *)errMsg {
    /*
    ErrorViewController *errVC = [[ErrorViewController alloc ]initWithNibName:@"ErrorViewController" bundle:nil withTitle:title andMessage:errMsg];
    
    UINavigationController* nc = [[UINavigationController alloc] initWithRootViewController:errVC];
    nc.navigationBar.tintColor = [Utilities getAppDel].navBarColor;
    [self presentModalViewController:nc animated:NO];
     */
    LOG("Displaying error alert!");
    [self.txt_password setText:@""];
    UIAlertView *alertView= [[UIAlertView alloc] initWithTitle:title message:errMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    alertView.tag = 1010;
    [[Utilities getAppDel].alerts addObject:alertView];
    [alertView show];
    [alertView release];
}


- (BOOL) isDifferentUser {
    AuthorizationMan* am = [AuthorizationMan get];
    
    NSString *newUserName=[self.txt_userName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    LOG("The new user name is: %@", self.txt_userName.text);
    NSString *currentUserName=[am.userName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    LOG("The old user name is: %@", currentUserName);
    
    if ([am isPreviousUserExisted]) {
        if (![newUserName isEqualToString:currentUserName]) {
            LOG("different user is logging in!");
            
            return YES;
        } else return NO;
    } else {
        [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:UD_PREVIOUS_USER_CHECK];
        [[NSUserDefaults standardUserDefaults] synchronize];
        return NO;
    }
}

- (void)completeOnlineSignOn:(NSDictionary *)dResponse {
    // Google Analyser
    [Utilities postGATrackEventName:@"Sign On done" withActionName:@"tracking logged in Users" andlabel:@""];
    
    LOG("What is the dResponse: %@", dResponse);
    
    AuthorizationMan* am = [AuthorizationMan get];
    
    am.userName=[self.txt_userName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    am.password=[self.txt_password.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    am.userId = [Utilities getStringFromJson:[dResponse objectForKey:@"userId"]];
    [am saveValuesToKC];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"flagSignOn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[IdleTimerMan get] resetIdleTimer];
    
    //reset tryMan count
    [self.m_tryMan reset];
    [[NSUserDefaults standardUserDefaults] setValue:@"NO" forKey:UD_OFFLINE_MODE_LOCKED];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    // get activation flag from server to determine whether to see the tutorial or not
    isTutorialNeeded=NO;
    
    NSString *activatedFlag=[dResponse valueForKey:@"introCompleteFl"];
    
    if (activatedFlag!=nil) {
        activatedFlag=[activatedFlag stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        if (![[activatedFlag uppercaseString] isEqualToString:@"Y"]) {
            isTutorialNeeded=YES;
            [[NSUserDefaults standardUserDefaults] setValue:@"NO" forKey:UD_WARNING_ACCEPTED];
            [[NSUserDefaults standardUserDefaults] synchronize];
        } else {
            [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:UD_WARNING_ACCEPTED];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
    }
    
    //[self.m_signOnView removeFromSuperview];
    [self dismissModalViewControllerAnimated:NO];
    [self signOnCompleteAndValid];
}

- (void)completeOfflineSignOn {
    //reset tryMan count
    [self.m_tryMan reset];
    [[NSUserDefaults standardUserDefaults] setValue:@"NO" forKey:UD_OFFLINE_MODE_LOCKED];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"flagSignOn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[IdleTimerMan get] resetIdleTimer];
    
    //[self.m_signOnView removeFromSuperview];
    [self dismissModalViewControllerAnimated:NO];
    [self signOnCompleteAndValid];
}


-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 1001)
    {
        if (buttonIndex == 0)
        {
            [self completeOfflineSignOn];
        } else if (buttonIndex == 1) {
            [self onlineSignOn:self.txt_userName.text :self.txt_password.text];
        }
    } else if (alertView.tag==1000)
    {
        if (buttonIndex == 0)
        {
            [self dismissModalViewControllerAnimated:NO];
            [Utilities signOff];
        } else if (buttonIndex == 1) {
            NSMutableDictionary* dParams = [NSMutableDictionary dictionary];
            
            NSString *tmpUserId=[Utilities getStringFromJson:[self.signInResponse objectForKey:@"userId"]];
            
            [dParams setValue:[Utilities encodeURLString:tmpUserId] forKey:@"userId"];
            
            self.m_fetcherJson = [[[FetcherJson alloc] initWithMethod:@"activateMemberDevice" andParams:dParams] autorelease];
            self.m_fetcherJson.delegate = self;
            self.requestType=ACTIVATE;
            [self.m_fetcherJson fetch];
            
            // AI is dismissed in the delegate.
            [[Utilities getAppDel] showAi];
        }
    } else if (alertView.tag==1002)
    {
        if (buttonIndex == 0)
        {
            [self dismissModalViewControllerAnimated:NO];
            [Utilities signOff];
        } else if (buttonIndex == 1) {
             [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:UD_APP_CLEAR_DATA_FLAG];
             [[NSUserDefaults standardUserDefaults] synchronize];
             shouldClearData=YES;
            
            if (self.signInResponse!=nil) {
                BOOL isDeviceSwtched = [[self.signInResponse objectForKey:@"switchDeviceFlag"] boolValue];
                if (isDeviceSwtched) {
                    LOG("The device is being switched after switched user!");
                    NSString *title=@"Using more than one device?";
                    NSString *message=@"If you continue, changes you make here will not show up on other devices until you use them to log in.";
                    UIAlertView *alertView= [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Use this device", nil];
                    alertView.tag = 1000;
                    [[Utilities getAppDel].alerts addObject:alertView];
                    [alertView show];
                    [alertView release];
                } else {
                    [self completeOnlineSignOn:self.signInResponse];
                }
            } else {
                NSString *errorMsg=@"We're sorry, we're unable to connect to retrieve your data at this time. Please try again later.";
                NSString *title=@"Error";
                [self displayErrorWithTitle:title andMessage:errorMsg];
            }
        }
    }
}

@end
