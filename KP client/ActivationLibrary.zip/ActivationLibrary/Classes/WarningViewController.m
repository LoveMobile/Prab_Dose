//
//  WarningViewController.m
//  ActivationLibrary
//
//
//

#import "WarningViewController.h"
#import "Utilities.h"
#import "AuthorizationMan.h"
#import "Constants.h"

@interface WarningViewController ()

@end

@implementation WarningViewController

@synthesize m_fetcherJson;
@synthesize jsonDict;
@synthesize serviceType;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithDelegate:(id<WarningViewControllerDelegate>)del
{
    self = [super initWithNibName:@"WarningViewController" bundle:nil];
    if (self)
    {
        m_delegate = del;
        self.jsonDict=[Utilities readTutorialJsonFile];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //self.title = @"Medications";
    //self.navigationController.navigationBarHidden = NO;
    //self.navigationController.navigationItem.backBarButtonItem = nil;
    //self.navigationController.navigationItem.title = @"Medications";
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    if (version>=7.0) {
        CGRect screenRect = [[UIScreen mainScreen] bounds];        
        CGRect r1 = CGRectMake(0, 0, screenRect.size.width, 20);
        UIView *statusView=[[UIView alloc] initWithFrame:r1];
        statusView.backgroundColor=[UIColor lightGrayColor];
        [self.view addSubview:statusView];
    }
    
    //////////////////////////////////////////////////////////////
    // make the call to get dynamic data
    NSDictionary *paraDict=[NSDictionary dictionaryWithObjectsAndKeys:@"ios", @"os", nil];
    FetcherJson *fetcherJson = [[FetcherJson alloc] initWithMethod:@"getTutorialAndWarningScreenContent" andParams:paraDict];
    fetcherJson.delegate = self;
    [fetcherJson fetch];
    self.serviceType=@"getWarningContent";
    // AI is dismissed in the delegate.
    [[Utilities getAppDel] showAi];
}

-(IBAction)closeBtnTapClicked
{
    NSMutableDictionary* dParams = [NSMutableDictionary dictionary];
    
    AuthorizationMan *am=[AuthorizationMan get];
    
    [dParams setValue:am.userId forKey:@"userId"];
    
    self.m_fetcherJson = [[[FetcherJson alloc] initWithMethod:@"updateIntroCompleteStatus" andParams:dParams] autorelease];
    self.m_fetcherJson.delegate = self;
    [self.m_fetcherJson fetch];
    self.serviceType=@"updateIntroCompleteStatus";
    
    // AI is dismissed in the delegate.
    [[Utilities getAppDel] showAi];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark -
#pragma mark Fetcher Delegate Methods
/*
- (void) loadTutorialContent:(NSDictionary *) di
{
        NSArray *dynamicTextArr=[di valueForKeyPath:@"warning.sections"];
        for (NSDictionary* textDict in dynamicTextArr) {
            NSString *contentItem=[textDict objectForKey:@"content"];
            NSString *orderStr=[textDict objectForKey:@"order"];
            int orderInt=[orderStr intValue]-1;
            UIWebView *webView=[[[UIWebView alloc] initWithFrame:CGRectMake(0, 230+orderInt*65, 280, 80)] autorelease];
            webView.opaque=NO;
            webView.backgroundColor=[UIColor clearColor];
            webView.userInteractionEnabled=NO;
            LOG("The current content item is: %@", contentItem);
            NSString *content=[NSString stringWithFormat:@"<html><head><style type=\"text/css\"> * { background-color: transparent; font-family: helvetica; font-size: 10pt; color:#000000; }</style></head><body><ul><li>%@</li></ul></body></html>", contentItem];
            [webView loadHTMLString:content baseURL:nil];
            [self.view addSubview:webView];
        }
}
*/

- (NSString *) extractHTMLContent: (NSDictionary *) di
{
    NSString *htmlContent=@"";
    htmlContent=[di valueForKeyPath:@"warning.content"];
    LOG("the extracted html content for warning screen is: %@", htmlContent);

    return htmlContent;
}

- (void) loadDynamicWarningHtml: (NSString *)htmlContent
{
    UIWebView *webView=nil;
    if ([Utilities isiPhone5]) {
        webView=[[[UIWebView alloc] initWithFrame:CGRectMake(0, 230, 280, 568)] autorelease];
    } else {
        webView=[[[UIWebView alloc] initWithFrame:CGRectMake(0, 230, 280, 480)] autorelease];
    }
    webView.opaque=NO;
    webView.backgroundColor=[UIColor clearColor];
    webView.userInteractionEnabled=NO;
    LOG("The current content is: %@", htmlContent);
    [webView loadHTMLString:htmlContent baseURL:nil];
    [self.view addSubview:webView];
}

- (BOOL)fetcher:(Fetcher*)fetcher didSucceedWithValue:(id)value
{
    [[Utilities getAppDel] hideAi];
    
    if (![value isKindOfClass:[NSDictionary class]])
    {
        [self displayErrorAlert];
        LOG("error in web service %@", value);
        return NO;
    }
    
    if (value != nil) {
        NSDictionary* dResponse = [value objectForKey:@"response"];
        
        LOG("statusCode:%@ - message:%@", [dResponse objectForKey:@"statusCode"], [dResponse objectForKey:@"message"]);
        
        int nRes = [[dResponse objectForKey:@"statusCode"] intValue];
        
        LOG("The nRes value is: %d", nRes);
        
        SERVER_STATUS_RESULT nSSR = [WSCheck getStatusResultFromCode:nRes];
        
        if ([self.serviceType isEqualToString:@"updateIntroCompleteStatus"]) {

            if (WSC_GOOD == nSSR)
            {
                // mark the user has accepted the warning
                [[NSUserDefaults standardUserDefaults] setValue:@"YES" forKey:UD_WARNING_ACCEPTED];
                [[NSUserDefaults standardUserDefaults] synchronize];
                [self dismissModalViewControllerAnimated:NO];
                [m_delegate setPasscodeFinished:YES];

            }
            else //web service error
            {
                [self displayErrorAlert];
            }
        } else if ([self.serviceType isEqualToString:@"getWarningContent"]) {
            
                /*
                if (self.jsonDict!=nil) {
                    //[self loadTutorialContent:self.jsonDict];
                    NSString *htmlContent = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"warningPage" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
                 */
            self.jsonDict=value;
            NSString *htmlContent=nil;
            htmlContent=[self extractHTMLContent:self.jsonDict];
            
            if (htmlContent==nil || [htmlContent isEqualToString:@""]) {
                 // Load the content from a static file
                LOG("Loading the local file instead!!!");
                htmlContent = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"warningPage" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
            }
            
            [self loadDynamicWarningHtml:htmlContent];
        }
    } else {
        [self displayErrorAlert];
        LOG("error in web service!! The return is nil");
        return NO;
    }
    
    return YES;
}

- (BOOL)fetcher:(Fetcher*)fetcher didFailWithError:(FETCHER_FAILURE)value
{
    [[Utilities getAppDel] hideAi];
    if ([self.serviceType isEqualToString:@"getWarningContent"]) {
        // Load the content from a static file
        /*
        self.jsonDict=[Utilities readTutorialJsonFile];
        if (self.jsonDict!=nil) {
            [self loadTutorialContent:self.jsonDict];
        }
        */
        NSString *htmlContent = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"warningPage" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
        [self loadDynamicWarningHtml:htmlContent];
    } else {
        [self displayErrorAlert];
    }

    return YES;
}

- (void) displayErrorAlert
{
    NSString* errorMessage=[NSString stringWithFormat:@"%@ is having trouble with signon. Please try again later.",[[Utilities getAppDel] getAppDisplayName]];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:errorMessage delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Re-try", nil];
    alert.tag = 1005;
    [alert show];
    [alert release];
}

-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 1005)
    {
        if (buttonIndex == 0)
        {
            [self dismissModalViewControllerAnimated:NO];
            [Utilities signOff];
        } else if (buttonIndex == 1) {
            [self closeBtnTapClicked];
        }
    }
}


@end
