//
//  AuthorizationCheck.m
//  MobileCare
//
//  Created by Paul on 5/17/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "AuthorizationCheck.h"
#import "NetworkMan.h"

@implementation AuthorizationCheck

- (void)startCheck
{
    NSAssert(self.delegate, @"delegate should be set");

    self.m_fetcher = [[[FetcherJson alloc] initWithMethod:@"getAuthorizeStatus" andParams:nil] autorelease];
    self.m_fetcher.delegate = self;
    [self.m_fetcher fetch];
}

- (void)dealloc
{    
    [super dealloc];
}

@end
