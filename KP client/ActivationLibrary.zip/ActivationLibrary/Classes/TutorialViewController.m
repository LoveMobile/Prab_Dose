//
//  CustomPageControlExampleViewController.m
//  CustomPageControlExample
//
//

#import "TutorialViewController.h"
#import "Utilities.h"
#import "WarningViewController.h"
#import "Constants.h"

@implementation TutorialViewController

@synthesize scrollView2;
@synthesize pageControl2;
@synthesize contentView2;
@synthesize warningView;
@synthesize jsonDict;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithMode:(BOOL)isStandalone
{
    self = [super initWithNibName:@"TutorialViewController" bundle:nil];
    if (self)
    {
        self.standalone=isStandalone;
        LOG("In Init. the standalone flag is: %d", self.standalone);
        //self.jsonDict=[Utilities readTutorialJsonFile];
    }
    return self;
}

- (void)dealloc
{
    [scrollView2 release];
    [pageControl2 release];
    [contentView2 release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    textView1.textColor = [UIColor colorWithHexString:@"333333"];
//    textView2.textColor = [UIColor colorWithHexString:@"333333"];
//    textView3.textColor = [UIColor colorWithHexString:@"333333"];
//    textView4.textColor = [UIColor colorWithHexString:@"333333"];
    textView1.textColor = [UIColor whiteColor];
    textView2.textColor = [UIColor whiteColor];
    textView3.textColor = [UIColor whiteColor];
    textView4.textColor = [UIColor whiteColor];
    textView5.textColor = [UIColor whiteColor];
    
    //textView1.text = @"\u2022 ";
    
    //set up second view
    scrollView2.pagingEnabled = YES;
    scrollView2.contentSize = contentView2.bounds.size;
    scrollView2.showsHorizontalScrollIndicator = NO;
    [scrollView2 addSubview:contentView2];
    
    pageControl2.numberOfPages = contentView2.bounds.size.width / scrollView2.bounds.size.width;
    pageControl2.defersCurrentPageDisplay = YES;
    //pageControl2.selectedDotColour = [UIColor colorWithHexString:@"0094D0"];
    pageControl2.dotColour = [UIColor whiteColor];
    pageControl2.selectedDotColour = [UIColor grayColor];
    pageControl2.dotSize = 10.0;
    pageControl2.dotSpacing = 18.0;
    pageControl2.wrap = YES;
    CGRect biggerFrame = self.tabBarController.view.frame;
    biggerFrame.size.height += self.tabBarController.tabBar.frame.size.height;
    self.tabBarController.view.frame = biggerFrame ;
    self.view.backgroundColor = [UIColor redColor];
    NSLog(@"self.view ::: %@",[self.view subviews]);
    self.tabBarController.tabBar.hidden = YES;

    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (screenBounds.size.height == 568) {
        self.view.frame = CGRectMake(0, 0, 320,  568);
        self.pageControl2.frame = CGRectMake(0, 500, 320,  32);

        // code for 4-inch screen
    } else {
        // code for 3.5-inch screen
        self.view.frame = CGRectMake(0, 0, 320, 460);
        self.pageControl2.frame = CGRectMake(0, 412, 320,  32);
    }

    self.navigationController.navigationBarHidden = YES;
    
    //////////////////////////////////////////////////////////////
    // make the call to get dynamic data
    NSDictionary *paraDict=[NSDictionary dictionaryWithObjectsAndKeys:@"ios", @"os", nil];
    FetcherJson *fetcherJson = [[FetcherJson alloc] initWithMethod:@"getTutorialAndWarningScreenContent" andParams:paraDict];
    fetcherJson.delegate = self;
    [fetcherJson fetch];
    // AI is dismissed in the delegate.
    [[Utilities getAppDel] showAi];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    self.scrollView2 = nil;
    self.pageControl2 = nil;
    self.contentView2 = nil;
}


/////////////////////////////////////////////////////////////////
/*
- (void) loadTutorialContent:(NSDictionary *) di
{

        NSArray *tutorialArr=[di valueForKeyPath:@"response.tutorials"];
        LOG("First array is: %@", tutorialArr);
        for (NSDictionary* tutorialDict in tutorialArr) {
            NSArray *dynamicTextArr=[tutorialDict valueForKeyPath:@"tutorial.sections"];
            for (NSDictionary* textDict in dynamicTextArr) {
                NSString *contentItem=[textDict objectForKey:@"content"];
                NSString *orderStr=[textDict objectForKey:@"order"];
                int orderInt=[orderStr intValue]-1;
                UIWebView *webView=nil;
                CGRect screenBounds = [[UIScreen mainScreen] bounds];
                if (screenBounds.size.height == 568) {
                    webView=[[[UIWebView alloc] initWithFrame:CGRectMake(0, 75+orderInt*140, 300, 140)] autorelease];
                } else {
                    webView=[[[UIWebView alloc] initWithFrame:CGRectMake(0, 76+orderInt*110, 300, 110)] autorelease];
                }
                webView.opaque=NO;
                webView.backgroundColor=[UIColor clearColor];
                webView.userInteractionEnabled=NO;
                LOG("The current content item is: %@", contentItem);
                NSString *content=@"";
                if (screenBounds.size.height == 568) {
                    content=[NSString stringWithFormat:@"<html><head><style type=\"text/css\"> * { background-color: transparent; font-family: helvetica; font-size: 10pt; color:#ffffff; }</style></head><body><ul><li>%@</li></ul></body></html>", contentItem];
                } else {
                    content=[NSString stringWithFormat:@"<html><head><style type=\"text/css\"> * { background-color: transparent; font-family: helvetica; font-size: 9pt; color:#ffffff; }</style></head><body><ul><li>%@</li></ul></body></html>", contentItem];
                }
                [webView loadHTMLString:content baseURL:nil];
                [self.contentView2 addSubview:webView];
            }
        }
}*/

- (NSString *) extractHTMLContent: (NSDictionary *) di
{
    NSString *htmlContent=@"";
    NSArray *tutorialArr=[di valueForKeyPath:@"response.tutorials"];
    LOG("First array is: %@", tutorialArr);
    for (NSDictionary* tutorialDict in tutorialArr) {
        NSDictionary* tutorialPage=[tutorialDict objectForKey:@"tutorial"];
        // how to make it more fit to json like page number?
        int pageNumber=[[tutorialPage objectForKey:@"page"] intValue];
        if (pageNumber==1) {
            htmlContent=[tutorialPage objectForKey:@"content"];
            LOG("the extracted html content is: %@", htmlContent);
        }
    }
    return htmlContent;
}

- (void) loadDynamicTutorialHtml: (NSString *)htmlContent
{
    UIWebView *webView=nil;
    if ([Utilities isiPhone5]) {
        webView=[[[UIWebView alloc] initWithFrame:CGRectMake(0, 76, 300, 568)] autorelease];
    } else {
        webView=[[[UIWebView alloc] initWithFrame:CGRectMake(0, 73, 300, 480)] autorelease];
    }
    webView.opaque=NO;
    webView.backgroundColor=[UIColor clearColor];
    webView.userInteractionEnabled=NO;
    LOG("The current content is: %@", htmlContent);
    [webView loadHTMLString:htmlContent baseURL:nil];
    [self.contentView2 addSubview:webView];
}


- (BOOL)fetcher:(Fetcher*)fetcher didSucceedWithValue:(id)value
{
    [[Utilities getAppDel] hideAi];
    NSString *htmlContent = nil;
    if (value != nil) {
        LOG("The returned response is: %@", value);
        
        /*
        NSDictionary* dResponse = [value objectForKey:@"response"];
        id statusCode=[dResponse objectForKey:@"statusCode"];
        NSString* statusCodeStr=@"0";
        if ([statusCode isKindOfClass:[NSString class]])
        {
            statusCodeStr = statusCode;
        }
        else if ([statusCode respondsToSelector:@selector(stringValue)])
        {
            statusCodeStr = [statusCode stringValue];
        }
        if ([statusCodeStr isEqualToString:@"0"]) {
            self.jsonDict=value;
            if (self.jsonDict!=nil) {
                //[self loadTutorialContent:self.jsonDict];
                NSString *htmlContent = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"tutorialPage" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
                [self loadDynamicTutorialHtml:htmlContent];
            }
        }  // status code != 0
        */
        
        self.jsonDict=value;
        htmlContent=[self extractHTMLContent:self.jsonDict];
    }
    
    if (htmlContent==nil || [htmlContent isEqualToString:@""]) {
        LOG("Loading the local file instead!!!");
        htmlContent = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"tutorialPage" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
    }
    
    [self loadDynamicTutorialHtml:htmlContent];
    return YES;
}

- (BOOL)fetcher:(Fetcher*)fetcher didFailWithError:(FETCHER_FAILURE)value
{
    [[Utilities getAppDel] hideAi];
    
    LOG("The cause of failure is %d.", value);

    // Load the content from a static file
    /*
    self.jsonDict=[Utilities readTutorialJsonFile];
    if (self.jsonDict!=nil) {
        [self loadTutorialContent:self.jsonDict];
    }*/
    NSString *htmlContent = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"tutorialPage" ofType:@"html"] encoding:NSUTF8StringEncoding error:nil];
    [self loadDynamicTutorialHtml:htmlContent];
    return YES;
}



-(IBAction)closeBtnClicked
{
    //NSLog(@"the Subviews %@",[self.view subviews]);
    LOG("In Close! The standalone flag is: %d", self.standalone);
    if (self.standalone) {
        LOG("I am in standalone!");
        [self dismissModalViewControllerAnimated:NO];
        //[self.navigationController popViewControllerAnimated:YES];
        /*
        CGPoint offset = CGPointMake(0, 0);
        [scrollView2 setContentOffset:offset animated:YES];
        [self.navigationController popViewControllerAnimated:YES];
        //pageControl2.currentPage = 0;
        [[[self.tabBarController viewControllers] objectAtIndex:0] popToRootViewControllerAnimated:NO];
        [Utilities getAppDel].tabBarController.selectedIndex = 0;
         */
    } else {
        LOG("I am invoked from sign in!");
        [self dismissModalViewControllerAnimated:NO];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"displayWarning" object:nil];
    }
    //WarningViewController *obj = [[WarningViewController alloc]initWithNibName:@"WarningViewController" bundle:nil];
    //[self.navigationController pushViewController:obj animated:NO];
    //[self.tabBarController.selectedViewController presentModalViewController:obj animated:YES];
    
    //    [[[self.tabBarController viewControllers] objectAtIndex:0] popToRootViewControllerAnimated:NO];
    //[Utilities getAppDel].tabBarController.selectedIndex = 0;

}

-(IBAction)closeBtnTapClicked
{
    [[[self.tabBarController viewControllers] objectAtIndex:0] popToRootViewControllerAnimated:NO];
    [Utilities getAppDel].tabBarController.selectedIndex = 0;

    //[Utilities getAppDel].tabBarController.selectedIndex = 1;
    
    //[self.view removeFromSuperview];
    //[Utilities getAppDel].tabBarController.selectedIndex = 0;
    //self.view.hidden = YES;
}

-(IBAction)backClicked:(id)sender {
    
//    if (backFlag == 1) {
//        [self.navigationController popViewControllerAnimated:YES];
//    }
//    else {
//        AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
//        
//        [appDelegate addTabBar];
//    }
}

-(IBAction)nextClicked:(id)sender {
//    LoginViewcontroller *obj = [[LoginViewcontroller alloc] init];
//    [self.navigationController pushViewController:obj animated:YES];
}

- (IBAction)pageControlAction:(CustomPageControl *)sender
{
    CGPoint offset = CGPointMake(sender.currentPage * scrollView2.bounds.size.width, 0);
    [scrollView2 setContentOffset:offset animated:YES];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //update page control when scrollview scrolls
    //prevent flicker by only updating when page index has changed

    NSInteger pageIndex = round(scrollView.contentOffset.x / scrollView.bounds.size.width);
        
    pageControl2.currentPage = pageIndex;
}

@end
