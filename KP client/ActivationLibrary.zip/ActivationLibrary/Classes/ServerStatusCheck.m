//
//  ServerStatusCheck.m
//  MobileCare
//
//  Created by Paul on 5/13/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "ServerStatusCheck.h"

@implementation ServerStatusCheck

- (void)startCheck
{
    NSAssert(self.delegate, @"delegate should be set");

    // TODO : add version and os.
    
    self.m_fetcher = [[[FetcherJson alloc] initWithMethod:@"checkServerStatus" andParams:nil] autorelease];
    self.m_fetcher.delegate = self;
    [self.m_fetcher fetch];
}

@end