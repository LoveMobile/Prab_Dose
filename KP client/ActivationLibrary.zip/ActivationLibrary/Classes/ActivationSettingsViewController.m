//
//  ActivationSettingsViewController.m
//  MobileCare
//
//  Created by Sean Gilligan on 10/12/10.
//  Copyright 2010 Fingerpaint Labs. All rights reserved.
//  Refurb Appstem/Kaiser
//

#import "ActivationSettingsViewController.h"
//#import "PushSettingsViewController.h"
#import "MobileCareAppDelegate.h"
//#import "MCWebServices.h"
#import "AuthorizationMan.h"
#import "Utilities.h"
#import "IdleTimerMan.h"
//#import "CoreDataMan.h"

#define	kDeauthorizeAlert	200
#define kReauthorizeAlert	201
#define	kNoPasscodeAlert	202
#define kSignoutAlert       203

@implementation ActivationSettingsViewController
@synthesize deactivateButton, setPcVC;

- (id)init
{
    return [super initWithNibName:@"SettingsView" bundle:nil];
}

- (void)setPasscodeFinished:(BOOL)confirmed
{
    [self dismissModalViewControllerAnimated:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"dismissPasscodeNoti" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"dismissPasscodeAppDelNoti" object:nil];    
    [IdleTimerMan get].changePasscodeActive=NO;
    [Utilities getAppDel].changePasscodeActive=NO;
    
    //if (NO == confirmed)
    //{
    //    [switchPasscodeLock setOn:NO animated:YES];
    //}
}

- (void)dismissPasscodeViewByIdleTimer
{
    self.setPcVC.activateEnterPasscode=YES;
    [self dismissModalViewControllerAnimated:NO];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"dismissPasscodeNoti" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"dismissPasscodeAppDelNoti" object:nil];
    [IdleTimerMan get].changePasscodeActive=NO;
    [Utilities getAppDel].changePasscodeActive=NO;
}

- (void)dismissPasscodeViewByAppDel
{
    [self dismissModalViewControllerAnimated:NO];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"dismissPasscodeNoti" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"dismissPasscodeAppDelNoti" object:nil];
    [IdleTimerMan get].changePasscodeActive=NO;
    [Utilities getAppDel].changePasscodeActive=NO;
}

- (void)pop
{
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"_fromLandingView"]) {
        [self.navigationController popViewControllerAnimated:YES];
        [Utilities getAppDel].tabBarController.selectedIndex = 0;
        [Utilities action_TransitionFromLeft];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}
- (void)viewDidLoad 
{
    [super viewDidLoad];
    
    // Left Navigation button
    
    UIImage* image3 = [UIImage imageNamed:@"icon_bkgd_back-arow.png"];
    CGRect frameimg = CGRectMake(0, 0, 40, 30);
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(pop)
         forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *m_barSomeButton = [[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.leftBarButtonItem = m_barSomeButton;
    [someButton release];
    [m_barSomeButton release];
    
    UIColor *background = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bkgd_wht-ltgrey.png"]];
    self.view.backgroundColor = background;
    [background release];
    
    //[[NSNotificationCenter defaultCenter] addObserver:self 
    //                                         selector:@selector(passcodeLockEnableChanged://) 
    //                                          name:MCPasscodeLockEnableChangedNotification 
    //                                          object:nil];
    
    tableView.backgroundColor = [UIColor clearColor];
    //switchPasscodeLock.on =  [[AuthorizationMan get] passcodeRequired];
    marketingVersionLabel.text = [[Utilities getAppDel] appVersion];
    cellPassCodeChange.textLabel.text = @"Change passcode";
    cellPushNotificationsDisclosure.textLabel.text = @"Push notifications";
    
    self.deactivateButton=[UIButton buttonWithType:UIButtonTypeCustom];
    [self.deactivateButton setFrame:CGRectMake(20, 300, 280, 35)];
    [self.deactivateButton setBackgroundImage:[[UIImage imageNamed:@"bkgd_button_blue.png"]
                                               stretchableImageWithLeftCapWidth:10.0f
                                               topCapHeight:0.0f]
                                     forState:UIControlStateNormal];
    [self.deactivateButton setTitle:@"Sign out" forState:UIControlStateNormal];
    [self.deactivateButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    //        self.deleteButton.titleLabel.font = [UIFont boldSystemFontOfSize:20];
    [self.deactivateButton.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:18.0]];        
    self.deactivateButton.titleLabel.shadowColor = [UIColor lightGrayColor];
    self.deactivateButton.titleLabel.shadowOffset = CGSizeMake(0, -1);     
    [self.deactivateButton addTarget:self action:@selector(doSignout:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.deactivateButton];
    self.deactivateButton.hidden=NO;
    self.deactivateButton.enabled=YES;       
}

-(void)viewWillAppear:(BOOL)animated{
    
    // iOS 6 tableview BG not clear issue
    [tableView setBackgroundView:nil];
    
    // Google Analyser
    [Utilities postGATrackPageName:@"SettingViewClicked"];
    
    if (int_showMessage == 1) {
        int_showMessage = 0;
        [[Utilities getAppDel] hideMessage];
    }
}

- (void) passcodeLockEnableChanged:(NSNotification *)notification
{
    //switchPasscodeLock.on = [[AuthorizationMan get] passcodeRequired];
}

- (IBAction)passcodeLockSwitchChanged:(UISwitch *)sender
{
    if (sender.isOn)
    {
        SetPasscodeViewController* vc = [[[SetPasscodeViewController alloc] initWithDelegate:self] autorelease];        
        vc.title = [[Utilities getAppDel] getAppDisplayName];
        [Utilities showVc:vc AsModalTo:self];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Remove Passcode" 
                                                        message:@"The security pin code protects the health information stored on your device. Click OK if you are sure you want to remove the security pin code."
                                                       delegate:self 
                                              cancelButtonTitle:@"Cancel" 
                                              otherButtonTitles:@"OK", nil];
        alert.tag = kNoPasscodeAlert;
        [alert show];
        [alert release];
    }
}

- (IBAction)changePassCode:(id)sender
{
    
    // Google Analyser
    [Utilities postGATrackEventName:@"Change Passcode View Clicked" withActionName:@"track Change Passcode View" andlabel:@""];
    
    SetPasscodeViewController* vc = [[[SetPasscodeViewController alloc] initWithDelegate:self] autorelease];        
    vc.title = [[Utilities getAppDel] getAppDisplayName];
    [Utilities showVc:vc AsModalTo:self];
    
}

- (void)doSignout:(id)sender
{
    
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sign Out" 
                                                    message:@"Are you sure you want to sign out?"
                                                   delegate:self 
                                          cancelButtonTitle:@"Cancel"
                                          otherButtonTitles:@"OK", nil];
    alert.tag = kSignoutAlert;
    [alert show];
    [alert release];
    
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alert clickedButtonAtIndex:(NSInteger)buttonIndex
{
    // The user clicked one of the OK/Cancel buttons
    
    switch (alert.tag)
    {
        case kSignoutAlert:
            // buttonIndex 0 is cancel, ignore
            if (buttonIndex == 1)
            {
                /*
                int_deactivate = 1;
                [[Utilities getAppDel] hideMessage];
                [[AuthorizationMan get] deauthorize];
                [[Utilities getAppDel] showMerlinWithState:DEAUTHORIZED];
                 /////////////////
                [[[self.tabBarController viewControllers] objectAtIndex:0] popToRootViewControllerAnimated:NO];
                [Utilities getAppDel].tabBarController.selectedIndex = 0;
                [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"flagSignOn"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                [[Utilities getAppDel] showMerlin];
                 */
                [Utilities signOff];
            }
            break;
            
        case kNoPasscodeAlert:
            if (buttonIndex == 0)
            {
                //switchPasscodeLock.on = YES;
            }
            else if (buttonIndex == 1)
            {
                [[AuthorizationMan get] resetPasscode];
            }
            break;
            
        default:
            break;
    }
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // ABHI CHECK Passcode or Sign On view
    /*
    BOOL _bool = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOnAsBG"];
    if (_bool == TRUE) {
        return 1;
    }
    else{
        return 2;
    }*/
    return 1;
    
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    // ABHI CHECK Passcode or Sign On view
    /*
    BOOL _bool = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOnAsBG"];
    if (_bool == TRUE) {
        
        switch (section)
        {
            case 0:
                return 1;
            default:
                return 0;
        }
        
    }
    else{
        switch (section)
        {
            case 0:
                return 1;
            case 1:
                return 1;
            default:
                return 0;
        }
    }*/
    return 1;
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    // ABHI CHECK Passcode or Sign On view
    /*
    BOOL _bool = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOnAsBG"];
    if (_bool == TRUE) {
        
        switch (indexPath.section)
        {
            case 0:
                if(indexPath.row == 0) return cellPushNotificationsDisclosure;
                break;
            default:
                return nil;
        }
    }
    else{
        switch (indexPath.section)
        {
            case 0:
                if(indexPath.row == 0) return cellPassCodeChange;
                break;
            case 1:
                if(indexPath.row == 0) return cellPushNotificationsDisclosure;
                break;
            default:
                return nil;
        }
        
    }
    
    
    return nil;
     */
    return cellPassCodeChange;
}

- (void) tableView: (UITableView *) tv didSelectRowAtIndexPath:(NSIndexPath *) indexPath
{
    /*
    switch (indexPath.section)
    {
        case 0:
        {   
            //[switchPasscodeLock setOn:(!switchPasscodeLock.on) animated:YES];
            //[self passcodeLockSwitchChanged:switchPasscodeLock];
            //[self changePassCode:changePasscode];
            //[[AuthorizationMan get] resetPasscode];
            
            
            // ABHI CHECK Passcode or Sign On view
            BOOL _bool = [[NSUserDefaults standardUserDefaults] boolForKey:@"flagSignOnAsBG"];
            if (_bool == TRUE) {
                
                PushSettingsViewController *vc = [[PushSettingsViewController alloc] initWithNibName:@"PushSettingsViewController" bundle:nil];			
                vc.title = @"Push notifications";
                [self.navigationController pushViewController:vc animated:YES];
                [vc release];
                
            }
            else{
                
                self.setPcVC = [[SetPasscodeViewController alloc] initWithDelegate:self];        
                self.setPcVC.title = @"Change passcode";
                self.setPcVC.changePasscode = YES;
                [Utilities showVc:self.setPcVC AsModalTo:self];
                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dismissPasscodeViewByIdleTimer) name:@"dismissPasscodeNoti" object:nil];
                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dismissPasscodeViewByAppDel) name:@"dismissPasscodeAppDelNoti" object:nil];
                [IdleTimerMan get].changePasscodeActive=YES;
                [Utilities getAppDel].changePasscodeActive=YES;
                
            }
            
            break;
        }
        case 1:
        {
            PushSettingsViewController *vc = [[PushSettingsViewController alloc] initWithNibName:@"PushSettingsViewController" bundle:nil];			
            vc.title = @"Push notifications";
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
            break;
        }
        default:
            break;
    }*/
    self.setPcVC = [[SetPasscodeViewController alloc] initWithDelegate:self];        
    self.setPcVC.title = @"Change passcode";
    self.setPcVC.changePasscode = YES;
    [Utilities showVc:self.setPcVC AsModalTo:self];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dismissPasscodeViewByIdleTimer) name:@"dismissPasscodeNoti" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dismissPasscodeViewByAppDel) name:@"dismissPasscodeAppDelNoti" object:nil];
    [IdleTimerMan get].changePasscodeActive=YES;
    [Utilities getAppDel].changePasscodeActive=YES;
    
    [tv deselectRowAtIndexPath:indexPath animated:YES];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    self.deactivateButton=nil;
    self.setPcVC=nil;
}


- (void)dealloc
{
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:MCPasscodeLockEnableChangedNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"dismissPasscodeNoti" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"dismissPasscodeAppDelNoti" object:nil];
    self.deactivateButton=nil;
    self.setPcVC=nil;
    [super dealloc];
}


@end
