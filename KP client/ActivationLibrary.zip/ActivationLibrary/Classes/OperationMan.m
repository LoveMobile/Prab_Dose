//
//  OperationMan.m
//  Iface1
//
//  Created by Paul on 4/20/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import "OperationMan.h"
#import "Constants.h"

#define MAX_OPERATIONS 1
//#define MAX_OPERATIONS 5

static OperationMan* mOperationMan;

@implementation OperationMan

@synthesize queue;

+ (OperationMan*)get
{
	if (nil == mOperationMan)
	{
		mOperationMan = [[OperationMan alloc] init];
	}
	return mOperationMan;
}

- (id)init
{
	if ((self = [super init]))
	{
		self.queue = [[[NSOperationQueue alloc] init] autorelease];	
		[queue setMaxConcurrentOperationCount:MAX_OPERATIONS];
		LOG("max operations %i", [queue maxConcurrentOperationCount]); 	
	}
	return self;
}

// This should be called by the main thread.
- (NSOperation*)executeOnTarget:(id)target selector:(SEL)pSelector param:(id)pParam
{	
	NSInvocationOperation* nio = [[NSInvocationOperation alloc] initWithTarget:target selector:pSelector object:pParam];

	NSAssert(nio, @"The NSInvocationOperatin is nil");
	
	[queue addOperation:nio];
	
	[nio autorelease];

	return nio;
}

- (NSOperation*)invoke:(NSInvocation*)inv
{	
	NSInvocationOperation* nio = [[NSInvocationOperation alloc] initWithInvocation:inv];
	
	NSAssert(nio, @"The NSInvocationOperation is nil");
		
	[queue addOperation:nio];

	return [nio autorelease];
}

- (void)dealloc
{
	self.queue = nil;
	[super dealloc];
}


@end

