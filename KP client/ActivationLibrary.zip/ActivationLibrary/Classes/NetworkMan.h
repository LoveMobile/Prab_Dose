//
//  NetworkMan.h
//  MobileCare
//
//  Created by Paul on 4/20/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>

#define NETWORK_INIT_CONNECT_TIMEOUT 60

@interface NetworkMan : NSObject 
{
}

+ (UInt32)getNetworkType;
+ (NSURL*)makeURLWithMethod:(NSString*)method;
+ (NSURLConnection*)getResultFromUrl:(NSURL*)url withMethod:(NSString *)method withParams:(NSDictionary*)parms andDelegate:(id)del;

@end
