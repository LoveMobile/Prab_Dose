//
//  Fetcher.h
//  MobileCare
//
//  Created by Paul on 4/20/11.
//  Copyright 2011 Appstem. All rights reserved.
//

#import <Foundation/Foundation.h>

#define TIME_OUT_SEC 60

typedef enum
{
	FS_IDLE,
	FS_FETCHING,
	FS_FETCHED,
	FS_FAILED,
} FETCHER_STATE;

typedef enum
{
	FF_TIMEOUT = -100,
	FF_CANCELED = -101,
	FF_FAILED = -102, // network failure.
} FETCHER_FAILURE;


@class Fetcher;

@protocol FetcherDelegate <NSObject>
- (BOOL)fetcher:(Fetcher*)fetcher didSucceedWithValue:(id)value;
- (BOOL)fetcher:(Fetcher*)fetcher didFailWithError:(FETCHER_FAILURE)value;
@end

@interface Fetcher : NSObject 
{
	FETCHER_STATE m_nState;
	NSMutableData* m_msdData;
	NSTimer* m_timer;
	NSURLConnection* m_nsUrlConnection;
    
    id<FetcherDelegate> m_delegate;
}

@property (assign) FETCHER_STATE m_nState;
@property (nonatomic, retain) NSMutableData* m_msdData;
@property (nonatomic, retain) NSTimer* m_timer;
@property (nonatomic, retain) NSURLConnection* m_nsUrlConnection;
@property (assign) id<FetcherDelegate> delegate;

- (void)extract;
- (void)fetch;
- (void)cancel;
- (void)cleanup; // to be used after the delegate has used the response.

- (void)clear; // internal only.
- (void)stop;

@end
