//
//  PhoneLinkHandler.h
//  MobileCare
//
//  Created by Zhanquan He on 7/18/11.
//  Copyright 2011 kaiser permanente. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kNotSupported   101
#define kSingleNumber   102
#define kMultipleNumber 103

@interface PhoneLinkHandler : NSObject <UIAlertViewDelegate> {
    
}

@property (nonatomic, retain) NSString *cancelBtnText;
@property (nonatomic, retain) NSString *alertTitle;
@property (nonatomic, retain) NSString *callString;
@property (nonatomic, retain) NSMutableArray *callPromptsAndNumbers;

- (void) showPhoneAlertWithPhoneNum:(NSString *)phoneNum;
- (void) showPhoneAlertWithPhoneNums:(NSArray *)phoneNums;
- (void) doCallDirectly:(NSString *)phoneNum;
@end
